import {settlements} from './market.mjs';

export function handler(assets) {
  return {async fetch(request,env={}) {
    const url=new URL(request.url);
    const api=url.pathname==='/api/market/settlements';
    const warm=url.pathname==='/api/market/refresh';
    if(api||warm) {
      if(request.method!==(warm?'POST':'GET')) return new Response('Method not allowed',{status:405});
      const result=await settlements(url,env,warm);
      return Response.json(result,{status:warm&&!Object.keys(result.quotes).length?503:200,headers:{'Cache-Control':'no-store'}});
    }
    if(!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed',{status:405});
    const asset=assets[url.pathname==='/'?'/index.html':url.pathname];
    if(!asset) return new Response('Not found',{status:404});
    const [type,body]=asset;
    return new Response(request.method==='HEAD'?null:body,{headers:{'Content-Type':type,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'}});
  }};
}
