const ICE='https://www.ice.com/marketdata/api/productguide/charting/';
const PRODUCTS={SB:[582,729],W:[15249,17453]};
const MONTHS={Jan:'F',Feb:'G',Mar:'H',Apr:'J',May:'K',Jun:'M',Jul:'N',Aug:'Q',Sep:'U',Oct:'V',Nov:'X',Dec:'Z'};
const SYMBOL=/^(?:SB[FHKNV]|W[HKQVZ])\d{2}$/;

export function cutoff(now=new Date()) {
  const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  return new Date(Date.parse(today+'T00:00:00Z')-86400000).toISOString().slice(0,10);
}

export function parseHistorical(bars,through) {
  const dates=new Map();
  for(const bar of bars??[]) {
    if(!Array.isArray(bar)||typeof bar[0]!=='string'||!Number.isFinite(bar[1])||bar[1]<=0) continue;
    const m=bar[0].match(/^\w{3} (\w{3}) (\d{1,2}) \d\d:\d\d:\d\d (\d{4})$/);
    if(!m) continue;
    const month=Object.keys(MONTHS).indexOf(m[1])+1;
    if(!month) continue;
    const date=m[3]+'-'+String(month).padStart(2,'0')+'-'+m[2].padStart(2,'0');
    if(date<=through) dates.set(date,bar[1]);
  }
  const sorted=[...dates.keys()].sort().reverse();
  const [date,previousDate]=sorted;
  return date?{date,close:dates.get(date),previousDate:previousDate??null,previous:dates.get(previousDate)??null}:null;
}

async function ice(path) {
  const response=await fetch(ICE+path,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(8500)});
  if(!response.ok) throw new Error('ICE HTTP '+response.status);
  return response.json();
}

async function chain(product) {
  const [id,hub]=PRODUCTS[product];
  const rows=await ice('contract-data?productId='+id+'&hubId='+hub);
  if(!Array.isArray(rows)) throw new Error('ICE contract list unavailable');
  return rows.flatMap(row=>{
    const m=/^([A-Za-z]{3})(\d{2})$/.exec(row.marketStrip);
    if(!m||!MONTHS[m[1]]||!Number.isInteger(row.marketId)) return [];
    return [[product+MONTHS[m[1]]+m[2],row.marketId]];
  }).filter(([symbol])=>SYMBOL.test(symbol));
}

async function readStored(bucket,symbol) {
  if(!bucket) return null;
  const item=await bucket.get('sugar-closes/v1/'+symbol+'.json');
  return item?item.json():null;
}
async function writeStored(bucket,symbol,data) {
  if(bucket) await bucket.put('sugar-closes/v1/'+symbol+'.json',JSON.stringify(data),{httpMetadata:{contentType:'application/json'}});
}

export async function settlements(url,env,warm=false) {
  const through=cutoff();
  const now=Date.now();
  const force=warm||url.searchParams.get('refresh')==='1';
  const requested=[...new Set((url.searchParams.get('symbols')??'').toUpperCase().split(',').filter(s=>SYMBOL.test(s)))].slice(0,8);
  const bucket=env.BUCKET;
  const stored=Object.fromEntries(await Promise.all(requested.map(async s=>[s,await readStored(bucket,s).catch(()=>null)])));
  if(!warm&&url.searchParams.get('cached')==='1') {
    const quotes=Object.fromEntries(Object.entries(stored).filter(([,value])=>value));
    return {through,quotes,errors:{},stored:Boolean(bucket)};
  }
  const needs=s=>force||!stored[s]||stored[s].through!==through||now-stored[s].checkedAt>3*3600000;
  const groups=warm?Object.keys(PRODUCTS):[...new Set(requested.filter(needs).map(s=>s.startsWith('SB')?'SB':'W'))];
  const chains=Object.fromEntries(await Promise.all(groups.map(async p=>[p,await chain(p).catch(()=>null)])));
  const symbols=warm?[...new Set([...requested,...Object.values(chains).flatMap(rows=>(rows??[]).slice(0,3).map(([s])=>s))])].slice(0,8):requested;
  const ids=new Map(Object.values(chains).flatMap(rows=>rows??[]));
  const errors={};
  const rows=await Promise.all(symbols.map(async symbol=>{
    const existing=stored[symbol]??(warm?await readStored(bucket,symbol).catch(()=>null):null);
    if(!warm&&!needs(symbol)) return [symbol,existing];
    try {
      const id=ids.get(symbol);
      if(!id) throw new Error('Kontrat ICE listesinde bulunamadı veya veri kaynağına erişilemedi.');
      const json=await ice('data/historical?marketId='+id+'&historicalSpan=1');
      const value=parseHistorical(json.bars,through);
      if(!value) throw new Error('Tarihli kapanış bulunamadı.');
      if(existing&&existing.date>value.date) throw new Error('Kaynak daha eski bir kapanış döndürdü.');
      const current={...value,through,checkedAt:now,marketId:id,source:'ICE tarihsel grafik kapanışı'};
      await writeStored(bucket,symbol,current).catch(()=>{errors[symbol]='Kapanış alındı ancak kayıt yazılamadı.';});
      return [symbol,current];
    } catch(err) {
      errors[symbol]=err.message;
      return [symbol,existing];
    }
  }));
  const quotes=Object.fromEntries(rows.filter(([,quote])=>quote));
  if(warm&&!symbols.length) errors.feed='ICE kontrat listesi alınamadı.';
  return {through,quotes,errors,stored:Boolean(bucket)};
}
