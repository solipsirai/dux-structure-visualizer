export const presets = {
  dux: {title:'DUX', subtitle:'Double up at expiry', description:'Fix one base lot amount each active day. At expiry, the trigger can add a second block based on the original scheduled quantity.', timing:'expiry', koMode:'touch', action:'stop', doubleEqual:false, count:5, prices:[580,610,615,635,665]},
  double: {title:'Double Up', subtitle:'One fixing, variable size', description:'Watch one fixing. The trigger changes how many lots price at the same strike.', timing:'daily', koMode:'none', action:'stop', doubleEqual:true, count:1, prices:[665]},
  parachute: {title:'Parachute', subtitle:'Reset the remaining lots', description:'On a barrier hit, the remaining scheduled base lots price at the reset price. Earlier fixings and extra lots stay booked.', timing:'daily', koMode:'touch', action:'resetRest', doubleEqual:true, count:5, prices:[585,665,545,605,665]},
  ddu: {title:'DDU', subtitle:'Double up at each fixing', description:'At each active fixing, check whether the price triggers extra lots. A barrier hit can end the remaining schedule.', timing:'daily', koMode:'touch', action:'stop', doubleEqual:true, count:5, prices:[580,665,620,655,675]},
  knock: {title:'Knock-Out', subtitle:'Barrier stops new fixings', description:'Fix the base lot amount while the contract is active. A barrier hit stops further lots under this preset.', timing:'none', koMode:'close', action:'stop', doubleEqual:true, count:5, prices:[590,620,545,620,660]},
  parachuteExpiry: {variant:true,title:'Parachute + Double-Up at Expiry', subtitle:'Synthetic corn example', description:'10 fixings, 480 intraday barrier, 495 Parachute and inclusive 520 expiry double-up.', timing:'expiry',koMode:'touch',action:'resetRest',doubleEqual:true,count:10,prices:Array.from({length:10},(_,i)=>i===9?520:501+(i%5)*2),terms:{strike:520,double:520,barrier:480,reset:495,size:5000,factor:.01}},
  closeReset: {variant:true,title:'Daily Close Reset + DDU', subtitle:'Daily reset', description:'A barrier close resets the base price for that fixing.', timing:'daily',koMode:'close',action:'resetDay',doubleEqual:false,count:5,prices:[580,620,548,625,660],terms:{double:600}},
  closeSkip: {variant:true,title:'Daily Close KO + DDU', subtitle:'Skip one fixing', description:'A barrier close skips the fixing. The next qualifying fixing can resume.', timing:'daily',koMode:'close',action:'skip',doubleEqual:true,count:5,prices:[580,620,548,625,660],terms:{double:600}},
  noKo: {variant:true,title:'No-KO Daily Double-Up', subtitle:'Daily multiplier without a barrier', description:'Qualifying fixings add lots throughout the schedule.', timing:'daily',koMode:'none',action:'stop',doubleEqual:true,count:5,prices:[580,665,620,655,675],terms:{double:600}},
  consumer: {variant:true,title:'Consumer Accumulator', subtitle:'Consumer side', description:'Lower prices can increase purchase lots. An upper barrier can stop the schedule.', timing:'daily',koMode:'touch',action:'stop',doubleEqual:true,count:5,prices:[615,585,555,625,640],terms:{side:'buy',double:575,barrier:650,reset:635,doubleDir:'below',barrierDir:'above'}},
  digital: {variant:true,title:'Digital Cash Payoff', subtitle:'One fixing, fixed cash amount', description:'Pays fixed cash per lot at or above the expiry strike.', timing:'none',koMode:'close',action:'skip',doubleEqual:true,count:1,prices:[610],terms:{settlement:'coupon',barrier:600,barrierEqual:false,coupon:250}}

};

export function example(id) {
  const p = presets[id];
  return {...p, prices:[...p.prices], touches:[], side:'sell', settlement:'physical', strike:600, double:650, barrier:550, reset:565, lots:1, multiplier:2, size:50, factor:1, currency:'USD', coupon:100, doubleDir:'above', barrierDir:'below', barrierEqual:true,...p.terms};
}

export function crosses(price, level, direction, equal) {
  if (price === level) return equal;
  return direction === 'above' ? price > level : price < level;
}

export function evaluate(c) {
  let stopped = false;
  let totalLots = 0;
  let totalPayoff = 0;
  const sign = c.side === 'sell' ? -1 : 1;
  const baseSchedule = c.count * c.lots;
  const rows = c.prices.map((price, index) => {
    const day = index + 1;
    const intraday = c.koMode === 'touch' ? c.touches[index] : undefined;
    const wasStopped = stopped;
    const touchHit = intraday != null && crosses(intraday,c.barrier,c.barrierDir,c.barrierEqual);
    const hit = !wasStopped && c.koMode !== 'none' && (touchHit || crosses(price,c.barrier,c.barrierDir,c.barrierEqual));
    let base = 0;
    let extra = 0;
    let level = c.strike;
    let event = 'base';
    if (wasStopped) {
      event = 'ended';
    } else if (hit) {
      event = c.action;
      switch (c.action) {
        case 'stop': stopped = true; break;
        case 'resetRest':
          stopped = true;
          base = (c.count - index) * c.lots;
          level = c.reset;
          break;
        case 'resetDay':
          base = c.lots;
          level = c.reset;
          break;
      }
    } else {
      base = c.lots;
      const doubles = crosses(price,c.double,c.doubleDir,c.doubleEqual);
      if (doubles && c.timing === 'daily') {
        extra = c.lots * (c.multiplier - 1);
        if (extra) event = 'double';
      }
      if (doubles && c.timing === 'expiry' && day === c.count) {
        extra = baseSchedule * (c.multiplier - 1);
        if (extra) event = 'expiry';
      }
    }
    const qty = base + extra;
    const slope = qty && c.settlement !== 'coupon' ? sign * qty : 0;
    const payoff = payoffAtRow(c,{qty,slope,level},price);
    totalLots += qty;
    totalPayoff += payoff;
    return {day, price, intraday, hit, touchHit, wasStopped, stopped, base, extra, qty, level, event, slope, payoff, totalLots, totalPayoff};
  });
  return {rows,totalLots,totalPayoff,baseSchedule,stopped,remaining:stopped ? 0 : Math.max(0,c.count-c.prices.length)*c.lots};
}

export function payoffAtRow(c,row,price) {
  if (!row.qty) return 0;
  return c.settlement === 'coupon' ? row.qty * c.coupon : row.slope * (price - row.level) * c.size * c.factor;
}

export function atPrice(c, index, price) {
  return evaluate({...c,prices:c.prices.map((s,i)=>i===index?price:s)}).rows[index];
}

export function boundaries(c,index) {
  const row = evaluate(c).rows[index];
  if (row.wasStopped || (row.touchHit && row.hit)) return [];
  const levels = [];
  if(c.koMode!=='none') levels.push(c.barrier);
  if(c.timing==='daily' || (c.timing==='expiry' && index+1===c.count)) levels.push(c.double);
  return [...new Set(levels)].sort((a,b)=>a-b);
}

export function intervals(c,index) {
  const limits = boundaries(c,index);
  return Array.from({length:limits.length+1},(_,i)=>{
    const lo=limits[i-1]??-Infinity;
    const hi=limits[i]??Infinity;
    const probe=lo===-Infinity ? (hi===Infinity ? c.prices[index] : hi-Math.max(1,Math.abs(hi)*.1)) :
      hi===Infinity ? lo+Math.max(1,Math.abs(lo)*.1) : (lo+hi)/2;
    return {lo,hi,probe,row:atPrice(c,index,probe)};
  });
}

export function sensitivity(c,index,price) {
  const row=atPrice(c,index,price);
  const levels=boundaries(c,index);
  const i=levels.indexOf(price);
  if(i===-1) return {slope:row.slope,edge:false};
  const ranges=intervals(c,index);
  const left=ranges[i].row;
  const right=ranges[i+1].row;
  const lhs=payoffAtRow(c,left,price);
  const rhs=payoffAtRow(c,right,price);
  return {slope:row.slope,left:left.slope,right:right.slope,jump:Math.abs(lhs-rhs)>1e-8||Math.abs(row.payoff-lhs)>1e-8,edge:left.slope!==right.slope||Math.abs(lhs-rhs)>1e-8||Math.abs(row.payoff-lhs)>1e-8};
}

export function vanilla(c,price,type) {
  const diff=type==='call' ? price-c.strike : c.strike-price;
  return Math.max(diff,0)*c.lots*c.size*c.factor;
}

export const checks = [
  {name:'DUX adds the whole base schedule at expiry', explain:'580 → 610 → 615 → 635 → 665. Four 1-lot fixings, then 6 lots on expiry. Total 10 lots.', run:()=>{const r=evaluate(example('dux'));return r.totalLots===10&&r.rows[4].extra===5&&r.rows[4].payoff===-19500;}},
  {name:'DUX uses the stated equality rule', explain:'An expiry fixing exactly at 650 gives 5 total lots with “strict,” and 10 with “inclusive.”', run:()=>{const c=example('dux');c.prices[4]=650;return evaluate(c).totalLots===5&&evaluate({...c,doubleEqual:true}).totalLots===10;}},
  {name:'Touch cancels the expiry double-up', explain:'A low of 549 before Day 2 close ends the DUX, even though it closes at 610. Only Day 1 stays booked.', run:()=>{const c={...example('dux'),touches:[null,549]};return evaluate(c).totalLots===1&&evaluate({...c,koMode:'close'}).totalLots===10;}},
  {name:'Double Up changes size and payoff', explain:'At 640, 1 lot gives −$2,000. At 660, 2 lots give −$6,000 at 50 MT per lot.', run:()=>{const c=example('double');return atPrice(c,0,640).payoff===-2000&&atPrice(c,0,660).payoff===-6000&&sensitivity(c,0,650).jump;}},
  {name:'DDU doubles only the triggering fixings', explain:'580 → 665 → 620 → 655 → 675 gives 1, 2, 1, 2 and 2 lots. Total 8 lots.', run:()=>{const r=evaluate(example('ddu'));return r.totalLots===8&&r.rows.map(x=>x.qty).join(',')==='1,2,1,2,2';}},
  {name:'Parachute preserves previously booked extra lots', explain:'Day 3 hits the barrier after 1 base lot and a 2-lot day. The 3 remaining base lots reset at 565. Total 6 lots.', run:()=>{const r=evaluate(example('parachute'));return r.totalLots===6&&r.rows[2].qty===3&&r.rows[2].level===565&&r.rows[2].payoff===3000&&r.rows[4].qty===0;}},
  {name:'Close KO can stop or skip', explain:'An inclusive close at 550 stops the example at 2 lots. Switching the action to “Skip this fixing” lets it reach 4 lots.', run:()=>{const c=example('knock');c.prices[2]=550;return evaluate(c).totalLots===2&&evaluate({...c,action:'skip'}).totalLots===4&&evaluate({...c,barrierEqual:false}).totalLots===5;}},
  {name:'Consumer reverses the payoff sign and trigger direction', explain:'A buyer with a lower doubling trigger fixes 2 lots at 600 when the market is 580. At 50 MT per lot the difference is −$2,000.', run:()=>{const c={...example('double'),side:'buy',doubleDir:'below',double:585};const r=atPrice(c,0,580);return r.qty===2&&r.payoff===-2000&&r.slope===2;}},
  {name:'Daily reset and partial schedule', explain:'With five fixings planned and three supplied, reset Day 3 only at 565. Two base lots remain scheduled.', run:()=>{const c={...example('parachute'),prices:[585,665,545],action:'resetDay'};const r=evaluate(c);return r.remaining===2&&r.rows[2].qty===1&&r.rows[2].level===565;}},
  {name:'Unit conversion and vanilla comparison', explain:'A five-cent difference on two 112,000-pound lots is $11,200. A long one-lot call with a 1-cent premium would net $4,480.', run:()=>{const c={...example('double'),size:112000,factor:.01,strike:15,double:18};return atPrice(c,0,20).payoff===-11200&&vanilla(c,20,'call')-c.size*c.factor===4480;}},
  {name:'Fixed coupon has flat regions and a cash jump', explain:'A $100 coupon per participating lot pays $100 at 640 and $200 at 660. The threshold creates a jump.', run:()=>{const c={...example('double'),settlement:'coupon'};return atPrice(c,0,640).payoff===100&&atPrice(c,0,660).payoff===200&&sensitivity(c,0,650).jump&&sensitivity(c,0,640).slope===0;}},
  {name:'Earlier fixing sensitivity ignores later prices', explain:'At Day 1, moving the fixing within an active price region changes the value of 1 lot. The future expiry block is separate.', run:()=>{const c=example('dux');return sensitivity(c,0,610).slope===-1&&sensitivity(c,4,660).slope===-6;}}
];
