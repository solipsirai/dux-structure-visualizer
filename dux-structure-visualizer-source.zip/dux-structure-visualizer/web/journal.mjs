import {objects,tables,csv,download} from './risk-import.mjs';
import {specs,shift,structureValue} from './risk-engine.mjs';
import {optionPoint} from './options-engine.mjs';

const key='commodity-trading-journal-v1', $=id=>document.getElementById(id);
let old={};
try{old=JSON.parse(localStorage.getItem(key))??{};}catch{}
const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const state={asof:shift(today,-1),prior:shift(today,-2),trades:[],accounts:{},markets:{},...old};
const n=['lots','entry','strike','iv','factor','closedLots','exit','realized','lastMark','priorMark','otcMark','otcPrior','dealerDelta','remaining','daily','original','fix','barrier','trigger','reset','multiple','coupon','equity','maintenance','target','broker','other','initial','posted','threshold','independent','mta','last','priorClose'];
const flags=['barrierEqual','doubleEqual'];
const fields=['id','kind','symbol','account','side','lots','openDate','entry','expiry','optionType','style','strike','iv','factor','closedLots','closeDate','exit','realized','lastMark','lastMarkDate','priorMark','priorMarkDate','otcMark','otcPrior','dealerDelta','remaining','daily','original','fix','barrier','trigger','reset','multiple','ko','barrierState','barrierDir','barrierEqual','doubleDir','doubleEqual','timing','action','settlement','coupon','notes'];
const toKey=k=>k.replace(/[A-Z]/g,x=>'_'+x.toLowerCase());
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const vals={kind:['future','option','structure'],side:['long','short'],optionType:['call','put'],style:['us','eu'],ko:['none','close','touch'],barrierState:['alive','unknown','ended'],barrierDir:['above','below'],doubleDir:['above','below'],timing:['none','daily','expiry'],action:['stop','skip','resetDay','resetRest'],settlement:['physical','cash','coupon'],barrierEqual:['true','false'],doubleEqual:['true','false']};
const fmt=v=>Number.isFinite(v)?v.toLocaleString('en-US',{maximumFractionDigits:4}):'—';
const message=s=>{$('status').textContent=s;};
const validate=t=>t.id&&['future','option','structure'].includes(t.kind)&&t.symbol&&t.account&&vals.side.includes(t.side)&&t.lots>0&&/^\d{4}-\d\d-\d\d$/.test(t.openDate)&&(!t.closedLots||t.closedLots>0&&t.closedLots<=t.lots&&t.closeDate>=t.openDate);
function save(){try{localStorage.setItem(key,JSON.stringify(state));}catch{message('Browser storage is full. Export trades before leaving.');}render();}
const open=t=>t.openDate>state.asof?0:Math.max(0,t.lots-(t.closeDate&&t.closeDate<=state.asof?t.closedLots??0:0));
function value(t){
  const q=open(t), m=state.markets[t.symbol]??{}, last=m.lastDate===state.asof?m.last:null, prior=m.priorDate===state.prior?m.prior:null;
  const factor=t.factor??m.factor??specs[/^([A-Z]+)[A-Z]\d\d$/.exec(t.symbol)?.[1]]?.[1];
  const sign=t.side==='short'?-1:1;
  let delta=q===0?0:null, move=null;
  if(t.kind==='future'){
    delta=q*sign;
    if(Number.isFinite(last)&&Number.isFinite(prior)&&factor)move=(last-prior)*delta*factor;
  }
  if(t.kind==='option'&&q&&last>0&&t.expiry>=state.asof&&t.strike>0&&t.iv>0){
    const leg={...t,type:t.optionType};
    delta=optionPoint(leg,last,state.asof,.04).delta*q*sign;
    if(prior>0&&factor)move=(optionPoint(leg,last,state.asof,.04).price-optionPoint(leg,prior,state.prior,.04).price)*q*sign*factor;
    if(factor&&t.lastMarkDate===state.asof&&t.priorMarkDate===state.prior&&Number.isFinite(t.lastMark)&&Number.isFinite(t.priorMark))move=(t.lastMark-t.priorMark)*q*sign*factor;
  }
  if(t.kind==='structure'&&q){
    if(t.lastMarkDate===state.asof&&Number.isFinite(t.dealerDelta))delta=t.dealerDelta;
    else if(last>0&&factor){const h=last*.005,a=structureValue({...t,factor},last+h,state.asof,.04),b=structureValue({...t,factor},last-h,state.asof,.04);if(a!=null&&b!=null)delta=(a-b)/(2*h*factor);}
    if(t.lastMarkDate===state.asof&&t.priorMarkDate===state.prior&&Number.isFinite(t.otcMark)&&Number.isFinite(t.otcPrior))move=t.otcMark-t.otcPrior;
  }
  const realized=t.closeDate&&t.closeDate<=state.asof?t.realized??(t.kind!=='structure'&&factor&&Number.isFinite(t.entry)&&Number.isFinite(t.exit)?(t.exit-t.entry)*t.closedLots*factor*sign:null):null;
  if(t.openDate>state.prior||t.closeDate>state.prior&&t.closeDate<=state.asof){
    const base=t.openDate>state.prior?t.entry:t.kind==='future'?prior:t.priorMarkDate===state.prior?t.priorMark:null;
    const end=t.kind==='future'?last:t.lastMarkDate===state.asof?t.lastMark:null;
    const closed=t.closeDate>state.prior&&t.closeDate<=state.asof?t.closedLots??0:0;
    move=t.kind!=='structure'&&factor&&Number.isFinite(base)&&(!q||Number.isFinite(end))&&(!closed||Number.isFinite(t.exit))?
      ((q?q*(end-base):0)+(closed?closed*(t.exit-base):0))*sign*factor:null;
  }
  return {delta,move,realized};
}
function render(){
  $('date').value=state.asof;$('prior').value=state.prior;
  const filter=$('filter').value;
  const rows=state.trades.filter(t=>filter==='all'||(filter==='open'?open(t)>0:t.closeDate&&t.closeDate<=state.asof&&open(t)===0));
  $('detail').innerHTML='<table><thead><tr><th>Trade</th><th>Instrument</th><th>Contract</th><th>Account</th><th>Open lots</th><th>Delta lots</th><th>Session P/L USD</th><th>Realized P/L USD</th><th></th></tr></thead><tbody>'+rows.map(t=>{
    const a=value(t);
    return '<tr>'+[t.id,t.kind,t.symbol,t.account,fmt(open(t)),fmt(a.delta),fmt(a.move),fmt(a.realized)].map(v=>'<td>'+escape(v)+'</td>').join('')+'<td><button data-trade="'+escape(t.id)+'">Details / edit</button></td></tr>';
  }).join('')+'</tbody></table>';
  const accountNames=[...new Set([...Object.keys(state.accounts),...state.trades.map(t=>(t.kind==='structure'?'otc|':'listed|')+t.account)])];
  $('accounts').innerHTML=accountNames.map(k=>'<p>'+escape(k)+' <button data-account="'+escape(k)+'">Edit inputs</button></p>').join('');
  $('markets').innerHTML=Object.entries(state.markets).map(([k,v])=>'<p>'+escape(k)+' · '+escape(fmt(v.last))+' · '+escape(v.lastDate)+' <button data-market="'+escape(k)+'">Edit marks</button></p>').join('');
}
function editor(title,keys,data,commit){
  $('title').textContent=title;
  $('fields').innerHTML=keys.map(k=>{
    const value=data[k]??'';
    const label=k.replace(/([A-Z])/g,' $1').replace(/^./,x=>x.toUpperCase());
    const attr='name="'+k+'"';
    const field=vals[k]?'<select '+attr+'><option value="">Select</option>'+vals[k].map(v=>'<option '+(String(value)===v?'selected':'')+'>'+v+'</option>').join('')+'</select>':
      k==='notes'?'<textarea '+attr+'>'+escape(value)+'</textarea>':'<input '+attr+' type="'+(n.includes(k)?'number':/Date$|^(expiry|asof|prior)$/.test(k)?'date':'text')+'" step="any" value="'+escape(value)+'">';
    return '<label>'+label+field+'</label>';
  }).join('');
  $('edit').onsubmit=e=>{
    e.preventDefault();
    const entry={...data};
    for(const [k,v] of new FormData(e.target))entry[k]=v===''?null:n.includes(k)?Number(v):flags.includes(k)?v==='true':v;
    if(!commit(entry))return;
    $('editor').close();save();
  };
  $('editor').showModal();
}
function trade(id){
  const old=state.trades.find(t=>t.id===id);
  editor(old?'Trade details':'New position',fields,old??{openDate:state.asof,kind:'future',side:'long'},t=>{
    t.symbol=t.symbol?.toUpperCase().trim().replace(/^C[_ -]?([A-Z]\d\d)$/,'ZC$1');
    if(!validate(t)||state.trades.some(r=>r.id===t.id&&r!==old)){alert('Check the trade ID, instrument, contract, account, side, dates and lot quantities.');return false;}
    if(old)state.trades[state.trades.indexOf(old)]=t;else state.trades.push(t);
    return true;
  });
}
function account(id=''){
  editor('Dated margin inputs',['accountKey','asof','prior','equity','initial','maintenance','target','broker','other','threshold','posted','independent','mta'],{asof:state.asof,prior:state.prior,...state.accounts[id],accountKey:id},x=>{
    if(!/^(listed|otc)\|.+/.test(x.accountKey??'')){alert('Use listed|Account name or otc|Netting set name.');return false;}
    state.accounts[x.accountKey]=x;return true;
  });
}
function marks(id=''){
  const old=state.markets[id]??{};
  editor('Closing marks',['symbol','last','lastDate','priorClose','priorDate','factor','source'],{symbol:id,lastDate:state.asof,priorDate:state.prior,...old,priorClose:old.prior},x=>{
    if(!x.symbol){alert('Enter the futures contract symbol.');return false;}
    state.markets[x.symbol.toUpperCase()]={...x,prior:x.priorClose};return true;
  });
}
$('new').onclick=()=>trade();$('new-account').onclick=()=>account();$('new-market').onclick=()=>marks();$('cancel').onclick=()=>$('editor').close();
document.addEventListener('click',e=>{const d=e.target.dataset;if(d.trade)trade(d.trade);if(d.account)account(d.account);if(d.market)marks(d.market);});
$('filter').onchange=render;
$('date').onchange=e=>{state.asof=e.target.value;save();};
$('prior').onchange=e=>{state.prior=e.target.value;save();};
$('template').onclick=()=>download(fields.map(toKey).join(',')+'\n','trade-journal-template.csv');
$('export').onclick=()=>download(csv(state.trades.map(t=>Object.fromEntries(Object.entries(t).map(([k,v])=>[toKey(k),v])))),'trade-journal.csv');
$('upload').onchange=async e=>{
  try{
    const rows=(await tables(e.target.files[0])).flatMap(objects).filter(r=>r.id);
    const incoming=new Map();
    let rejected=0;
    for(const row of rows){
      const t={};
      for(const k of fields){const v=row[toKey(k)];if(v!=null&&v!=='')t[k]=n.includes(k)?Number(v):flags.includes(k)?v.toLowerCase()==='true':v;}
      t.symbol=t.symbol?.toUpperCase();
      if(validate(t))incoming.set(t.id,t);else rejected++;
    }
    if(!incoming.size)throw Error('No valid trade rows. Use the template headings.');
    for(const t of state.trades){if(incoming.has(t.id)){incoming.set(t.id,{...t,...incoming.get(t.id)});}else incoming.set(t.id,t);}
    state.trades=[...incoming.values()];save();message(rows.length-rejected+' rows imported · '+rejected+' rejected.');
  }catch(error){message(error.message);}finally{e.target.value='';}
};
render();

$('ice-marks').onclick=async()=>{
  const symbols=[...new Set(state.trades.map(t=>t.symbol).filter(s=>/^(SB[FHKNV]|W[HKQVZ])\d\d$/.test(s)))];
  if(!symbols.length){message('Add an ICE sugar trade to retrieve closing marks.');return;}
  $('ice-marks').disabled=true;
  try {
    const batches=Array.from({length:Math.ceil(symbols.length/8)},(_,i)=>symbols.slice(i*8,i*8+8));
    const results=await Promise.all(batches.map(async batch=>{
      const res=await fetch('./api/market/settlements?symbols='+encodeURIComponent(batch.join(',')));
      if(!res.ok)throw Error('ICE close request failed.');
      return (await res.json()).quotes;
    }));
    const quotes=Object.entries(Object.assign({},...results)).filter(([,q])=>q.date&&Number.isFinite(q.close));
    let updated=0;
    for(const [symbol,q] of quotes){
      const previous=state.markets[symbol];
      if(previous?.lastDate>q.date||previous?.lastDate===q.date&&previous.source!=='ICE historical close')continue;
      state.markets[symbol]={...previous,last:q.close,lastDate:q.date,prior:q.previous,priorDate:q.previousDate,source:'ICE historical close'};
      updated++;
    }
    save();
    message(updated+' ICE contracts updated. Select the matching valuation and prior session dates to use these marks.');
  } catch(error){message(error.message);}finally{$('ice-marks').disabled=false;}
};
