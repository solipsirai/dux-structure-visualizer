export const webgl=()=>{try{return Boolean(document.createElement('canvas').getContext('webgl'));}catch{return false;}};

export function drawSurface(container,traces,labels,dark,onPick,view){
  const canvas=document.createElement('canvas');
  canvas.style.cssText='width:100%;height:100%;display:block;touch-action:none';
  canvas.tabIndex=0;
  canvas.setAttribute('aria-label','3D chart. Drag to rotate, scroll to zoom, or use arrow keys.');
  const tip=document.createElement('div');tip.className='surface-tip';tip.hidden=true;
  container.replaceChildren(canvas,tip);container.style.position='relative';
  const context=canvas.getContext('2d');
  const polygons=[],points=[];
  const p=(x,y,z,meta)=>({x,y,z,meta});
  for(const t of traces){
    if(t.type==='surface'){
      const data=t.y.map((y,i)=>t.x.map((x,j)=>p(x,y,t.z[i]?.[j],t.customdata?.[i]?.[j])));
      for(let i=0;i<data.length;i++)for(let j=0;j<data[i].length;j++){
        const a=data[i][j];if(Number.isFinite(a.z))points.push(a);
        if(i&&j){
          const face=[data[i-1][j-1],data[i-1][j],a,data[i][j-1]];
          if(face.every(v=>Number.isFinite(v.z)))polygons.push({face});
        }
      }
    } else if(t.type==='mesh3d'){
      const data=t.x.map((x,i)=>p(x,t.y[i],t.z[i],t.customdata?.[i]));
      points.push(...data.filter(a=>a.z!==0));
      for(let i=0;i<t.i.length;i++)polygons.push({face:[data[t.i[i]],data[t.j[i]],data[t.k[i]]],color:t.facecolor[i]});
    } else if(t.type==='scatter3d')points.push(...t.x.map((x,i)=>({...p(x,t.y[i],t.z[i],t.customdata?.[i]),highlight:true})));
  }
  if(!points.length){container.textContent='No plottable values for this selection.';return null;}
  const bounds=['x','y','z'].map(k=>{
    let lo=Infinity,hi=-Infinity;
    for(const v of points){lo=Math.min(lo,v[k]);hi=Math.max(hi,v[k]);}
    if(k==='z'&&traces.some(t=>t.type==='mesh3d')){lo=Math.min(lo,0);hi=Math.max(hi,0);}
    return [lo,hi===lo?lo+1:hi];
  });
  const color=z=>{
    const scale=Math.max(Math.abs(bounds[2][0]),Math.abs(bounds[2][1]),1e-12);
    return z<0?'rgba(182,72,69,'+(.48+.45*Math.min(1,Math.abs(z)/scale))+')':'rgba(35,132,90,'+(.48+.45*Math.min(1,z/scale))+')';
  };
  const number=x=>x.toLocaleString('en-US',{maximumFractionDigits:3});
  let mapped=[], drag=null;
  function paint(){
    const w=container.clientWidth,h=container.clientHeight,dpr=Math.min(2,devicePixelRatio||1);
    canvas.width=w*dpr;canvas.height=h*dpr;context.setTransform(dpr,0,0,dpr,0,0);
    const ink=dark?'#e3ece6':'#25362b',grid=dark?'#607268':'#a0aa9d';
    context.fillStyle=dark?'#18231f':'#fffefa';context.fillRect(0,0,w,h);
    const scale=Math.min(w,h)*.28*view.zoom;
    const ca=Math.cos(view.az),sa=Math.sin(view.az),cb=Math.cos(view.tilt),sb=Math.sin(view.tilt);
    function project(v){
      const [x,y,z]=['x','y','z'].map((k,i)=>2*(v[k]-bounds[i][0])/(bounds[i][1]-bounds[i][0])-1);
      const u=x*ca-y*sa, t=x*sa+y*ca;
      return {sx:w*.5+u*scale,sy:h*.51+(t*sb-z*cb)*scale,depth:t*cb+z*sb,...v};
    }
    function segment(a,b){context.beginPath();context.moveTo(a.sx,a.sy);context.lineTo(b.sx,b.sy);context.stroke();}
    const [a,b,c]=bounds.map(([v])=>v);
    const base=p(a,b,c);
    context.strokeStyle=grid;context.lineWidth=1;
    for(let i=0;i<=4;i++){
      const x=a+(bounds[0][1]-a)*i/4,y=b+(bounds[1][1]-b)*i/4;
      segment(project(p(x,b,c)),project(p(x,bounds[1][1],c)));
      segment(project(p(a,y,c)),project(p(bounds[0][1],y,c)));
    }
    const faces=polygons.map(o=>({...o,projected:o.face.map(project)})).sort((a,b)=>a.projected.reduce((n,x)=>n+x.depth,0)/a.projected.length-b.projected.reduce((n,x)=>n+x.depth,0)/b.projected.length);
    for(const o of faces){
      context.beginPath();
      for(let i=0;i<o.projected.length;i++){const a=o.projected[i];if(i)context.lineTo(a.sx,a.sy);else context.moveTo(a.sx,a.sy);}
      context.closePath();context.fillStyle=o.color??color(o.face.reduce((n,v)=>n+v.z,0)/o.face.length);context.fill();
      context.strokeStyle=dark?'#253d35aa':'#ffffff9a';context.stroke();
    }
    mapped=points.map(project);
    for(const p of mapped){
      context.fillStyle=p.highlight?'#f0a154':color(p.z);context.beginPath();context.arc(p.sx,p.sy,p.highlight?4:2,0,2*Math.PI);context.fill();
    }
    context.strokeStyle=grid;context.fillStyle=ink;context.font='12px system-ui';
    labels.forEach((label,i)=>{
      const key=['x','y','z'][i];const end=project({...base,[key]:bounds[i][1]});
      segment(project(base),end);
      context.fillText(label,Math.max(5,Math.min(w-context.measureText(label).width-5,end.sx+7)),Math.max(15,Math.min(h-6,end.sy+13)));
      for(const k of [.25,.5,.75]){
        const v=bounds[i][0]+k*(bounds[i][1]-bounds[i][0]);
        const q=project({...base,[key]:v});context.fillText(number(v),q.sx+4,q.sy+(i===2?0:12));
      }
    });
  }
  const resize=new ResizeObserver(paint);resize.observe(container);
  canvas.onpointerdown=e=>{drag={x:e.clientX,y:e.clientY,moved:false};canvas.setPointerCapture(e.pointerId);};
  const nearest=e=>{const b=canvas.getBoundingClientRect(),x=e.clientX-b.left,y=e.clientY-b.top;let best=null,d=144;for(const p of mapped){const q=(p.sx-x)**2+(p.sy-y)**2;if(q<d){best=p;d=q;}}return best;};
  canvas.onpointermove=e=>{
    if(drag){view.az+=(e.clientX-drag.x)*.012;view.tilt=Math.max(-1.5,Math.min(1.5,view.tilt+(e.clientY-drag.y)*.01));drag={x:e.clientX,y:e.clientY,moved:true};tip.hidden=true;paint();return;}
    const a=nearest(e);tip.hidden=!a;
    if(a){tip.textContent=labels[0]+' '+number(a.meta?.[0]??a.x)+' · '+(a.meta?.[1]??number(a.y))+' · '+number(a.z);tip.style.left=Math.min(container.clientWidth-215,Math.max(0,a.sx+8))+'px';tip.style.top=Math.max(0,a.sy-36)+'px';}
  };
  canvas.onpointerup=e=>{const was=drag;drag=null;if(!was?.moved){const a=nearest(e);if(a?.meta)onPick(...a.meta);}};
  canvas.onpointercancel=()=>{drag=null;};
  canvas.onpointerleave=()=>{tip.hidden=true;};
  canvas.addEventListener('wheel',e=>{e.preventDefault();view.zoom=Math.max(.35,Math.min(2.5,view.zoom*Math.exp(-e.deltaY*.001)));paint();},{passive:false});
  canvas.onkeydown=e=>{
    const axes={ArrowLeft:['az',-.16],ArrowRight:['az',.16],ArrowUp:['tilt',.1],ArrowDown:['tilt',-.1],'+':['zoom',.1],'-':['zoom',-.1]};
    if(!axes[e.key])return;
    e.preventDefault();const [key,n]=axes[e.key];view[key]+=n;view.tilt=Math.max(-1.5,Math.min(1.5,view.tilt));view.zoom=Math.max(.35,Math.min(2.5,view.zoom));paint();
  };
  paint();
  return {canvas,stop:()=>resize.disconnect()};
}
