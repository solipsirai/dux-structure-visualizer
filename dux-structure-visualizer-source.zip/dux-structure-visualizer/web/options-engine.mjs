const DAY = 86400000;
const Y = 365;
const pdf = x => Math.exp(-x*x/2)/Math.sqrt(2*Math.PI);

export const products = {
  SB:{name:'NY Sugar No. 11', factor:1120, unit:'¢/lb', defaultMonth:'SBH27'},
  W:{name:'London White Sugar No. 5', factor:50, unit:'USD/MT', defaultMonth:'WH27'},
  ZC:{name:'CBOT Corn',factor:50,unit:'¢/bu',defaultMonth:'ZCZ26'},
  OTHER:{name:'Custom contract',factor:1,unit:'price point',defaultMonth:'OTHER'}
};

export function daysBetween(asof, expiry) {
  return (Date.parse(expiry+'T00:00:00Z')-Date.parse(asof+'T00:00:00Z'))/DAY;
}
export const intrinsic = (type,f,k) => Math.max(type==='call'?f-k:k-f,0);

function cdf(x) {
  const t=1/(1+.2316419*Math.abs(x));
  const tail=pdf(x)*t*(.319381530+t*(-.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))));
  return x<0?tail:1-tail;
}

function black(type,f,k,vol,rate,t) {
  const sign=type==='call'?1:-1;
  const std=vol*Math.sqrt(t);
  const d1=(Math.log(f/k)+std*std/2)/std;
  const d2=d1-std;
  const disc=Math.exp(-rate*t);
  const price=Math.max(0,disc*sign*(f*cdf(sign*d1)-k*cdf(sign*d2)));
  return {price,delta:disc*sign*cdf(sign*d1),gamma:disc*pdf(d1)/(f*std),vega:disc*f*pdf(d1)*Math.sqrt(t)/100,rho:-t*price/100};
}

function tree(type,f,k,vol,rate,t,steps) {
  const dt=t/steps;
  const logU=vol*Math.sqrt(dt);
  const prob=1/(1+Math.exp(logU));
  const disc=Math.exp(-rate*dt);
  const values=new Float64Array(steps+1);
  for(let j=0;j<=steps;j++) values[j]=intrinsic(type,f*Math.exp((2*j-steps)*logU),k);
  let upDelta=0,downDelta=0,delta=0;
  for(let i=steps-1;i>=0;i--) {
    for(let j=0;j<=i;j++) {
      const futures=f*Math.exp((2*j-i)*logU);
      values[j]=Math.max(intrinsic(type,futures,k),disc*(prob*values[j+1]+(1-prob)*values[j]));
    }
    if(i===2) {
      upDelta=(values[2]-values[1])/(f*Math.expm1(2*logU));
      downDelta=(values[1]-values[0])/(-f*Math.expm1(-2*logU));
    }
    if(i===1) delta=(values[1]-values[0])/(2*f*Math.sinh(logU));
  }
  return {price:values[0],delta,gamma:(upDelta-downDelta)/(f*Math.sinh(2*logU))};
}

function american(type,f,k,vol,rate,t,steps) {
  const a=tree(type,f,k,vol,rate,t,steps);
  const b=tree(type,f,k,vol,rate,t,steps+1);
  return {price:(a.price+b.price)/2,delta:(a.delta+b.delta)/2,gamma:(a.gamma+b.gamma)/2};
}

export function optionValue(leg,f,asof,rate,vol=leg.iv/100,steps=100) {
  const t=daysBetween(asof,leg.expiry)/Y;
  if(t<=0) return intrinsic(leg.type,f,leg.strike);
  const method=leg.style==='us'?american:black;
  return method(leg.type,f,leg.strike,vol,rate,t,steps).price;
}

export function greeks(leg,f,asof,rate) {
  const d=daysBetween(asof,leg.expiry);
  const t=d/Y, vol=leg.iv/100;
  if(t<=0) {
    const sign=leg.type==='call'?1:-1;
    return {price:intrinsic(leg.type,f,leg.strike),delta:sign*(f-leg.strike)>0?sign:0,gamma:0,theta:0,vega:0,rho:0,atStrike:f===leg.strike};
  }
  const method=leg.style==='us'?american:black;
  const price=(v,r,tt)=>tt<=0?intrinsic(leg.type,f,leg.strike):method(leg.type,f,leg.strike,v,r,tt,200).price;
  const result=method(leg.type,f,leg.strike,vol,rate,t,200);
  const theta=price(vol,rate,(d-1)/Y)-result.price;
  if(leg.style!=='us') return {...result,theta};
  const volBump=Math.min(.005,vol/2);
  const rateBump=.005;
  return {...result,theta,vega:(price(vol+volBump,rate,t)-price(vol-volBump,rate,t))*.01/(2*volBump),rho:(price(vol,rate+rateBump,t)-price(vol,rate-rateBump,t))*.01/(2*rateBump)};
}

export function marginCall(equity,movement,maintenance,target,other=0) {
  const adjusted=equity+movement+other;
  return {adjusted,shortfall:Math.max(0,maintenance-adjusted),call:adjusted<maintenance?Math.max(0,target-adjusted):0};
}

export function collateralCall(mtm,threshold,posted,independent,minTransfer) {
  const required=Math.max(0,-mtm+independent-threshold);
  const uncovered=Math.max(0,required-posted);
  return {required,uncovered,call:uncovered>=minTransfer?uncovered:0};
}

export function optionBook(legs,market,asof,rate) {
  return legs.map(leg=>{
    const m=market[leg.contract];
    const g=greeks(leg,m.close,asof,rate);
    const mult=leg.lots*(leg.side==='long'?1:-1);
    const cash=mult*m.factor;
    const marked=leg.mark??g.price;
    return {...leg,...g,marked,mult,cash,deltaLots:g.delta*mult,gammaLots:g.gamma*mult,
      thetaCash:g.theta*cash,vegaCash:g.vega*cash,rhoCash:g.rho*cash,mtm:marked*cash,
      pl:(marked-leg.premium)*cash};
  });
}

export function marketMove(book,market,asof,previousDate,rate) {
  if(!previousDate || previousDate>=asof) return null;
  let value=0;
  let modelled=false;
  for(const leg of book) {
    const m=market[leg.contract];
    if(leg.mark!=null&&leg.previousMark!=null) {
      value+=(leg.mark-leg.previousMark)*leg.cash;
      continue;
    }
    if(!(m.previous>0)||leg.expiry<=asof) return null;
    modelled=true;
    // Compare model with model so that a broker mark and a model level are never mixed.
    value+=(leg.price-optionValue(leg,m.previous,previousDate,rate,(leg.previousIV??leg.iv)/100,200))*leg.cash;
  }
  return {value,modelled};
}

export function shockValue(book,market,asof,rate,pricePct,volPoints=0,mode='theory',steps=56) {
  return book.reduce((total,leg)=>{
    const m=market[leg.contract];
    const f=m.close*(1+pricePct/100);
    const v=Math.max(.0001,(leg.iv+volPoints)/100);
    if(mode==='expiry') return total+(intrinsic(leg.type,f,leg.strike)-leg.premium)*leg.cash;
    const reference=steps===200?leg.price:optionValue(leg,m.close,asof,rate,leg.iv/100,steps);
    const movement=optionValue(leg,f,asof,rate,v,steps)-reference;
    return total+(mode==='stress'?movement:(leg.marked-leg.premium+movement))*leg.cash;
  },0);
}

export function optionPoint(leg,f,asof,rate,steps=80) {
  const t=daysBetween(asof,leg.expiry)/365;
  if(t<=0) {
    const sign=leg.type==='call'?1:-1;
    return {price:intrinsic(leg.type,f,leg.strike),delta:sign*(f-leg.strike)>0?sign:0,gamma:0};
  }
  return (leg.style==='us'?american:black)(leg.type,f,leg.strike,leg.iv/100,rate,t,steps);
}
