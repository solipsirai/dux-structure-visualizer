import {knownSum,historyChange,profileRoots,hedgeRoll,portfolioGamma,gammaByExpiry} from './gex-engine.mjs';
import {webgl,drawSurface} from './canvas-surface.mjs';
import {specs,normalize,demo,headers,market,group,flips,series,sum,advanced,diagnostics,scenario,stressedCalls,shift,structureValue} from './risk-engine.mjs';
import {tables,objects,csv,excel,download} from './risk-import.mjs';
import {daysBetween,optionPoint,intrinsic} from './options-engine.mjs';

const $=x=>document.getElementById(x);
const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}};
const save=(key,data)=>{try{localStorage.setItem(key,JSON.stringify(data));return true;}catch{return false;}};
const escape=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=x=>Number.isFinite(x)?x.toLocaleString('en-US',{maximumFractionDigits:4}):x??'—';
const labels={overview:'GEX Overview',strike:'GEX by Strike',profile:'Gamma Exposure Profile',walls:'Call / Put Walls',heat:'GEX Heatmap',history:'Historical GEX Changes',hedge:'Dealer Hedging Simulator',gex:'3D GEX Surface',pgamma:'Portfolio Gamma',iv:'3D Volatility Surface',greeks:'3D Greeks Surface',portfolio:'Portfolio Risk Surface',margin:'Margin Stress Surface',vol:'Volatility Analytics'};
const greeksLabels={delta:'Delta · futures lots',gamma:'Gamma · lots per price point',theta:'Theta · USD/day',vega:'Vega · USD/vol point',rho:'Rho · USD/rate point',vanna:'Vanna · delta lots/vol point',charm:'Charm · delta lots/day',vomma:'Vomma · USD/vol point²'};
const metricLabels={net:'Net GEX',dealer:'Estimated Dealer Gamma · lots/point',absolute:'Absolute GEX',call:'Call GEX',put:'Put GEX',oi:'Open interest',gamma:'Mean gamma per contract',lots:'Futures-equivalent GEX'};
const initial={commodity:'SB',contract:'',date:'',expiry:'all',type:'all',position:'long',call:25,put:-25,rate:4,range:20,days:0,vol:0,shock:3,metric:'net',surface:'surface',coordinate:'strike',greek:'gamma',size:1,side:'long',book:'journal',scope:'contract',rateShock:0,crossShock:1,trade:'all',comparison:'previous',historyMetric:'Net GEX USD',wallView:'strike',focusPortfolio:false,dark:false,tab:'overview',focus:null};
let c={...initial,...read('dux-risk-preferences',{})};
let imported=read('dux-chain-v1',[]);
let demonstration=!imported.length;
let demoData;
let exported=[];
let revision=0;
let note='';
let playback=null;
const palette=[[0,'#b34546'],[.499,'#c8a7a0'],[.501,'#a1bcab'],[1,'#267653']];
const plot=$('plot');
const gpu=webgl();
const camera={az:-.58,tilt:.52,zoom:1};
let fallback=null;
const settlementKey=r=>[r.date,r.commodity,r.contract,r.expiry,r.strike,r.type].join('|');
const uniq=(rows,key)=>[...new Set(rows.map(r=>r[key]))].sort((a,b)=>typeof a==='number'?a-b:String(a).localeCompare(String(b)));
const selected=()=>demonstration?(demoData??=demo()):imported;
function status(s,warn=false){$('status').textContent=s;$('status').dataset.warn=warn;}
const select=(id,label,values)=>'<label>'+label+'<select data-key="'+id+'">'+values.map(v=>{const [k,l]=Array.isArray(v)?v:[v,v];return '<option value="'+escape(k)+'" '+(String(c[id])===String(k)?'selected':'')+'>'+escape(l)+'</option>';}).join('')+'</select></label>';
const input=(key,label,min,max,step=1)=>'<label>'+label+'<input type="number" data-key="'+key+'" min="'+min+'" max="'+max+'" step="'+step+'" value="'+escape(c[key])+'"></label>';
const tiles=values=>{$('kpis').innerHTML=values.map(([k,v])=>'<div class="risk-kpi"><small>'+escape(k)+'</small><strong>'+escape(fmt(v))+'</strong></div>').join('');};
function table(rows,saveRows=true){
  if(saveRows)exported=rows;
  const keys=[...new Set(rows.flatMap(Object.keys))];
  $('detail').innerHTML=keys.length?'<table><thead><tr>'+keys.map(k=>'<th>'+escape(k)+'</th>').join('')+'</tr></thead><tbody>'+rows.slice(0,100).map(r=>'<tr>'+keys.map(k=>'<td>'+escape(fmt(r[k]))+'</td>').join('')+'</tr>').join('')+'</tbody></table>':'';
}
const item=(r)=>({Strike:r.strike,Expiry:r.expiry,Type:r.type,OI:r.oi,'IV %':r.iv,'IV source':r.ivSource,Delta:r.delta,Gamma:r.gamma,'Estimated GEX USD':r.exposure});
function focus(k,e){
  if(!Number.isFinite(k))return;
  c.focus={strike:k,expiry:e??null};save('dux-risk-preferences',c);
  if(['heat','gex','strike','walls','iv','vol','greeks'].includes(c.tab))render();
}
function graph(data,x,y,z,extra={}){
  if(fallback){fallback.stop();fallback=null;plot.replaceChildren();}
  if(z&&!gpu){
    if(plot._fullLayout)globalThis.Plotly?.purge(plot);
    fallback=drawSurface(plot,data,[x,y,z],c.dark,focus,camera);
    return;
  }
  if(!globalThis.Plotly){status('Chart library could not load. Tables and downloads remain available.',true);return;}
  const dark=c.dark,bg=dark?'#18231f':'#fffefa',ink=dark?'#ebf2ec':'#26322a',grid=dark?'#334139':'#e5e6db';
  const axis=title=>({title,gridcolor:grid,zerolinecolor:grid,automargin:true});
  const layout={margin:{l:72,r:55,t:36,b:54},paper_bgcolor:bg,plot_bgcolor:bg,font:{color:ink},uirevision:c.tab+'|'+c.contract,
    xaxis:axis(x),yaxis:axis(y),legend:{orientation:'h'},...(z?{scene:{xaxis:axis(x),yaxis:axis(y),zaxis:axis(z),bgcolor:bg}}:{}),...extra};
  Plotly.react(plot,data,layout,{responsive:true,displaylogo:false,scrollZoom:true,toImageButtonOptions:{format:'png',filename:'dux-'+c.tab}}).then(()=>{
    plot.removeAllListeners('plotly_click');
    plot.on('plotly_click',event=>{
      const p=event.points[0];
      if(Array.isArray(p.customdata)&&Number.isFinite(p.customdata[0]))focus(p.customdata[0],p.customdata[1]);
      else if(['heat','strike','walls','gex','vol'].includes(c.tab))focus(Number(p.x),typeof p.y==='string'?p.y:null);
    });
  }).catch(()=>status('This chart could not render. Tabular results are still available.',true));
}
const line=(x,y,name,extra={})=>({type:'scatter',mode:'lines+markers',x,y,name,...extra});
const marker=(x,label,color)=>({type:'line',xref:'x',yref:'paper',x0:x,x1:x,y0:0,y1:1,line:{color,dash:'dot',width:1.5},label:{text:label,textposition:'end'}});
const surface=(x,y,z,extra={})=>({type:'surface',x,y,z,colorscale:palette,connectgaps:false,showscale:true,...extra});
function bars3d(cells){
  const x=[],y=[],z=[],i=[],j=[],k=[],facecolor=[],customdata=[];
  const width=cells.length?Math.min(...uniq(cells,'strike').slice(1).map((v,n)=>v-uniq(cells,'strike')[n]).filter(v=>v>0),Infinity):Infinity;
  for(const cell of cells){
    if(cell.v==null)continue;
    const n=x.length,a=Number.isFinite(width)?width*.27:cell.strike*.007;
    x.push(cell.strike-a,cell.strike+a,cell.strike+a,cell.strike-a,cell.strike-a,cell.strike+a,cell.strike+a,cell.strike-a);
    y.push(cell.dte-1,cell.dte-1,cell.dte+1,cell.dte+1,cell.dte-1,cell.dte-1,cell.dte+1,cell.dte+1);
    z.push(0,0,0,0,cell.v,cell.v,cell.v,cell.v);
    customdata.push(...Array.from({length:8},()=>[cell.strike,cell.expiry]));
    for(const [u,v,w] of [[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7],[4,5,6],[4,6,7]]){
      i.push(n+u);j.push(n+v);k.push(n+w);facecolor.push(cell.v>=0?'#278c60':'#bd4a4a');
    }
  }
  return {type:'mesh3d',x,y,z,i,j,k,facecolor,customdata,hovertemplate:'Strike %{customdata[0]}<br>Expiry %{customdata[1]}<br>Value %{z:,.3f}<extra></extra>'};
}
function gexValue(rows,metric){
  const known=rows.filter(r=>r.exposure!=null);
  if(metric==='oi')return rows.some(r=>r.oi!=null)?sum(rows,r=>r.oi??0):null;
  if(metric==='gamma')return rows.length?sum(rows,r=>r.gamma)/rows.length:null;
  if(!known.length)return null;
  return sum(known,r=>metric==='absolute'?Math.abs(r.exposure):metric==='call'||metric==='put'?r.type===metric?r.exposure:0:metric==='lots'?r.equivalent:metric==='dealer'?r.gamma*r.lots:r.exposure);
}
function concentrations(priced){
  const strikes=group(priced,'strike').map(([strike,rs])=>({strike,net:gexValue(rs,'net'),abs:gexValue(rs,'absolute'),calls:gexValue(rs.filter(r=>r.type==='call'),'oi'),puts:gexValue(rs.filter(r=>r.type==='put'),'oi')}));
  const max=key=>[...strikes].filter(r=>r[key]!=null&&r[key]>0).sort((a,b)=>b[key]-a[key])[0]?.strike;
  return {strikes,call:max('calls'),put:max('puts'),peak:max('abs'),positive:max('net'),negative:[...strikes].filter(r=>r.net<0).sort((a,b)=>a.net-b.net)[0]?.strike};
}
function profile(rows,range=c.range,count=101,days=c.days,vol=c.vol){
  if(!rows.length||!rows.some(r=>r.oi!=null&&(c.position!=='proxy'||r.share!=null)))return [];
  const f=rows[0].f;
  return series(f*(1-range/100),f*(1+range/100),count).map(x=>[x,gexValue(market(rows,c,x,days,vol,40),'net')]);
}
function crossings(rows,p,days=c.days,vol=c.vol){
  return profileRoots(p,f=>gexValue(market(rows,c,f,days,vol,40),'net'));
}
function rootsLabel(roots,p){
  if(!p.length)return 'Unavailable';
  if(p.every(([,y])=>Math.abs(y??0)<1e-9))return 'Flat across range';
  return roots.length?roots.map(fmt).join(', '):'None detected';
}
function focusLabel(){
  return c.focus?'Selected strike '+fmt(c.focus.strike)+(c.focus.expiry?' · '+c.focus.expiry:''):'';
}
function journal(){
  const j=read('commodity-trading-journal-v1',{});
  const o=read('commodity-options-v2',{});
  const positions=j.trades??[];
  return {j,o,positions};
}
function openTrades(raw,rows){
  const {j,o,positions}=raw;
  const date=c.date;
  let items=c.book==='journal'?positions:(o.legs??[]).map(l=>{
    const m=o.markets?.find(m=>m.id===l.contract);
    return {...l,kind:'option',symbol:m?.symbol,factor:m?.factor,openDate:o.asof,entry:l.premium,lastMark:l.mark,lastMarkDate:l.markDate,account:'Options workspace',id:String(l.id),optMarket:m};
  });
  if(demonstration&&c.book==='demo'&&rows.length){
    const r=rows.find(r=>r.type==='call'&&r.strike>=r.f)??rows[0];
    items=[{...r,id:'DEMO-FUT',kind:'future',symbol:c.contract,side:'short',lots:3,entry:r.f*.985,openDate:shift(date,-8),account:'Synthetic clearing'},
      {...r,id:'DEMO-OPT',kind:'option',symbol:c.contract,optionType:'call',side:'long',lots:6,entry:r.f*.025,openDate:shift(date,-8),account:'Synthetic clearing'},
      {...r,id:'DEMO-OTC',kind:'structure',symbol:c.contract,side:'short',lots:8,openDate:shift(date,-8),account:'Synthetic CSA',remaining:8,daily:1,original:8,fix:r.f,barrier:r.f*.85,barrierDir:'below',barrierEqual:true,barrierState:'alive',ko:'touch',action:'resetRest',reset:r.f*.94,settlement:'physical',timing:'expiry',trigger:r.f*1.06,doubleDir:'above',doubleEqual:true,multiple:2,otcMark:-5400,lastMarkDate:date}];
  }
  const all=['portfolio','margin','pgamma'].includes(c.tab)&&c.scope==='all';
  const focusFilter=c.focusPortfolio&&c.focus&&['portfolio','pgamma','margin'].includes(c.tab);
  return items.filter(t=>(!focusFilter||t.kind==='option'&&t.strike===c.focus.strike&&(!c.focus.expiry||t.expiry===c.focus.expiry))&&(all||t.symbol===c.contract)&&(!t.openDate||t.openDate<=date)&&(['all','aggregate'].includes(c.trade)||String(t.id)===c.trade)).flatMap(t=>{
    const lots=t.lots-(t.closeDate&&t.closeDate<=date?t.closedLots??0:0);
    if(!(lots>0))return [];
    const chainRows=demonstration&&c.book!=='demo'?[]:t.symbol===c.contract?selected().filter(r=>r.contract===t.symbol&&r.commodity===c.commodity&&r.date===date):selected().filter(r=>r.contract===t.symbol&&r.date===date);
    const chain=chainRows.find(r=>r.expiry===t.expiry&&r.strike===t.strike&&r.type===(t.optionType??t.type));
    const m=j.markets?.[t.symbol];
    const importedMark=read('dux-futures-v1',{})[date+'|'+t.symbol];
    const f=chainRows[0]?.f??importedMark?.close??(m?.lastDate===date?m.last:null)??(o.asof===date?t.optMarket?.close:null);
    const factor=t.factor??chainRows[0]?.factor??importedMark?.factor??m?.factor??specs[t.symbol.match(/^([A-Z]+)[A-Z]\d\d$/)?.[1]]?.[1];
    const accountKey=(t.kind==='structure'?'otc|':'listed|')+t.account;
    const mtm=t.lastMarkDate===date?t.otcMark:null;
    return [{...t,f,factor,accountKey,mtm,shockWeight:t.symbol===c.contract?1:c.crossShock,signed:lots*(t.side==='short'?-1:1),type:t.optionType??t.type,style:t.style??chain?.style??'us',iv:chain?.iv??t.iv}];
  });
}
function gex(rows,full,priced,previous,trades){
  const f=rows[0].f, g=concentrations(priced);
  const chosen=c.focus;
  const marks=[[f,'Futures','#5a7793'],[g.call,'Call wall','#25885b'],[g.put,'Put wall','#b34848'],[g.positive,'Max +GEX','#278b61'],[g.negative,'Max −GEX','#b04848'],[g.peak,'Concentration','#96754d'],[chosen?.strike,'Selected','#bf773d']];
  const positions=uniq(trades.filter(t=>t.kind==='option'&&Number.isFinite(t.strike)),'strike');
  const shapes=marks.filter(([k])=>Number.isFinite(k)).map(([k,n,color])=>marker(k,n,color));
  const totals=group(priced,'expiry').map(([expiry,rs])=>({Expiry:expiry,'Net GEX USD':gexValue(rs,'net'),'Absolute GEX USD':gexValue(rs,'absolute'),OI:gexValue(rs,'oi'),'Hedge lots':knownSum(rs,r=>r.hedge)}));
  const change=historyChange(previous,rows,c);
  const now=gexValue(priced,'net');
  const known=priced.filter(r=>r.exposure!=null);
  const hedge=knownSum(known,r=>r.hedge);
  if(c.tab==='overview'){
    const baseProfile=profile(rows,c.range,101,0,0), roots=crossings(rows,baseProfile,0,0);
    tiles([['Estimated net GEX USD',now],['Positive GEX USD',known.length?sum(known,r=>Math.max(0,r.exposure)):null],['Negative GEX USD',known.length?sum(known,r=>Math.min(0,r.exposure)):null],['Call GEX USD',gexValue(priced.filter(r=>r.type==='call'),'net')],['Put GEX USD',gexValue(priced.filter(r=>r.type==='put'),'net')],['Call wall',g.call],['Put wall',g.put],['Gamma flips ±'+c.range+'%',rootsLabel(roots,baseProfile)],['Highest concentration',g.peak],['Futures settlement',f],['Estimated hedge lots',hedge],['Change vs prior USD',change.net],['Covered series',known.length+' / '+priced.length],['Prior chain',previous[0]?.date],['Matched series',change.matched]]);
    const scope=selected().filter(r=>r.date===c.date);
    const summary=group(scope,'commodity').map(([k,rs])=>({Commodity:specs[k][0],'Net GEX USD':gexValue(market(rs,c),'net'),'Futures contracts':uniq(rs,'contract').length}));
    graph([{type:'bar',x:totals.map(r=>r.Expiry),y:totals.map(r=>r['Net GEX USD']),marker:{color:totals.map(r=>r['Net GEX USD']>=0?'#267653':'#b34546')}}],'Expiry','Estimated net GEX · USD / 1%');
    table([...totals,...summary,{Expiry:'Snapshot comparison','Matched-series change USD':change.matchedMove,'Expired-series effect USD':change.expiredEffect,'Other series additions/removals USD':change.universeEffect,'OI change':change.oiMove}]);return;
  }
  if(c.tab==='walls'&&c.wallView==='expiry'){
    const concentrations=gammaByExpiry(priced);
    graph([{type:'bar',x:concentrations.map(r=>r.expiry),y:concentrations.map(r=>r.oi),name:'Open interest'},line(concentrations.map(r=>r.expiry),concentrations.map(r=>r.absolute),'Absolute GEX USD',{yaxis:'y2'})],
      'Expiration','Open interest',null,{yaxis2:{overlaying:'y',side:'right',title:'Absolute GEX USD'}});
    table(totals);return;
  }
  if(c.tab==='strike'||c.tab==='walls'){
    const strikes=group(priced,'strike').map(([strike,rs])=>{
      const old=previous.filter(r=>r.strike===strike);
      const call=rs.filter(r=>r.type==='call'),put=rs.filter(r=>r.type==='put');
      const a=gexValue(call,'oi'),b=gexValue(put,'oi'),oi=gexValue(rs,'oi'),priorOI=gexValue(old,'oi');
      return {Strike:strike,Value:gexValue(rs,c.metric),'Net GEX USD':gexValue(rs,'net'),'Call OI':a,'Put OI':b,'Call GEX USD':gexValue(call,'net'),'Put GEX USD':gexValue(put,'net'),'Call gamma × OI':knownSum(call,r=>r.oi==null?null:r.gamma*r.oi),'Put gamma × OI':knownSum(put,r=>r.oi==null?null:r.gamma*r.oi),'Estimated dealer gamma':gexValue(rs,'dealer'),'Call/put OI':b>0&&a!=null?a/b:null,'OI change':priorOI==null||oi==null?null:oi-priorOI};
    });
    const x=strikes.map(r=>r.Strike);
    const gammaView=c.tab==='walls'&&c.wallView==='gamma';
    const barFields=gammaView?['Call gamma × OI','Put gamma × OI']:['Call OI','Put OI'];
    const bars=c.tab==='strike'?[{type:'bar',x,y:strikes.map(r=>r.Value),marker:{color:strikes.map(r=>r.Value>=0?'#267653':'#b34546')}}]:
      barFields.map((key,i)=>({type:'bar',x,y:strikes.map(r=>r[key]),name:key,marker:{color:i?'#b34546':'#267653'}}));
    if(gammaView)bars.push(line(x,strikes.map(r=>r['Estimated dealer gamma']),'Estimated dealer gamma',{line:{color:'#7767ac'}}));
    if(c.tab==='walls'&&!gammaView) for(const [key,color] of [['Call GEX USD','#3b9c72'],['Put GEX USD','#cf745d'],['Net GEX USD','#7767ac']])bars.push(line(x,strikes.map(r=>r[key]),key,{yaxis:'y2',line:{color}}));
    if(positions.length)bars.push({type:'scatter',mode:'markers',x:positions,y:positions.map(()=>0),name:'Portfolio strikes',marker:{symbol:'diamond',color:'#7767ac',size:9}});
    const overlay=trades.filter(t=>t.kind==='option'&&t.iv>0&&t.expiry>=c.date&&t.f>0&&t.strike>0);
    const exposure=group(overlay,'strike').map(([strike,rs])=>[strike,sum(rs,t=>optionPoint(t,t.f,c.date,c.rate,48).gamma*t.signed*t.f*.01*t.f*t.factor)]);
    if(c.tab==='strike'&&c.metric==='net'&&exposure.length)bars.push({type:'scatter',mode:'markers',x:exposure.map(r=>r[0]),y:exposure.map(r=>r[1]),name:'Portfolio GEX · USD',marker:{symbol:'diamond-open',size:10,color:'#7767ac'}});
    const axis=c.tab==='strike'?metricLabels[c.metric]:gammaView?'Gamma · lots per price point':'Open interest';
    graph(bars,'Strike · '+specs[c.commodity][2],axis,null,{shapes,barmode:'group',...(c.tab==='walls'&&!gammaView?{yaxis2:{title:'Estimated GEX · USD',overlaying:'y',side:'right'}}:{})});
    table(strikes.map(r=>({...r,'Portfolio GEX USD':exposure.find(x=>x[0]===r.Strike)?.[1]})));return;
  }
  if(c.tab==='profile'||c.tab==='hedge'){
    const p=profile(rows), roots=crossings(rows,p);
    const baseline=gexValue(market(rows,c,f,c.days,c.vol),'net');
    const getHedge=x=>knownSum(market(rows,c,x,c.days,c.vol,48).filter(r=>r.expiry>shift(r.date,c.days)),r=>r.hedge);
    const start=known.length?getHedge(f):null;
    tiles([['Gamma regime',baseline==null?'Unavailable':baseline>0?'Positive':baseline<0?'Negative':'Flat'],['Zero crossings',rootsLabel(roots,p)],['Estimated starting hedge lots',start]]);
    if(c.tab==='profile'){
      graph([line(p.map(x=>x[0]),p.map(x=>x[1]),'Net GEX'),{type:'scatter',mode:'lines',x:p.map(x=>x[0]),y:p.map(x=>Math.max(0,x[1])),fill:'tozeroy',line:{color:'#267653'}},{type:'scatter',mode:'lines',x:p.map(x=>x[0]),y:p.map(x=>Math.min(0,x[1])),fill:'tozeroy',line:{color:'#b34546'}}],'Simulated futures price','Estimated net GEX USD / 1%',null,{shapes:[...[[f,'Futures','#5a7793'],[g.peak,'Concentration','#96754d'],[g.call,'Call wall','#25885b'],[g.put,'Put wall','#b34848']].filter(([k])=>Number.isFinite(k)&&k>=p[0]?.[0]&&k<=p.at(-1)?.[0]).map(args=>marker(...args)),...roots.map((x,i)=>marker(x,'Flip '+(i+1),'#8067a4'))]});
      table(p.map(([x,y])=>({'Futures price':x,'Net GEX USD':y})));return;
    }
    const shocks=[...new Set([-2,-1,-.5,.5,1,2,c.shock])].sort((a,b)=>a-b);
    const flows=start==null?[]:shocks.map(shock=>{const x=f*(1+shock/100), lots=getHedge(x)-start;return {'Shock %':shock,'Futures price':x,'Hedge change lots':lots,'Trade notional USD':lots*x*rows[0].factor,Action:lots>0?'Buy':lots<0?'Sell':'Flat'};});
    const roll=hedgeRoll(rows,c,f,c.days,c.vol);
    if(start!=null)tiles([['Estimated starting hedge lots',start],['Local hedge change lots / +1%',-gexValue(market(rows,c,f,c.days,c.vol),'lots')],['One-day roll hedge change',roll.change],['Expiring series',roll.expiring],['Expiring hedge lots',roll.expiringHedge],['Gamma flips',rootsLabel(roots,p)]]);
    graph([{type:'bar',x:flows.map(r=>r['Shock %']),y:flows.map(r=>r['Hedge change lots']),marker:{color:flows.map(r=>r['Hedge change lots']>=0?'#267653':'#b34546')}}],'Futures price shock %','Mechanical hedge change · futures lots');
    table(flows);return;
  }
  if(c.tab==='history'){
    const snapshots=group(full.filter(r=>r.date<=c.date),'date').slice(-25);
    const history=snapshots.map(([date,rs],i)=>{
      const m=market(rs,c), w=concentrations(m), p=profile(rs,c.range,61,0,0), roots=crossings(rs,p,0,0);
      const diff=historyChange(snapshots[i-1]?.[1]??[],rs,c);
      const hedge=knownSum(m,r=>r.hedge);
      return {Date:date,Settlement:rs[0].f,'Net GEX USD':gexValue(m,'net'),OI:gexValue(m,'oi'),'Call wall':w.call,'Put wall':w.put,'Peak strike':w.peak,'Nearest flip':roots.sort((a,b)=>Math.abs(a-rs[0].f)-Math.abs(b-rs[0].f))[0],
        'All flips':rootsLabel(roots,p),'Front expiry GEX':gexValue(m.filter(r=>r.expiry===uniq(rs,'expiry')[0]),'net'),'Hedge lots':hedge,'Hedge adjustment lots':hedge==null?null:knownSum(market(rs,c,rs[0].f*(1+c.shock/100)),r=>r.hedge)-hedge,
        'GEX change USD':diff.net,'OI change':diff.oiMove,'Expired-series effect USD':diff.expiredEffect,'Matched-series move USD':diff.matchedMove,'Other series additions/removals USD':diff.universeEffect,Source:uniq(rs,'source').join(' · ')};
    });
    const x=history.map(r=>r.Date);
    const metric=c.historyMetric;
    const comparison=history.find(r=>r.Date===previous[0]?.date);
    tiles([['Available snapshots',history.length],['Selected comparison',comparison?.Date],['Net change vs comparison USD',change.net],['Expired-series effect USD',change.expiredEffect],['Matched series',change.matched]]);
    graph([line(x,history.map(r=>r[metric]),metric),line(x,history.map(r=>r.Settlement),'Futures close',{yaxis:'y2'})],'Session',metric,null,{yaxis2:{title:'Futures close',side:'right',overlaying:'y'}});
    table(history);return;
  }
  const x=uniq(priced,'strike').sort((a,b)=>a-b), y=uniq(priced,'expiry'), dates=y.map(e=>daysBetween(c.date,e));
  const grid=y.map(e=>x.map(k=>gexValue(priced.filter(r=>r.strike===k&&r.expiry===e),c.metric)));
  const cells=y.flatMap((expiry,i)=>x.map((strike,j)=>({strike,expiry,dte:dates[i],v:grid[i][j]})));
  const cross=cells.find(r=>r.strike===chosen?.strike&&(chosen.expiry==null||r.expiry===chosen.expiry));
  const focusData=cross&&cross.v!=null?[{type:'scatter3d',mode:'markers',x:[cross.strike],y:[cross.dte],z:[cross.v],name:'Selected',marker:{size:6,color:'#e3a159'},customdata:[[cross.strike,cross.expiry]]}]:[];
  const cd=y.map(e=>x.map(k=>[k,e]));
  const zscale=Math.max(1e-12,...grid.flat().filter(Number.isFinite).map(Math.abs));
  if(c.tab==='heat')graph([{type:'heatmap',x,y,z:grid,customdata:cd,colorscale:palette,zmin:-zscale,zmax:zscale,hoverongaps:false,hovertemplate:'Strike %{x}<br>Expiry %{y}<br>Value %{z:,.4f}<extra></extra>'},...(cross?[{type:'scatter',mode:'markers',x:[cross.strike],y:[cross.expiry],marker:{symbol:'square-open',size:15,color:'#e3a159'},customdata:[[cross.strike,cross.expiry]],name:'Selected'}]:[])],'Strike','Expiry');
  else graph([c.surface==='bars'?bars3d(cells):surface(x,dates,grid,{customdata:cd,cmin:-zscale,cmax:zscale}),...focusData],'Strike','Days to expiry',metricLabels[c.metric]);
  const inspect=priced.filter(r=>!cross||(r.strike===cross.strike&&r.expiry===cross.expiry));
  table(inspect.map(r=>({...item(r),'Signed dealer lots':r.lots,'Dealer gamma lots / point':r.lots==null?null:r.lots*r.gamma,'Hedge lots':r.hedge})),false);
  exported=cells.map(r=>({Strike:r.strike,Expiry:r.expiry,Value:r.v}));
}

const interp=(points,target)=>{
  const s=[...points].sort((a,b)=>a[0]-b[0]);
  const i=s.findIndex(p=>p[0]>=target);
  if(i<0)return null;
  if(s[i][0]===target)return s[i][1];
  if(i===0)return null;
  const [a,b]=[s[i-1],s[i]];
  return a[1]+(target-a[0])*(b[1]-a[1])/(b[0]-a[0]);
};
function volatility(rows,prior,full,priced){
  const calc=ps=>group(ps,'expiry').map(([expiry,rs])=>{
    const f=rs[0].f;
    const curve=type=>rs.filter(r=>r.type===type).map(r=>[Math.abs(r.delta),r.iv]);
    const call=interp(curve('call'),.25),put=interp(curve('put'),.25);
    const atk=group(rs,'strike').map(([k,v])=>[k,sum(v,r=>r.iv)/v.length]);
    const atm=interp(atk,f);
    return {Expiry:expiry,'ATM IV %':atm,'25Δ call IV':call,'25Δ put IV':put,'25Δ risk reversal':call!=null&&put!=null?call-put:null,'25Δ butterfly':call!=null&&put!=null&&atm!=null?(call+put)/2-atm:null};
  });
  const metrics=calc(priced), d=diagnostics(rows,c.rate);
  const priorMetrics=prior.length?calc(market(prior,c)):[];
  const observations=group(full.filter(r=>r.date<=c.date),'date');
  const returns=observations.slice(1).map(([,r],i)=>Math.log(r[0].f/observations[i][1][0].f));
  const avg=returns.length?sum(returns,x=>x)/returns.length:0;
  const hv=returns.length>=10?100*Math.sqrt(252*sum(returns,r=>(r-avg)**2)/(returns.length-1)):null;
  const atmHistory=observations.filter(([date])=>date<=c.date).map(([,rs])=>calc(market(rs,c))[0]?.['ATM IV %']).filter(Number.isFinite);
  const atm=metrics[0]?.['ATM IV %'];
  const lo=Math.min(...atmHistory), hi=Math.max(...atmHistory);
  tiles([['Front ATM IV %',atm],['Realized volatility %',hv],['IV percentile',atmHistory.length>=20&&atm!=null?100*atmHistory.filter(x=>x<=atm).length/atmHistory.length:null],['IV rank',atmHistory.length>=20&&atm!=null&&hi>lo?100*(atm-lo)/(hi-lo):null],['Butterfly / calendar flags',d.comparable?d.butterfly+' / '+d.calendar:'Insufficient comparable European quotes']]);
  if(c.tab==='vol'){
    const traces=group(priced,'expiry').flatMap(([expiry,rs])=>group(rs,'type').map(([type,legs])=>{const s=[...legs].sort((a,b)=>a.strike-b.strike);return line(s.map(r=>r.strike),s.map(r=>r.iv),expiry+' '+type);}));
    graph(traces,'Strike','IV %',null,{shapes:[marker(rows[0].f,'Futures','#5a7793'),...(c.focus?[marker(c.focus.strike,'Selected','#bf773d')]:[])]});
  } else {
    const groups=group(priced,'expiry');
    const coord=r=>c.coordinate==='strike'?r.strike:c.coordinate==='log'?Math.log(r.strike/r.f):r.delta;
    const coordLabel={strike:'Strike',log:'Log-moneyness',delta:'Signed delta'}[c.coordinate];
    const all=priced.map(coord);
    const x=c.coordinate==='strike'?uniq(priced,'strike').sort((a,b)=>a-b):series(Math.min(...all),Math.max(...all),33);
    const traces=['call','put'].filter(type=>priced.some(r=>r.type===type)).flatMap((type,i)=>{
      const data=groups.map(([expiry,rs])=>({expiry,legs:rs.filter(r=>r.type===type)}));
      const y=data.map(r=>daysBetween(c.date,r.expiry));
      const z=data.map(r=>x.map(k=>{
        const exact=r.legs.find(l=>coord(l)===k);
        return exact?.iv??(c.coordinate==='strike'||d.butterfly||d.calendar?null:interp(r.legs.map(l=>[coord(l),l.iv]),k));
      }));
      const points=priced.filter(r=>r.type===type);
      return [surface(x,y,z,{name:type,opacity:.76,showscale:false,colorscale:i?'Reds':'Greens',hoverinfo:'skip'}),
        {type:'scatter3d',mode:'markers',x:points.map(coord),y:points.map(r=>daysBetween(c.date,r.expiry)),z:points.map(r=>r.iv),name:type+' observations',customdata:points.map(r=>[r.strike,r.expiry,r.ivSource]),marker:{size:points.map(r=>c.focus?.strike===r.strike&&(!c.focus.expiry||c.focus.expiry===r.expiry)?7:3),color:i?'#b64d4d':'#237851'},hovertemplate:'Strike %{customdata[0]}<br>Expiry %{customdata[1]}<br>IV %{z:.3f}% · %{customdata[2]}<extra></extra>'}];
    });
    graph(traces,coordLabel,'Days to expiry','IV %');
  }
  table(metrics.map(r=>{const before=priorMetrics.find(p=>p.Expiry===r.Expiry)?.['ATM IV %'];return {...r,'ATM IV change':before==null||r['ATM IV %']==null?null:r['ATM IV %']-before};}));
}
function greekSurface(rows,trades){
  const target=c.focus?.strike??rows[0].f;
  const candidates=rows.filter(r=>!c.focus?.expiry||r.expiry===c.focus.expiry);
  const chosenTrade=trades.find(t=>t.kind==='option'&&t.iv>0&&t.f>0&&t.strike>0&&t.expiry>=c.date);
  const leg=(c.trade!=='all'&&c.trade!=='aggregate'?chosenTrade:null)??[...(candidates.length?candidates:rows)].sort((a,b)=>Math.abs(a.strike-target)-Math.abs(b.strike-target))[0];
  const x=series(leg.f*(1-c.range/100),leg.f*(1+c.range/100),31);
  const days=daysBetween(c.date,leg.expiry);
  const aggregate=c.trade==='aggregate';
  const y=series(0,Math.max(1,days-1),14).map(Math.round);
  const legs=aggregate?trades.filter(t=>t.kind==='option'&&t.iv>0&&t.strike>0&&t.expiry>=c.date):[{...leg,signed:c.trade!=='all'&&chosenTrade===leg?leg.signed:c.size*(c.side==='short'?-1:1)}];
  const z=y.map(day=>x.map(f=>legs.length?sum(legs,l=>{
    const g=advanced(l,f,shift(c.date,day),c.rate)[c.greek];
    return g*l.signed*(['delta','gamma','vanna','charm'].includes(c.greek)?1:l.factor);
  }):null));
  tiles([['Position',aggregate?'Journal option legs: '+legs.length:leg.type+' '+leg.strike],['Expiry',aggregate?'Individual leg expiries':leg.expiry],['Selected Greek',greeksLabels[c.greek]]]);
  graph([surface(x,y,z,{cmid:0})],'Simulated futures price','Calendar days elapsed',greeksLabels[c.greek]);
  table(y.flatMap((day,i)=>x.map((f,j)=>({'Futures price':f,'Days elapsed':day,Greek:c.greek,Value:z[i][j]}))));
}

function expiryBounds(trades){
  const opts=trades.filter(t=>t.kind==='option');
  if(!opts.length||trades.some(t=>t.kind==='structure'||!Number.isFinite(t.entry)||!Number.isFinite(t.factor))||uniq(trades,'symbol').length!==1||uniq(opts,'expiry').length!==1)return null;
  const knots=[0,...uniq(opts,'strike').filter(k=>k>0)];
  const pl=f=>sum(trades,t=>(t.kind==='future'?f-t.entry:intrinsic(t.type,f,t.strike)-t.entry)*t.signed*t.factor);
  const points=knots.map(k=>[k,pl(k)]);
  const tail=sum(trades,t=>t.kind==='future'||t.type==='call'?t.signed*t.factor:0);
  const end=points.at(-1);
  const roots=[...new Set([...flips(points),...points.filter(p=>Math.abs(p[1])<1e-7).map(p=>p[0]),...(tail&&end[1]*tail<0?[end[0]-end[1]/tail]:[])])];
  return {roots,best:tail>0?'Unbounded':Math.max(...points.map(p=>p[1])),worst:tail<0?'Unbounded':Math.min(...points.map(p=>p[1]))};
}

function riskSurface(rows,trades,raw,priorDate){
  const x=series(-c.range,c.range,17), y=series(-10,10,11);
  const asof=c.date;
  const prior=raw.j.asof===c.date&&raw.j.prior?raw.j.prior:priorDate;
  const valid=trades.filter(t=>t.f>0);
  const ready=valid.map(t=>({...t,baseline:t.kind==='structure'?structureValue(t,t.f,c.date,c.rate):
    t.kind==='option'&&t.iv>0?optionPoint(t,t.f,c.date,c.rate,48).price:null}));
  const accounts=structuredClone(raw.j.accounts??{});
  if(demonstration&&c.book==='demo'){
    accounts['listed|Synthetic clearing']={asof,prior,equity:18000,maintenance:15000,target:20000,broker:-3200,initial:20000};
    accounts['otc|Synthetic CSA']={asof,threshold:1000,posted:3000,mta:500,independent:0};
  }
  if(c.book==='options'&&raw.o.asof===asof&&raw.o.margin?.equityDate===prior){
    const m=raw.o.margin;
    accounts['listed|Options workspace']={asof,prior,equity:m.equity,maintenance:m.maintenance,target:m.target,broker:m.brokerDate===asof?m.broker:null,other:m.otherDate===asof?m.other:0};
  }
  const allAccountTrades=raw.positions.filter(t=>(!t.openDate||t.openDate<=asof)&&t.lots-(t.closeDate&&t.closeDate<=asof?t.closedLots??0:0)>0);
  const omittedAccount=c.book==='journal'&&ready.some(t=>allAccountTrades.some(r=>r.account===t.account&&(r.kind==='structure')===(t.kind==='structure')&&!ready.some(p=>p.id===r.id)));
  for(const [key,a] of Object.entries(accounts)){
    if(a.broker!=null||key.startsWith('otc|')||c.book==='options')continue;
    const rs=ready.filter(t=>t.accountKey===key);
    const moves=rs.map(t=>{
      const m=raw.j.markets?.[t.symbol];
      const prev=read('dux-futures-v1',{})[prior+'|'+t.symbol]?.close??imported.find(r=>r.date===prior&&r.contract===t.symbol)?.f??(m?.priorDate===prior?m.prior:null);
      if(t.openDate>prior) return Number.isFinite(t.entry)&&t.kind==='future'?(t.f-t.entry)*t.factor*t.signed:null;
      if(t.kind==='future'&&Number.isFinite(prev))return (t.f-prev)*t.factor*t.signed;
      if(t.kind==='option'&&t.lastMarkDate===asof&&t.priorMarkDate===prior&&Number.isFinite(t.lastMark)&&Number.isFinite(t.priorMark))return (t.lastMark-t.priorMark)*t.factor*t.signed;
      return null;
    });
    const fills=raw.positions.filter(t=>t.account===key.slice(7)&&t.kind!=='structure'&&t.closedLots>0&&t.closeDate>prior&&t.closeDate<=asof);
    for(const t of fills){
      const m=raw.j.markets?.[t.symbol];
      const start=t.openDate>prior?t.entry:t.kind==='future'&&m?.priorDate===prior?m.prior:t.priorMarkDate===prior?t.priorMark:null;
      const factor=t.factor??m?.factor??specs[c.commodity][1];
      moves.push(Number.isFinite(start)&&Number.isFinite(t.exit)?(t.exit-start)*t.closedLots*factor*(t.side==='short'?-1:1):null);
    }
    if(rs.length&&moves.every(Number.isFinite))a.movement=sum(moves,v=>v);
  }
  const margin=c.tab==='margin';
  const datesOk=Boolean(asof&&prior&&asof>prior);
  const grid=y.map(v=>x.map(p=>{
    if(!ready.length||ready.length!==trades.length)return null;
    const moves=scenario(ready,c,p,v,c.days,c.rate+(c.rateShock??0)/100);
    if(margin&&(!datesOk||omittedAccount))return null;
    return margin?stressedCalls(ready,moves,accounts,asof,prior):moves.every(Number.isFinite)?sum(moves,n=>n):null;
  }));
  const available=grid.flat().filter(Number.isFinite);
  const greeks=ready.filter(t=>t.kind==='option'&&t.iv>0&&t.expiry>=c.date&&t.strike>0).map(t=>({t,...advanced(t,t.f,c.date,c.rate)}));
  const otc=ready.filter(t=>t.kind==='structure'&&t.baseline!=null);
  const modeledDelta=otc.map(t=>{const bump=t.f*.005;return (structureValue(t,t.f+bump,c.date,c.rate)-structureValue(t,t.f-bump,c.date,c.rate))/(2*bump*t.factor);});
  const modeledGamma=otc.map(t=>{const bump=t.f*.005;return (structureValue(t,t.f+bump,c.date,c.rate)+structureValue(t,t.f-bump,c.date,c.rate)-2*t.baseline)/(bump*bump*t.factor);});
  const futuresDelta=sum(ready.filter(t=>t.kind==='future'),t=>t.signed);
  const delta=futuresDelta+sum(greeks,r=>r.delta*r.t.signed)+sum(modeledDelta,v=>v);
  const gamma=sum(greeks,r=>r.gamma*r.t.signed)+sum(modeledGamma,v=>v);
  const pnl=available.length?[Math.min(...available),Math.max(...available)]:[null,null];
  const relevant=[...new Set(ready.map(t=>t.accountKey))].map(k=>[k,accounts[k]]);
  const inputSum=(key)=>relevant.length&&relevant.every(([,a])=>Number.isFinite(a?.[key]))?sum(relevant,([,a])=>a[key]):null;
  const details=ready.map(t=>{
    const g=greeks.find(r=>r.t===t), i=otc.indexOf(t);
    const d=t.kind==='future'?t.signed:g?g.delta*t.signed:i>=0?modeledDelta[i]:null;
    return {Trade:t.id,Contract:t.symbol,Account:t.account,Instrument:t.kind,Expiry:t.expiry,'Open signed lots':t.signed,'Delta lots':d,
      'Gamma lots/point':g?g.gamma*t.signed:i>=0?modeledGamma[i]:t.kind==='future'?0:null,'Theta USD/day':g?g.theta*t.signed*t.factor:null,'Vega USD/vol point':g?g.vega*t.signed*t.factor:null,
      'Dealer MTM USD':t.mtm,'Model value USD':t.kind==='structure'?t.baseline:t.kind==='option'&&t.baseline!=null?t.baseline*t.signed*t.factor:null,
      'Unrealized USD':t.kind==='structure'?t.mtm:Number.isFinite(t.entry)?(t.kind==='future'?t.f-t.entry:t.baseline==null?NaN:(t.lastMarkDate===asof&&Number.isFinite(t.lastMark)?t.lastMark:t.baseline)-t.entry)*t.signed*t.factor:null};
  });
  const realized=raw.positions.filter(t=>t.symbol===c.contract&&t.closeDate&&t.closeDate<=asof&&Number.isFinite(t.realized));
  const inventory=group(details,'Contract').map(([contract,rs])=>({Contract:contract,Trade:'Contract total','Delta lots':rs.every(t=>Number.isFinite(t['Delta lots']))?sum(rs,t=>t['Delta lots']):null,'Gamma lots/point':rs.every(t=>Number.isFinite(t['Gamma lots/point']))?sum(rs,t=>t['Gamma lots/point']):null}));
  const bounds=expiryBounds(ready);
  const portfolioReady=ready.length===trades.length&&details.every(t=>Number.isFinite(t['Delta lots']));
  tiles(margin?[[ 'Open positions',ready.length],['Initial margin input USD',inputSum('initial')],['Maintenance / call threshold USD',inputSum('maintenance')],['Posted CSA collateral USD',inputSum('posted')],['Base estimated call USD',available.length?stressedCalls(ready,scenario(ready,c,0,0),accounts,asof,prior):null],['Worst tested call USD',pnl[1]]]:
    [['Open positions',ready.length],['Known net delta lots',new Set(ready.map(t=>t.symbol)).size===1?delta:null],['Known net gamma lots/point',new Set(ready.map(t=>t.symbol)).size===1?gamma:null],['Delta coverage',portfolioReady?'Complete':'Partial'],['Worst tested P/L USD',pnl[0]],['Best tested P/L USD',pnl[1]],['Recorded realized USD',realized.length?sum(realized,t=>t.realized):null],['Expiry breakevens',bounds?.roots.length?bounds.roots.map(fmt).join(', '):null],['Maximum expiry gain USD',bounds?.best],['Worst expiry P/L USD',bounds?.worst]]);
  const zname=margin?'Estimated call · USD':'Change in portfolio value · USD';
  graph(available.length?[surface(x,y,grid,{cmid:0})]:[],'Futures price shock %','IV shock · vol points',zname);
  if(!available.length)status(margin?'Margin surface needs all active positions in each selected account, same-date broker or CSA inputs, and valid marks.':'Portfolio surface needs open trades for this contract and complete pricing inputs.',true);
  if(margin)table(relevant.map(([k,a])=>({Account:k,'Inputs date':a?.asof,'Prior equity':a?.equity,'Initial margin':a?.initial,'Maintenance threshold':a?.maintenance,'Broker / journal variation':a?.broker??a?.movement,'CSA posted':a?.posted})),false);
  else table([...details,...inventory],false);
  exported=y.flatMap((v,i)=>x.map((p,j)=>({'Price shock %':p,'IV shock points':v,[zname]:grid[i][j]})));
  if(available.length){const history=read('dux-risk-snapshots',{}); history[[c.date,c.contract,c.book,c.tab].join('|')]={date:c.date,contract:c.contract,book:c.book,synthetic:c.book==='demo',view:c.tab,worst:pnl[0],best:pnl[1],delta:new Set(ready.map(t=>t.symbol)).size===1?delta:null,gamma:new Set(ready.map(t=>t.symbol)).size===1?gamma:null};save('dux-risk-snapshots',Object.fromEntries(Object.entries(history).slice(-100)));}
}

function renderPortfolioGamma(trades, marketRows){
  const rows=portfolioGamma(trades,c.date,c);
  const value='Portfolio GEX USD / 1%';
  const known=rows.filter(r=>Number.isFinite(r[value]));
  const complete=rows.length>0&&known.length===rows.length;
  const single=new Set(rows.map(r=>r.Contract)).size<=1;
  tiles([['Open positions',rows.length],['Gamma coverage',known.length+' / '+rows.length],['Known portfolio GEX USD / 1%',single?knownSum(rows,r=>r[value]):'See contract totals'],
    ['Estimated market GEX · selected chain',gexValue(marketRows,'net')],['Book coverage',complete?'Complete':rows.length?'Partial':'No open trades']]);
  graph(known.length?[{type:'bar',x:known.map(r=>r.Trade),y:known.map(r=>r[value]),marker:{color:known.map(r=>r[value]>=0?'#267653':'#b34546')},
    customdata:known.map(r=>[r.Contract,r.Method]),hovertemplate:'%{x} · %{customdata[0]}<br>%{y:,.2f} USD / 1%<br>%{customdata[1]}<extra></extra>'}]:[],
    'Open trade','Portfolio GEX · USD / 1%');
  table([...rows,...group(rows,'Contract').map(([contract,rs])=>({Trade:'Contract subtotal',Contract:contract,[value]:knownSum(rs,r=>r[value]),Method:rs.filter(r=>Number.isFinite(r[value])).length+' / '+rs.length+' covered'}))]);
  if(!rows.length)status('No open positions in this book for '+c.contract+' on '+c.date+'.',true);
}
function rebuildControls(){
  const source=selected();
  const journalView=['pgamma','portfolio','margin'].includes(c.tab);
  const bySymbol=s=>Object.keys(specs).sort((a,b)=>b.length-a.length).find(k=>new RegExp('^'+k+'[A-Z][0-9]{2}$').test(s));
  const saved=journal();
  const symbols=journalView&&c.book!=='demo'?[...new Set([...saved.positions.map(t=>t.symbol),...Object.keys(saved.j.markets??{}),...(saved.o.markets??[]).map(m=>m.symbol)].filter(Boolean))]:[];
  const avail=[...new Set([...uniq(source,'commodity'),...symbols.map(bySymbol).filter(Boolean)])];
  if(!avail.includes(c.commodity))c.commodity=avail[0]??'SB';
  const contracts=[...new Set([...uniq(source.filter(r=>r.commodity===c.commodity),'contract'),...symbols.filter(s=>bySymbol(s)===c.commodity)])];
  if(!contracts.includes(c.contract)){c.contract=contracts[0]??'';c.focus=null;}
  const dated=source.filter(r=>r.commodity===c.commodity&&r.contract===c.contract);
  const dates=[...new Set([...uniq(dated,'date'),...(symbols.includes(c.contract)?[saved.j.asof,saved.j.markets?.[c.contract]?.lastDate,saved.o.asof].filter(Boolean):[])])].sort().reverse();
  if(!dates.includes(c.date))c.date=dates[0]??'';
  const expiries=uniq(dated.filter(r=>r.date===c.date),'expiry');
  if(!['all',...expiries].includes(c.expiry))c.expiry='all';
  $('controls').innerHTML=select('commodity','Commodity',avail.map(k=>[k,specs[k][0]]))+select('contract','Futures contract',contracts)+select('date','Settlement date',dates)+select('expiry','Option expiration',[['all','All expiries'],...expiries])+select('type','Option type',[['all','Call and put'],['call','Calls'],['put','Puts']])+select('comparison','Compare with',[['previous','Previous snapshot'],...dates.filter(d=>d<c.date)]);
  $('assumptions').innerHTML=select('position','Dealer positioning',[['long','All OI long'],['short','All OI short'],['custom','User-defined shares'],['proxy','Imported signed share proxy']])+input('call','Call share %',-100,100)+input('put','Put share %',-100,100)+input('rate','Base annual rate %',-20,50,.1)+input('range','Futures range ±%',1,80)+input('days','Days elapsed',0,120)+input('vol','IV change · points',-50,100,.5)+input('shock','Custom hedge shock %',-80,100,.1);
  const nav=k=>'<button type="button" data-tab="'+k+'" aria-current="'+(c.tab===k)+'">'+labels[k]+'</button>';
  const keys=Object.keys(labels);
  $('risk-tabs').innerHTML='<div class="tab-group"><strong>GEX Analytics</strong><div>'+keys.slice(0,9).map(nav).join('')+'</div></div><div class="tab-group"><strong>Volatility and risk</strong><div>'+keys.slice(9).map(nav).join('')+'</div></div>';
  const picks=uniq(dated.filter(r=>r.date===c.date&&(c.expiry==='all'||r.expiry===c.expiry)),'strike').sort((a,b)=>a-b);
  const books=[['journal','Trade journal'],['options','Saved options workspace'],...(demonstration?[['demo','Synthetic positions']]:[])];
  if(!books.some(([k])=>k===c.book))c.book='journal';
  const book=journal();
  const ids=c.book==='journal'?book.positions.filter(t=>c.scope==='all'||t.symbol===c.contract).map(t=>String(t.id)):c.book==='options'?(book.o.legs??[]).map(l=>String(l.id)):[];
  const portfolioTabs=['greeks','portfolio','margin','pgamma'];
  const tradeOptions=[['all','All positions'],...(c.tab==='greeks'?[['aggregate','Aggregate open vanilla options']]:[]),...ids];
  $('extras').innerHTML=(['strike','heat','gex'].includes(c.tab)?select('metric','Exposure measure',Object.entries(metricLabels)):'')+
    (c.tab==='history'?select('historyMetric','Historical metric',['Net GEX USD','GEX change USD','Call wall','Put wall','Peak strike','Nearest flip','OI','OI change','Front expiry GEX','Expired-series effect USD','Hedge lots','Hedge adjustment lots']):'')+
    (c.tab==='walls'?select('wallView','Concentrations by',[['strike','Open interest by strike'],['gamma','Gamma by strike'],['expiry','Expiration']]):'')+
    (['portfolio','pgamma','margin'].includes(c.tab)&&c.focus?'<label class="focus-filter"><input type="checkbox" data-key="focusPortfolio" '+(c.focusPortfolio?'checked':'')+'> Limit to selected option</label>':'')+
    (c.tab==='gex'?select('surface','Display',[['surface','Surface'],['bars','3D bars']]):'')+
    (c.tab==='iv'?select('coordinate','Horizontal axis',[['strike','Strike'],['log','Log-moneyness'],['delta','Delta']])+'<button id="animate">Animate settlement dates</button>':'')+
    (portfolioTabs.includes(c.tab)||c.tab==='strike'?select('book','Portfolio source',books):'')+
    (portfolioTabs.includes(c.tab)?select('trade','Trade selection',tradeOptions):'')+
    (c.tab==='greeks'?select('greek','Greek',Object.entries(greeksLabels))+select('side','Option side',[['long','Long'],['short','Short']])+input('size','Position lots',1,100000):'')+
    (['portfolio','margin','pgamma'].includes(c.tab)?select('scope','Shock scope',[['contract','Selected contract'],['all','All open contracts']]):'')+
    (c.tab==='portfolio'?input('rateShock','Rate shock · points',-30,50,.25):'')+
    (['portfolio','margin'].includes(c.tab)&&c.scope==='all'?input('crossShock','Other contracts shock multiplier',-1,1,.1):'')+
    (['strike','heat','gex','iv','greeks'].includes(c.tab)?select('focusStrike','Selected strike',[['','Auto'],...picks]):'');
  const fs=$('extras').querySelector('[data-key=focusStrike]');if(fs)fs.value=c.focus?.strike??'';
  $('focus-label').textContent=focusLabel();
  return dated;
}
const descriptions={pgamma:'Modelled gamma of open positions. Futures are linear. OTC estimates use their remaining contractual payoff rules.',overview:'Market estimates for the selected chain and an exposure summary across imported commodities.',strike:'Signed dealer estimates with open-interest walls and recorded portfolio strikes.',profile:'Net gamma repriced across futures prices. Crossings are estimated on the displayed grid.',walls:'Open-interest concentrations and modelled dealer gamma by strike.',heat:'Select a strike and expiry cell to inspect the underlying option series.',history:'Comparison of available dated chain snapshots for this contract.',hedge:'Hypothetical futures trades needed to restore a delta-neutral hedge.',gex:'Estimated dealer exposure by strike and days to expiration.',iv:'Observed or settlement-implied IV points with bounded interpolation where available.',greeks:'Model Greeks for a selected option or the saved book’s open vanilla legs.',portfolio:'Change in portfolio value under parallel futures and IV shocks for the selected contract.',margin:'Scenario collateral calls using account inputs. Contract filters can exclude offsets.',vol:'ATM volatility, smile, skew and tenor metrics from available chain observations.'};
function render(){
  const id=++revision;
  const dated=rebuildControls();
  save('dux-risk-preferences',c);
  const full=dated.filter(r=>(c.expiry==='all'||r.expiry===c.expiry)&&(c.type==='all'||r.type===c.type));
  const rows=full.filter(r=>r.date===c.date);
  $('heading').textContent=labels[c.tab];
  $('description').textContent=descriptions[c.tab];
  $('kpis').textContent='';$('detail').textContent='';exported=[];
  if(!rows.length&&!['pgamma','portfolio','margin'].includes(c.tab)){status('No matching dated option chain. Import a snapshot or load the synthetic demo.',true);graph([],'','');return;}
  const prev=c.comparison==='previous'?uniq(dated,'date').filter(d=>d<c.date).at(-1):c.comparison;
  const old=full.filter(r=>r.date===prev);
  const cutoff=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  const age=daysBetween(c.date,cutoff);
  const known=rows.filter(r=>r.oi!=null&&(c.position!=='proxy'||r.share!=null)).length;
  $('restore-data').hidden=!demonstration||!imported.length;
  const prefix=rows.length?(demonstration?'SYNTHETIC DEMONSTRATION':uniq(rows,'source').join(' · ')):'Journal or workspace marks · No market chain';
  status(prefix+' · '+c.date+' · '+c.contract+' · '+rows.length+' series'+(known<rows.length?' · '+(rows.length-known)+' missing GEX inputs':'')+(age>4?' · Historical snapshot':'')+(note?' · '+note:''),demonstration||known<rows.length||age>4);
  setTimeout(()=>{
    if(id!==revision)return;
    try {
      const model={...c,rate:c.rate/100};
      const before=c;
      c=model;
      try{
        const raw=journal();
        const trades=openTrades(raw,rows);
        const priced=market(rows,c);
        if(c.tab==='pgamma'){renderPortfolioGamma(trades,priced);return;}
        if(c.tab==='iv'||c.tab==='vol')volatility(rows,old,full,priced);
        else if(c.tab==='greeks')greekSurface(rows,trades);
        else if(c.tab==='portfolio'||c.tab==='margin')riskSurface(rows,trades,raw,prev);
        else gex(rows,full,priced,old,trades);
      } finally {c=before;}
    } catch(error){status('Calculation could not finish: '+error.message,true);}
  },15);
}
$('restore-data').onclick=()=>{demonstration=false;c.book='journal';c.date='';c.focus=null;note='';render();};
$('demo').onclick=()=>{demonstration=true;c={...c,book:'demo',date:'',contract:'',focus:null};note='';render();};
$('template').onclick=()=>download(headers.join(',')+'\n2026-11-12,SB,SBH27,18.22,2027-02-12,18,call,us,,1000,25,Example only,1120,,,\n','option-chain-template.csv');
$('upload').onchange=async e=>{
  const file=e.target.files[0];if(!file)return;
  status('Validating settlement data…');
  try{
    const sheets=await tables(file);
    const payload=sheets.flatMap(objects);
    const futures=read('dux-futures-v1',{});
    let added=0;
    const chain=[];
    for(const r of payload){
      if(r.expiry){chain.push(r);continue;}
      const symbol=String(r.contract??'').toUpperCase();
      const spec=specs[String(r.commodity??'').toUpperCase()];
      const f=Number(r.futures_settlement);
      const factor=Number(r.multiplier)||spec?.[1];
      if(!spec||!symbol||!r.source||!Number.isFinite(f)||!(f>0&&factor>0)||!/^\d{4}-\d\d-\d\d$/.test(r.date)||!Number.isFinite(Date.parse(r.date))||shift(r.date,0)!==r.date)continue;
      futures[r.date+'|'+symbol]={close:f,factor,source:r.source};added++;
    }
    for(const r of chain){
      const f=futures[r.date+'|'+String(r.contract??'').toUpperCase()];
      if(f&&r.futures_settlement&&Number(r.futures_settlement)!==f.close)throw Error('Futures and option sheets disagree on a settlement.');
      if(f&&!r.futures_settlement)r.futures_settlement=f.close;
      if(f&&!r.multiplier)r.multiplier=f.factor;
    }
    const parsed=normalize(chain,c.rate/100);
    if(!parsed.rows.length&&!added)throw Error(parsed.issues.slice(0,3).join(' ')||'No valid rows match the import template.');
    
    const merged=new Map(imported.map(r=>[settlementKey(r),r]));
    for(const r of parsed.rows)merged.set(settlementKey(r),r);
    const next=[...merged.values()];
    const check=new Map();
    for(const r of next){
      const k=[r.date,r.commodity,r.contract].join('|'),v=r.f+'|'+r.factor;
      if(check.has(k)&&check.get(k)!==v)throw Error('A corrected closing mark must replace every series for its contract and session.');
      check.set(k,v);
    }
    const storedFutures=save('dux-futures-v1',futures);
    imported=next;
    const stored=save('dux-chain-v1',imported);
    demonstration=!imported.length;c.date='';c.focus=null;
    note=parsed.rows.length+' option rows and '+added+' futures marks loaded'+(parsed.issues.length?' · '+parsed.issues.length+' validation notes. '+parsed.issues.slice(0,2).join(' '):'')+(stored&&storedFutures?'':' · Browser storage is full. This import lasts for the current tab.');
    render();
  }catch(err){status(err.message,true);}finally{e.target.value='';}
};
document.addEventListener('change',e=>{
  const k=e.target.dataset.key;
  if(!k)return;
  if(e.target.type==='number'&&(!e.target.checkValidity()||!Number.isFinite(e.target.valueAsNumber)))return;
  if(k==='focusStrike'){c.focus=e.target.value?{strike:Number(e.target.value),expiry:c.expiry==='all'?null:c.expiry}:null;}
  else c[k]=e.target.type==='checkbox'?e.target.checked:e.target.type==='number'?e.target.valueAsNumber:e.target.value;
  if(['commodity','contract','date','expiry'].includes(k)){
    c.focus=null;
    if(k==='commodity'||k==='contract'){c.date='';c.trade='all';}
    if(k==='date')c.comparison='previous';
  }
  if(k==='book'||k==='scope')c.trade='all';
  render();
});
document.addEventListener('click',e=>{
  const target=e.target.closest('button');
  if(target?.dataset.tab){clearInterval(playback);c.tab=target.dataset.tab;if(c.trade==='aggregate'&&c.tab!=='greeks')c.trade='all';render();}
  if(target?.id==='animate'){
    clearInterval(playback);
    const dates=uniq(selected().filter(r=>r.contract===c.contract),'date');
    if(dates.length<2){status('At least two snapshots are needed for animation.',true);return;}
    let i=0;
    playback=setInterval(()=>{if(i>=dates.length){clearInterval(playback);return;}c.date=dates[i++];c.comparison='previous';render();},950);
  }
});
$('csv').onclick=()=>{if(exported.length)download(csv(exported),'dux-'+c.tab+'.csv');};
$('excel').onclick=()=>{if(exported.length)excel(exported,'dux-'+c.tab);};
$('png').onclick=()=>{if(fallback){const a=document.createElement('a');a.href=fallback.canvas.toDataURL();a.download='dux-'+c.tab+'.png';a.click();return;}if(plot.data?.length)Plotly.downloadImage(plot,{format:'png',filename:'dux-'+c.tab,scale:2});};
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('plot-panel').requestFullscreen();}catch{status('Full screen is unavailable in this browser.',true);}};
function theme(){document.body.classList.toggle('dark',c.dark);$('theme').textContent=c.dark?'Light mode':'Dark mode';}
$('theme').onclick=()=>{c.dark=!c.dark;theme();render();};
window.addEventListener('storage',e=>{if(['commodity-trading-journal-v1','commodity-options-v2'].includes(e.key))render();});
if(!imported.length&&c.book==='journal'&&!journal().positions.length)c.book='demo';
if(!Object.hasOwn(labels,c.tab))c.tab='overview';
theme();render();
