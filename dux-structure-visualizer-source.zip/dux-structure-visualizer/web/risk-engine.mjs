import {optionPoint,optionValue,daysBetween,intrinsic,marginCall,collateralCall} from './options-engine.mjs';
import {crosses} from './engine.mjs';

export const specs={
  SB:['ICE Sugar No. 11',1120,'¢/lb',18.5,'SBH27'],
  W:['ICE White Sugar No. 5',50,'USD/MT',510,'WH27'],
  ZW:['CBOT SRW Wheat',50,'¢/bu',575,'ZWH27'],
  ZC:['CBOT Corn',50,'¢/bu',475,'ZCH27'],
  ZS:['CBOT Soybeans',50,'¢/bu',1110,'ZSH27'],
  ZL:['CBOT Soybean Oil',600,'¢/lb',52,'ZLH27'],
  ZM:['CBOT Soybean Meal',100,'USD/short ton',310,'ZMH27']
};
export const shift=(date,n)=>new Date(Date.parse(date+'T00:00:00Z')+n*86400000).toISOString().slice(0,10);
const validDate=s=>/^\d{4}-\d\d-\d\d$/.test(s)&&Number.isFinite(Date.parse(s))&&shift(s,0)===s;
const num=x=>x==null||String(x).trim()===''?null:Number(x);
export const sum=(rows,fn)=>rows.reduce((a,r)=>a+fn(r),0);
export const headers='date,commodity,contract,futures_settlement,expiry,strike,type,style,option_settlement,open_interest,iv_percent,source,multiplier,dealer_share,initial_margin,maintenance_margin'.split(',');

export function implied(row) {
  const target=row.settle;
  if(target==null||target<=0) return null;
  const value=iv=>optionValue(row,row.f,row.date,row.rate,iv/100,80);
  let lo=.01,hi=400;
  const low=value(lo),high=value(hi);
  if(target<=low+Math.max(1e-8,row.f*1e-8)||target>high) return null;
  for(let i=0;i<32;i++){
    const mid=(lo+hi)/2;
    if(value(mid)>target) hi=mid; else lo=mid;
  }
  return (lo+hi)/2;
}

export function normalize(input,rate=.04) {
  const out=[],issues=[];
  const seen=new Set(), groups=new Map();
  for(const [i,x] of input.entries()){
    const commodity=String(x.commodity??'').toUpperCase().trim();
    const spec=specs[commodity];
    const row={date:String(x.date??''),commodity,contract:String(x.contract??'').trim().toUpperCase(),f:num(x.futures_settlement),
      expiry:String(x.expiry??''),strike:num(x.strike),type:String(x.type??'').toLowerCase(),style:String(x.style??'').toLowerCase(),settle:num(x.option_settlement),oi:num(x.open_interest),
      iv:num(x.iv_percent),source:String(x.source??'').trim(),factor:num(x.multiplier)??spec?.[1],share:num(x.dealer_share),im:num(x.initial_margin),mm:num(x.maintenance_margin),rate};
    if(row.style==='american') row.style='us';
    if(row.style==='european') row.style='eu';
    const group=[row.date,commodity,row.contract].join('|');
    const identity=[group,row.expiry,row.strike,row.type].join('|');
    const optional=[row.settle,row.oi,row.iv,row.share,row.im,row.mm];
    if(!spec||!row.contract||!row.source||!validDate(row.date)||!validDate(row.expiry)||row.expiry<=row.date||!(Number.isFinite(row.f)&&Number.isFinite(row.strike)&&Number.isFinite(row.factor)&&row.f>0&&row.strike>0&&row.factor>0)||!['call','put'].includes(row.type)||!['us','eu'].includes(row.style)||
       optional.some(n=>n!==null&&!Number.isFinite(n))||row.oi<0||row.settle<0||row.share< -1||row.share>1||row.im<0||row.mm<0||seen.has(identity)||(groups.has(group)&&groups.get(group)!==row.f+'|'+row.factor)) {
      issues.push('Row '+(i+2)+': invalid, duplicate or inconsistent contract/date inputs.');
      continue;
    }
    row.ivSource=row.iv==null?'Inverted settlement':'Imported IV';
    if(row.iv==null) row.iv=implied(row);
    if(!(row.iv>=.01&&row.iv<=400)) {issues.push('Row '+(i+2)+': IV missing or settlement cannot be inverted.');continue;}
    if(row.oi===null) issues.push('Row '+(i+2)+': open interest missing. IV available, GEX incomplete.');
    seen.add(identity);
    groups.set(group,row.f+'|'+row.factor);
    out.push(row);
  }
  return {rows:out,issues};
}

export function demo() {
  const rows=[];
  for(const [commodity,s] of Object.entries(specs)) for(let session=0;session<5;session++) {
    const date=shift('2026-11-06',[0,3,4,5,6][session]);
    const f=s[3]*(1+.006*(session-2));
    for(const tenor of [25,53,85]) for(let k=-5;k<=5;k++) for(const type of ['call','put']){
      const strike=+(s[3]*(1+k*.035)).toFixed(2);
      const iv=22+Math.abs(k)*.85+tenor*.025+(type==='put'?1.4:0)+session*.25;
      const oi=Math.round(90+950*Math.exp(-((k-(type==='call'?2:-2))**2)/5)*(1-tenor/170)+session*7);
      const share=(type==='call'?1:-1)*(.2+Math.abs(k)*.04);
      rows.push({date,commodity,contract:s[4],f,expiry:shift('2026-11-12',tenor),strike,type,style:'us',settle:null,oi,iv,source:'Synthetic demonstration',ivSource:'Synthetic IV',factor:s[1],share,rate:.04});
    }
  }
  return rows;
}

export function weight(row,c) {
  if(c.position==='long') return 1;
  if(c.position==='short') return -1;
  if(c.position==='proxy') return row.share;
  return (row.type==='call'?c.call:c.put)/100;
}

export function market(rows,c,price,days=0,vol=0,steps=48) {
  return rows.map(r=>{
    const date=shift(r.date,days);
    const f=price??r.f;
    const g=optionPoint({...r,iv:Math.max(.01,r.iv+vol)},f,date,c.rate,steps);
    const w=weight(r,c);
    const lots=w==null||r.oi==null?null:w*r.oi;
    const equivalent=lots==null?null:lots*g.gamma*f*.01;
    return {...r,...g,lots,equivalent,exposure:equivalent==null?null:equivalent*f*r.factor,hedge:lots==null?null:-g.delta*lots};
  });
}

export function group(rows,key) {
  const buckets=new Map();
  for(const r of rows) {
    const k=r[key];
    if(!buckets.has(k)) buckets.set(k,[]);
    buckets.get(k).push(r);
  }
  return [...buckets].sort(([a],[b])=>typeof a==='number'?a-b:a.localeCompare(b));
}
export function flips(points) {
  const roots=[];
  const epsilon=Math.max(...points.map(p=>Math.abs(p[1])),1)*1e-9;
  let prior=null;
  for(const p of points) {
    if(Math.abs(p[1])<=epsilon) continue;
    if(prior&&prior[1]*p[1]<0) roots.push(prior[0]+(p[0]-prior[0])*(-prior[1])/(p[1]-prior[1]));
    prior=p;
  }
  return roots;
}
export const series=(a,b,n)=>Array.from({length:n},(_,i)=>a+(b-a)*i/(n-1));

export function advanced(r,f,date,rate) {
  const g=optionPoint(r,f,date,rate,72);
  if(daysBetween(date,r.expiry)<=0) return {...g,theta:0,vega:0,rho:0,vanna:0,charm:0,vomma:0};
  const t=shift(date,1), v=Math.min(.5,r.iv/2);
  const high=optionPoint({...r,iv:r.iv+v},f,date,rate,72);
  const low=optionPoint({...r,iv:r.iv-v},f,date,rate,72);
  const tomorrow=optionPoint(r,f,t,rate,72);
  return {...g,theta:tomorrow.price-g.price,vega:(high.price-low.price)/(2*v),
    rho:optionPoint(r,f,date,rate+.005,72).price-optionPoint(r,f,date,rate-.005,72).price,
    vanna:(high.delta-low.delta)/(2*v),charm:tomorrow.delta-g.delta,vomma:(high.price+low.price-2*g.price)/(v*v)};
}

export function diagnostics(rows,rate) {
  let butterfly=0, calendar=0, comparable=0;
  const slices=group(rows.filter(r=>r.style==='eu'&&r.type==='call'),'expiry');
  for(const [,slice] of slices){
    const s=[...slice].sort((a,b)=>a.strike-b.strike);
    const prices=s.map(r=>r.settle??optionPoint(r,r.f,r.date,rate).price);
    for(let i=1;i<s.length-1;i++){
      const l=(prices[i]-prices[i-1])/(s[i].strike-s[i-1].strike);
      const h=(prices[i+1]-prices[i])/(s[i+1].strike-s[i].strike);
      comparable++;
      if(l>1e-5||h>1e-5||h<l-1e-5) butterfly++;
    }
  }
  for(const [,slice] of group(rows.filter(r=>r.style==='eu'&&r.type==='call'),'strike')){
    const s=[...slice].sort((a,b)=>a.expiry.localeCompare(b.expiry));
    for(let i=1;i<s.length;i++) {
      const a=s[i-1],b=s[i];
      if(a.contract!==b.contract||a.f!==b.f) continue;
      comparable++;
      if(b.iv*b.iv*daysBetween(b.date,b.expiry)<a.iv*a.iv*daysBetween(a.date,a.expiry)-1e-6) calendar++;
    }
  }
  return {butterfly,calendar,comparable};
}

export function structureValue(t,f,date,rate,vol=t.iv,paths=192,elapsed=0,rollFrom=null) {
  const days=daysBetween(date,t.expiry);
  const count=t.remaining;
  if(!(days>0&&f>0&&vol>0&&Number.isInteger(count)&&count>0&&count<=120&&t.daily>0&&t.factor>0&&['none','close','touch'].includes(t.ko)&&['none','daily','expiry'].includes(t.timing))) return null;
  if(t.ko!=='none'&&(!(t.barrier>0)||t.barrierState!=='alive'||!['above','below'].includes(t.barrierDir)||!['stop','skip','resetDay','resetRest'].includes(t.action))) return null;
  if(t.timing!=='none'&&(!(t.trigger>0)||!(t.multiple>=1)||!['above','below'].includes(t.doubleDir)||(t.timing==='expiry'&&!(t.original>0)))) return null;
  if(!['physical','cash','coupon'].includes(t.settlement)) return null;
  if(t.settlement==='coupon'?!Number.isFinite(t.coupon):!Number.isFinite(t.fix)||(t.ko!=='none'&&t.action?.startsWith('reset')&&!Number.isFinite(t.reset))) return null;
  const originalDays=days+elapsed;
  const interval=originalDays/count;
  const variance=(vol/100)**2*interval/365;
  const std=Math.sqrt(variance);
  let seed=914702, value=0;
  const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return (seed+.5)/4294967296;};
  const cash=(p,k)=>t.settlement==='coupon'?t.coupon:(t.side==='short'?-1:1)*(p-k)*t.factor;
  for(let i=0;i<paths;i++){
    let start=rollFrom??f, alive=1;
    for(let j=0;j<count;j++){
      const time=(j+1)*interval;
      const z=Math.sqrt(-2*Math.log(rand()))*Math.cos(2*Math.PI*rand());
      if(alive<1e-12)continue;
      const beforeRoll=rollFrom!=null&&time<=elapsed;
      const dt=rollFrom!=null&&time-interval<elapsed?Math.max(0,time-elapsed):interval;
      const varStep=variance*dt/interval;
      const from=rollFrom!=null&&time-interval<elapsed&&time>elapsed?f:start;
      const end=beforeRoll?rollFrom:from*Math.exp(-varStep/2+std*Math.sqrt(dt/interval)*z);
      let hit=0;
      if(t.ko!=='none'){
        hit=Number(crosses(end,t.barrier,t.barrierDir,t.barrierEqual));
        if(t.ko==='touch'){
          if(crosses(from,t.barrier,t.barrierDir,true)) hit=1;
          else if(!hit&&varStep>0) hit=Math.exp(-2*Math.log(from/t.barrier)*Math.log(end/t.barrier)/varStep);
        }
      }
      const doubled=t.timing!=='none'&&crosses(end,t.trigger,t.doubleDir,t.doubleEqual);
      const extra=doubled?(t.timing==='daily'?t.daily:j===count-1?t.original:0)*(t.multiple-1):0;
      const reset=t.action==='resetRest'?t.daily*(count-j):t.action==='resetDay'?t.daily:0;
      value+=alive*Math.exp(-rate*Math.max(0,time-elapsed)/365)*((1-hit)*(t.daily+extra)*cash(end,t.fix)+(hit&&reset?hit*reset*cash(end,t.reset):0));
      if(t.action==='stop'||t.action==='resetRest') alive*=1-hit;
      start=end;
    }
  }
  return value/paths;
}

export function scenario(trades,c,shock,vol,elapsed=0,scenarioRate=c.rate) {
  const changes=[];
  for(const t of trades){
    const f=t.f*(1+shock*(t.shockWeight??1)/100);
    const date=shift(c.date,elapsed);
    let baseline,price;
    if(!(t.f>0&&f>0&&t.factor>0)){changes.push(null);continue;}
    if(t.kind==='future') {baseline=t.f;price=f;}
    if(t.kind==='option'){
      if(!(t.iv>0&&t.strike>0&&t.expiry>=c.date)) {changes.push(null);continue;}
      baseline=t.baseline??optionPoint(t,t.f,c.date,c.rate,48).price;
      price=optionPoint({...t,iv:Math.max(.01,t.iv+vol)},f,date,scenarioRate,48).price;
    }
    if(t.kind==='structure'){
      baseline=t.baseline??structureValue(t,t.f,c.date,c.rate);
      price=structureValue(t,f,date,scenarioRate,Math.max(.01,t.iv+vol),192,elapsed,elapsed?t.f:null);
    }
    changes.push(baseline==null||price==null?null:(price-baseline)*(t.kind==='structure'?1:t.signed*t.factor));
  }
  return changes;
}

export function stressedCalls(trades,changes,accounts,date,prior) {
  const result=[];
  for(const [key,positions] of group(trades.map((t,i)=>({...t,change:changes[i]})),'accountKey')){
    const a=Object.hasOwn(accounts,key)?accounts[key]:null;
    if(!a||a.asof!==date||positions.some(t=>!Number.isFinite(t.change))){result.push(null);continue;}
    const pnl=sum(positions,t=>t.change);
    if(key.startsWith('otc|')){
      if(!Number.isFinite(a.threshold)||a.threshold<0||!Number.isFinite(a.posted)||a.posted<0||positions.some(t=>!Number.isFinite(t.mtm))){result.push(null);continue;}
      result.push(collateralCall(sum(positions,t=>t.mtm)+pnl,a.threshold,a.posted,a.independent??0,a.mta??0).call);
    } else {
      const movement=a.broker??a.movement;
      if(a.prior!==prior||a.maintenance<0||a.target<a.maintenance||![a.equity,a.maintenance,a.target,movement].every(Number.isFinite)){result.push(null);continue;}
      result.push(marginCall(a.equity,movement+pnl,a.maintenance,a.target,a.other??0).call);
    }
  }
  return result.length&&result.every(Number.isFinite)?sum(result,x=>x):null;
}
