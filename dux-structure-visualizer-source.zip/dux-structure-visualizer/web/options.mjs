import {products,daysBetween,optionBook,marketMove,marginCall,collateralCall,shockValue} from './options-engine.mjs';

const $=id=>document.getElementById(id);
const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const num=(v,d=2)=>new Intl.NumberFormat('en-US',{maximumFractionDigits:d}).format(v);
const usd=v=>(v<0?'−':'')+'$'+num(Math.abs(v));
const moneyClass=v=>v<-.005?'negative':v>.005?'positive':'';
const dateNow=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const plusDate=(date,n)=>new Date(Date.parse(date+'T00:00:00Z')+86400000*n).toISOString().slice(0,10);
const lookupKey='commodity-options-v2';
const otcInputs=['mtm','threshold','posted','ia','mta'];
const colors=['#426d88','#477757','#846383','#a57334','#537477','#875651','#626e91','#75715a'];
let mode='theory', cache=null, frame=0, feedSeq=0, feedRunning=false;
let state=load()??demo();

function demo() {
  return {asof:'2026-11-11',prior:'2026-11-10',rate:4,auto:true,
    markets:[{id:1,symbol:'SBH27',product:'SB',close:18.50,previous:18.20,factor:1120,source:'Sample data'}],
    legs:[
      {id:1,contract:1,side:'long',type:'call',style:'us',lots:4,strike:18,expiry:'2027-02-12',iv:26,premium:.94},
      {id:2,contract:1,side:'short',type:'call',style:'us',lots:4,strike:19,expiry:'2027-02-12',iv:25,premium:.54},
      {id:3,contract:1,side:'long',type:'put',style:'us',lots:4,strike:17.5,expiry:'2027-02-12',iv:28,premium:.48},
      {id:4,contract:1,side:'short',type:'put',style:'us',lots:4,strike:16.5,expiry:'2027-02-12',iv:29,premium:.23}
    ],margin:{},otc:{}};
}
function load() {
  try {
    const data=JSON.parse(localStorage.getItem(lookupKey));
    for(const m of data?.markets??[]) m.source=({'Elle girildi':'Manual','Örnek veri':'Sample data','Kapanış bekleniyor':'Waiting for close'})[m.source]??m.source?.replace('ICE grafik','ICE chart');
    return data?.markets?.length&&data?.legs&&data.margin?{otc:{},...data}:null;
  } catch { return null; }
}
function save() {
  try { localStorage.setItem(lookupKey,JSON.stringify(state)); } catch {}
}
function nextId(rows) {
  return Math.max(0,...rows.map(r=>r.id))+1;
}
function field(label,key,value,params='step="any"',type='number') {
  return '<input aria-label="'+esc(label)+'" data-key="'+key+'" type="'+type+'" value="'+esc(value)+'" '+params+'>';
}
function select(label,key,value,items) {
  return '<select aria-label="'+esc(label)+'" data-key="'+key+'">'+items.map(([id,name])=>'<option value="'+esc(id)+'"'+(String(id)===String(value)?' selected':'')+'>'+esc(name)+'</option>').join('')+'</select>';
}
function marketRows() {
  $('market-rows').innerHTML=state.markets.map((m,i)=>{
    const n='Contract '+(i+1)+' ';
    return '<tr data-id="'+m.id+'"><td>'+field(n+'symbol','symbol',m.symbol,'class="market-symbol" maxlength="14"','text')+'</td><td>'+select(n+'product','product',m.product,Object.entries(products).map(([id,p])=>[id,p.name]))+'</td><td>'+field(n+'current close','close',m.close)+'</td><td>'+field(n+'prior close','previous',m.previous)+'</td><td>'+field(n+'multiplier','factor',m.factor)+'</td><td><small data-market-source>'+esc(m.source??'Manual')+'</small></td><td><button type="button" class="row-delete" data-remove aria-label="'+n+'sil"'+(state.markets.length===1||state.legs.some(l=>l.contract===m.id)?' disabled title="Reassign the legs using this contract first"':'')+'>×</button></td></tr>';
  }).join('');
}
function legRows() {
  const choices=state.markets.map(m=>[m.id,m.symbol||'Contract '+m.id]);
  $('legs').innerHTML=state.legs.map((l,i)=>{
    const n='Leg '+(i+1)+' ';
    return '<tr data-id="'+l.id+'"><td class="row-id">'+(i+1)+'</td><td>'+select(n+'contract','contract',l.contract,choices)+'</td><td>'+select(n+'side','side',l.side,[['long','Long'],['short','Short']])+'</td><td>'+select(n+'type','type',l.type,[['call','Call'],['put','Put']])+'</td><td>'+select(n+'style','style',l.style,[['us','American'],['eu','European']])+'</td><td>'+field(n+'lot','lots',l.lots)+'</td><td>'+field(n+'strike','strike',l.strike)+'</td><td>'+field(n+'expiry','expiry',l.expiry,'','date')+'</td><td>'+field(n+'IV','iv',l.iv)+'</td><td>'+field(n+'entry premium','premium',l.premium)+'</td><td><button type="button" class="row-delete" data-remove aria-label="'+n+'sil">×</button></td></tr>';
  }).join('');
  $('marks').innerHTML=state.legs.map((l,i)=>{
    const n='Leg '+(i+1)+' ';
    const old=l.mark!=null&&l.markDate!==state.asof?' · current mark '+l.markDate:'';
    const oldPrior=l.previousMark!=null&&l.priorMarkDate!==state.prior?' · prior mark '+l.priorMarkDate:'';
    const oldIV=l.previousIV!=null&&l.priorIVDate!==state.prior?' · prior IV '+l.priorIVDate:'';
    return '<tr data-id="'+l.id+'"><td class="row-id">'+(i+1)+esc(old+oldPrior+oldIV)+'</td><td>'+field(n+'current mark','mark',l.mark)+'</td><td>'+field(n+'prior mark','previousMark',l.previousMark)+'</td><td>'+field(n+'prior IV','previousIV',l.previousIV)+'</td></tr>';
  }).join('');
  $('add-leg').disabled=state.legs.length>=12;
  $('add-market').disabled=state.markets.length>=8;
}

function loadControls() {
  $('asof').value=state.asof;
  $('prior-date').value=state.prior;
  $('rate').value=state.rate??'';
  $('auto').checked=state.auto;
  for(const id of ['equity','maintenance','target','other','broker']) $(id).value=state.margin[id]??'';
  for(const key of otcInputs) $('otc-'+key).value=state.otc[key]??'';
  marketRows();
  legRows();
  drawOtc();
  drawSoon();
}
function drawSoon() {
  save();
  cancelAnimationFrame(frame);
  frame=requestAnimationFrame(draw);
}
function asInput(element) {
  return element.type==='number'?(Number.isFinite(element.valueAsNumber)?element.valueAsNumber:null):element.value;
}
function message(value,warn=false) {
  $('feed-status').textContent=value;
  $('feed-status').dataset.state=warn?'warn':'ok';
}
function usedMarkets() {
  const used=new Set(state.legs.map(l=>l.contract));
  return state.markets.filter(m=>used.has(m.id));
}
function eligible(m) {
  return m.product==='SB'?/^SB[FHKNV]\d\d$/.test(m.symbol):m.product==='W'&&/^W[HKQVZ]\d\d$/.test(m.symbol);
}

async function refresh(force=false) {
  if(feedRunning&&!force) return;
  if(!state.auto&&!force) { message('Manual mode is active.'); return; }
  const market=usedMarkets();
  if(!market.length||market.some(m=>!eligible(m))) {
    message('Automatic updates require valid ICE sugar symbols for every active leg, such as SBH27 or WK27.',true);
    return;
  }
  const seq=++feedSeq;
  const identity=market.map(m=>m.id+':'+m.symbol).join(',');
  const symbols=market.map(m=>m.symbol);
  feedRunning=true;
  $('refresh').disabled=true;
  message('Fetching ICE historical closes…');
  try {
    const query=new URLSearchParams({symbols:symbols.join(',')});
    if(force) query.set('refresh','1');
    const response=await fetch('./api/market/settlements?'+query,{signal:AbortSignal.timeout(23000)});
    if(!response.ok) throw new Error('HTTP '+response.status);
    const {quotes,through,errors}=await response.json();
    if(seq!==feedSeq||identity!==usedMarkets().map(m=>m.id+':'+m.symbol).join(',')) return;
    const rows=symbols.map(s=>quotes?.[s]);
    if(rows.some(r=>!r)||rows.some(r=>r.date!==rows[0].date||r.previousDate!==rows[0].previousDate)) {
      message('Common session closes are unavailable. Existing marks are retained.',true);
      return;
    }
    if(!force&&market.some(m=>m.source==='Manual')) {
      message('Manual closes are retained. Select Refresh closes to apply ICE marks.');
      return;
    }
    const age=daysBetween(rows[0].date,through);
    const warning=Object.keys(errors??{}).length>0||age>3;
    if(warning&&market.some(m=>m.source==='Manual')) {
      message('ICE could not supply a common close. Manual marks are retained.',true);
      return;
    }
    state.asof=rows[0].date;
    state.prior=rows[0].previousDate??'';
    market.forEach((m,i)=>{m.close=rows[i].close;m.previous=rows[i].previous;m.source='ICE chart · '+rows[i].date;});
    loadControls();
    message((warning?'Last verified':'Automatically applied')+' ICE chart close '+state.asof+' · Prior session '+(state.prior||'unavailable')+(warning?' · Newer data could not be verified.':''),warning);
  } catch {
    if(seq===feedSeq) message('The ICE feed is unavailable. Existing marks are retained.',true);
  } finally {
    if(seq===feedSeq) { feedRunning=false; $('refresh').disabled=false; }
  }
}
function cancelFeed() {
  if(feedRunning){ feedSeq++; feedRunning=false; $('refresh').disabled=false; }
}

function config() {
  if(!state.asof||!Number.isFinite(state.rate)||state.rate< -20||state.rate>100) throw new Error('Enter a valuation date and annual rate between −20% and 100%.');
  if(!state.legs.length) throw new Error('Add at least one option.');
  const market=Object.fromEntries(state.markets.map(m=>[m.id,m]));
  const names=usedMarkets().map(m=>m.symbol);
  if(new Set(names).size!==names.length) throw new Error('Link legs with the same symbol to one closing-mark row.');
  const legs=state.legs.map((l,i)=>{
    const name='Leg '+(i+1);
    const m=market[l.contract];
    if(!m?.symbol||!(m.close>0&&m.close<=1e6)||!(m.factor>0&&m.factor<=1e9)) throw new Error(name+' needs a positive close and contract multiplier.');
    if(!(l.strike>0&&l.strike<=1e6)||!(l.lots>0&&l.lots<=1e6)||!(l.iv>=.01&&l.iv<=400)||!(l.premium>=0&&l.premium!=null)) throw new Error(name+' needs strike, lots, IV between 0.01% and 400%, and entry premium.');
    const days=daysBetween(state.asof,l.expiry);
    if(!Number.isFinite(days)||days>3650) throw new Error(name+' needs an expiry within ten years.');
    if(days<0) throw new Error(name+' expired before the valuation date. Use the actual expiry closing mark or remove the expired leg.');
    for(const field of ['mark','previousMark']) if(l[field]!=null&&l[field]<0) throw new Error(name+' broker premium must be zero or positive.');
    if(l.previousIV!=null&&!(l.previousIV>=.01&&l.previousIV<=400)) throw new Error(name+' prior IV must be between 0.01% and 400%.');
    return {...l,mark:l.markDate===state.asof?l.mark:null,previousMark:l.priorMarkDate===state.prior?l.previousMark:null,previousIV:l.priorIVDate===state.prior?l.previousIV:null};
  });
  return {market,legs,rate:state.rate/100,asof:state.asof,prior:state.prior};
}

const tile=(label,value,cls='',extra='')=>'<div class="opt-tile '+extra+'"><small>'+esc(label)+'</small><strong class="'+cls+'">'+esc(value)+'</strong></div>';
function draw() {
  let c;
  try {c=config();}
  catch(err) {
    cache=null;
    $('opt-results').hidden=true;
    $('opt-error').hidden=false;
    $('opt-error').textContent=err.message;
    drawMargin();
    return;
  }
  $('opt-error').hidden=true;
  $('opt-results').hidden=false;
  const book=optionBook(c.legs,c.market,c.asof,c.rate);
  const sum=key=>book.reduce((n,b)=>n+b[key],0);
  const symbols=usedMarkets();
  const grouped=Object.fromEntries(symbols.map(m=>[m.id,{delta:0,gamma:0,undefinedAtStrike:false}]));
  book.forEach(b=>{
    grouped[b.contract].delta+=b.deltaLots;
    grouped[b.contract].gamma+=b.gammaLots;
    grouped[b.contract].undefinedAtStrike||=Boolean(b.atStrike);
  });
  $('greek-date').textContent=c.asof+' · '+book.length+' legs';
  $('chart-market').textContent=symbols.map(m=>m.symbol+' '+num(m.close,3)+' '+products[m.product].unit).join(' · ');
  const result=sum('pl');
  $('opt-summary').innerHTML=tile('P/L since entry',usd(result),moneyClass(result))+tile('Net mark',usd(sum('mtm')))+
    tile('Theta / day',usd(sum('thetaCash')))+tile('Vega / vol point',usd(sum('vegaCash')))+tile('Rho / rate point',usd(sum('rhoCash')))+
    symbols.map(m=>{
      const g=grouped[m.id];
      return tile(m.symbol+' · Delta / Gamma',g.undefinedAtStrike?'At strike':num(g.delta,3)+' / '+num(g.gamma,4),'','wide');
    }).join('');
  $('greek-rows').innerHTML=book.map((b,i)=>'<tr><td>'+(i+1)+' · '+b.side+' '+b.type+'</td><td>'+esc(c.market[b.contract].symbol)+'</td><td>'+num(b.price,4)+'</td><td>'+num(b.marked,4)+(b.mark!=null?' · Broker':' · Model')+'</td><td>'+(b.atStrike?'—':num(b.deltaLots,4))+'</td><td>'+(b.atStrike?'—':num(b.gammaLots,4))+'</td><td>'+usd(b.thetaCash)+'</td><td>'+usd(b.vegaCash)+'</td><td>'+usd(b.rhoCash)+'</td><td class="'+moneyClass(b.pl)+'">'+usd(b.pl)+'</td></tr>').join('');
  $('expiry-note').textContent=book.some(b=>b.expiry===c.asof)?'At expiry the closing futures mark determines intrinsic value. Delta and gamma are undefined exactly at the strike.':'P/L uses supplied broker marks. Greeks come from the model.';
  const shocks=Array.from({length:65},(_,i)=>-20+i*.625);
  cache={c,book,shocks,curves:shocks.map(p=>book.map(b=>shockValue([b],c.market,c.asof,c.rate,p,0,mode))),
    movement:marketMove(book,c.market,c.asof,c.prior,c.rate)};
  drawChart();
  drawMargin();
}

function drawChart() {
  if(!cache) return;
  const {c,book,shocks,curves}=cache;
  const svg=$('portfolio-chart');
  const width=Math.max(270,svg.clientWidth||640);
  const height=svg.clientHeight||265;
  const left=width<500?56:68, right=width-18, top=19, bottom=height-38;
  const totals=curves.map(row=>row.reduce((a,b)=>a+b,0));
  const individual=$('show-legs').checked;
  const values=[0,...totals,...(individual?curves.flat():[])];
  const minimum=Math.min(...values), maximum=Math.max(...values);
  const pad=(maximum-minimum)*.11||1;
  const yMin=minimum-pad, yMax=maximum+pad;
  const x=p=>left+(p+20)/40*(right-left);
  const y=v=>bottom-(v-yMin)/(yMax-yMin)*(bottom-top);
  const points=(data)=>data.map((v,i)=>x(shocks[i]).toFixed(2)+','+y(v).toFixed(2)).join(' ');
  const shock=Number($('shock').value);
  const contracts=usedMarkets();
  $('shock-caption').textContent=(shock>0?'+':'')+num(shock)+'% · '+contracts.map(m=>m.symbol+' '+num(m.close*(1+shock/100),3)).join(' · ');
  $('leg-key').innerHTML=individual?book.map((b,i)=>'<span><i style="border-color:'+colors[i%colors.length]+'"></i>'+esc((i+1)+' · '+b.side+' '+b.type+' '+num(b.strike))+'</span>').join(''):'';
  const result=shockValue(book,c.market,c.asof,c.rate,shock,0,mode);
  $('shock').setAttribute('aria-valuetext',num(shock)+' percent');
  $('shock-output').textContent=usd(result);
  $('shock-output').className='shock-output '+moneyClass(result);
  let markup='<title id="portfolio-title">Option portfolio P/L curve</title><desc id="portfolio-desc">Selected price shock: '+num(shock)+'%. Portfolio P/L: '+esc(usd(result))+'. Use the slider to change the price shock.</desc>';
  for(let i=0;i<=4;i++) {
    const v=yMin+(yMax-yMin)*i/4;
    const tick=new Intl.NumberFormat('en-US',{notation:'compact',maximumFractionDigits:1}).format(v);
    markup+='<line x1="'+left+'" x2="'+right+'" y1="'+y(v)+'" y2="'+y(v)+'" stroke="#dce0d3"/><text x="'+(left-7)+'" y="'+(y(v)+4)+'" text-anchor="end" fill="#596358" font-size="11">'+tick+'</text>';
  }
  markup+='<line x1="'+left+'" x2="'+right+'" y1="'+y(0)+'" y2="'+y(0)+'" stroke="#899887" stroke-width="1.1"/>';
  for(let p=-20;p<=20;p+=10) {
    markup+='<line x1="'+x(p)+'" x2="'+x(p)+'" y1="'+top+'" y2="'+bottom+'" stroke="#dce0d3"/><text x="'+x(p)+'" y="'+(bottom+15)+'" text-anchor="middle" fill="#596358" font-size="11">%'+p+'</text>';
  }
  if(individual) for(let j=0;j<book.length;j++){
    markup+='<polyline points="'+points(curves.map(row=>row[j]))+'" fill="none" stroke="'+colors[j%colors.length]+'" opacity=".7" stroke-width="1.45" stroke-dasharray="5 3"><title>Leg '+(j+1)+'</title></polyline>';
  }
  markup+='<polygon points="'+left+','+y(0)+' '+points(totals)+' '+right+','+y(0)+'" fill="#ecc1a0" opacity=".42"/>';
  markup+='<polyline points="'+points(totals)+'" fill="none" stroke="#a84b24" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>';
  markup+='<line x1="'+x(shock)+'" x2="'+x(shock)+'" y1="'+top+'" y2="'+bottom+'" stroke="#a84b24" stroke-dasharray="3 3"/><circle cx="'+x(shock)+'" cy="'+y(result)+'" r="5" fill="#a84b24" stroke="#fffefa" stroke-width="2"/>';
  markup+='<text x="'+left+'" y="12" fill="#596358" font-size="11" font-weight="700">USD</text><text x="'+((left+right)/2)+'" y="'+(height-7)+'" text-anchor="middle" fill="#596358" font-size="11">Underlying price shock</text>';
  svg.setAttribute('viewBox','0 0 '+width+' '+height);
  svg.innerHTML=markup;
  $('chart-note').textContent=mode==='expiry'?'Each leg uses the same percentage shock at its own expiry.':'A parallel price shock is applied with fixed IV and time. Theoretical change is added to the broker mark when supplied.';
}

function drawMargin() {
  const m=state.margin;
  const valid=[m.equity,m.maintenance,m.target].every(Number.isFinite)&&m.maintenance>=0&&m.target>=m.maintenance;
  const staleEquity=m.equity!=null&&m.equityDate!==state.prior;
  const staleCash=(m.broker!=null&&m.brokerDate!==state.asof)||(m.other!=null&&m.otherDate!==state.asof);
  const movement=m.broker??cache?.movement?.value;
  const available=Number.isFinite(movement);
  $('stress-wrap').hidden=true;
  if(staleEquity||staleCash) {
    $('margin-result').innerHTML='<p class="status-strip" data-state="warn">The session changed. Enter equity and cash moves for the new session.</p>';
    $('margin-note').textContent='';
    return;
  }
  if(!valid||!available) {
    $('margin-result').innerHTML='<p class="status-strip">'+(!valid?'Enter prior equity, the threshold and a target at or above it.':'Enter both closes, both broker option marks, or the broker net move.')+'</p>';
    $('margin-note').textContent='';
    return;
  }
  const current=marginCall(m.equity,movement,m.maintenance,m.target,m.other??0);
  $('margin-result').innerHTML=tile('Daily net move',usd(movement),moneyClass(movement))+tile('Projected equity',usd(current.adjusted))+tile('Shortfall to threshold',usd(current.shortfall),current.shortfall?'negative':'')+tile('Estimated call',usd(current.call),current.call?'negative':'positive');
  $('margin-note').textContent=m.broker!=null?'Using the entered broker net move.':cache?.movement?.modelled?'Some session P/L is modelled. Current IV is used when prior IV is missing.':'Session P/L uses broker option marks.';
  if(!cache) return;
  const {c,book}=cache;
  const scenarios=[[-5,3],[-2,0],[0,3],[0,-3],[2,0],[5,3]];
  $('stress').innerHTML=scenarios.map(([p,v])=>{
    const shock=shockValue(book,c.market,c.asof,c.rate,p,v,'stress',100);
    const risk=marginCall(current.adjusted,shock,m.maintenance,m.target);
    return '<tr><td>'+num(p)+'%</td><td>'+num(v)+' puan</td><td class="'+moneyClass(shock)+'">'+usd(shock)+'</td><td>'+usd(risk.adjusted)+'</td><td class="'+(risk.call?'negative':'')+'">'+usd(risk.call)+'</td></tr>';
  }).join('');
  $('stress-wrap').hidden=false;
}

$('market-rows').addEventListener('input',e=>{
  const key=e.target.dataset.key;
  if(!key||key==='symbol'||key==='product') return;
  cancelFeed();
  const row=e.target.closest('tr');
  const m=state.markets.find(x=>x.id===Number(row.dataset.id));
  m[key]=asInput(e.target);
  if(key==='close'||key==='previous'){
    m.source='Manual';
    row.querySelector('[data-market-source]').textContent=m.source;
    message('Manual close retained. Select Refresh closes to apply ICE prices.');
  }
  drawSoon();
});
$('market-rows').addEventListener('change',e=>{
  const key=e.target.dataset.key;
  if(!['symbol','product'].includes(key)) return;
  cancelFeed();
  const m=state.markets.find(x=>x.id===Number(e.target.closest('tr').dataset.id));
  if(key==='product') {
    m.product=e.target.value;
    m.symbol=products[m.product].defaultMonth;
    m.factor=products[m.product].factor;
  } else m.symbol=e.target.value.trim().toUpperCase();
  m.close=null;
  m.previous=null;
  m.source='Waiting for close';
  for(const l of state.legs.filter(l=>l.contract===m.id)){delete l.mark;delete l.previousMark;}
  marketRows();
  legRows();
  drawSoon();
  refresh();
});
$('market-rows').addEventListener('click',e=>{
  if(!e.target.hasAttribute('data-remove')) return;
  const id=Number(e.target.closest('tr').dataset.id);
  state.markets=state.markets.filter(m=>m.id!==id);
  marketRows();
  legRows();
  drawSoon();
});
$('add-market').addEventListener('click',()=>{
  if(state.markets.length>=8) return;
  state.markets.push({id:nextId(state.markets),product:'W',symbol:'WH27',factor:50,source:'Waiting for close'});
  marketRows();
  legRows();
  drawSoon();
});
$('add-leg').addEventListener('click',()=>{
  if(state.legs.length>=12) return;
  const contract=usedMarkets()[0]??state.markets[0];
  const asof=state.asof||dateNow();
  state.legs.push({id:nextId(state.legs),contract:contract.id,side:'long',type:'call',style:'us',lots:1,strike:contract.close??null,expiry:plusDate(asof,90),iv:25,premium:0});
  marketRows();
  legRows();
  drawSoon();
});
$('legs').addEventListener('input',e=>{
  const key=e.target.dataset.key;
  if(!key) return;
  const l=state.legs.find(x=>x.id===Number(e.target.closest('tr').dataset.id));
  l[key]=key==='contract'?Number(e.target.value):asInput(e.target);
  if(['contract','type','strike','expiry'].includes(key)){
    delete l.mark;
    delete l.previousMark;
    $('marks').querySelectorAll('tr').forEach(r=>{
      if(Number(r.dataset.id)===l.id) r.querySelectorAll('[data-key=mark],[data-key=previousMark]').forEach(el=>{el.value='';});
    });
  }
  if(key==='contract'){ cancelFeed(); marketRows(); refresh(); }
  drawSoon();
});
$('legs').addEventListener('click',e=>{
  if(!e.target.hasAttribute('data-remove')) return;
  const id=Number(e.target.closest('tr').dataset.id);
  state.legs=state.legs.filter(l=>l.id!==id);
  marketRows();
  legRows();
  drawSoon();
});
$('marks').addEventListener('input',e=>{
  const key=e.target.dataset.key;
  if(!key) return;
  const l=state.legs.find(x=>x.id===Number(e.target.closest('tr').dataset.id));
  l[key]=asInput(e.target);
  if(key==='mark') l.markDate=state.asof;
  if(key==='previousMark') l.priorMarkDate=state.prior;
  if(key==='previousIV') l.priorIVDate=state.prior;
  drawSoon();
});
for(const [id,key] of [['asof','asof'],['prior-date','prior'],['rate','rate']]) $(id).addEventListener('change',e=>{
  cancelFeed();
  state[key]=asInput(e.target);
  if(id!=='rate') { state.auto=false; $('auto').checked=false; legRows(); message('Manual valuation date selected. Automatic updates are paused.'); }
  drawSoon();
});
$('auto').addEventListener('change',e=>{
  cancelFeed();
  state.auto=e.target.checked;
  save();
  refresh();
});
$('refresh').addEventListener('click',()=>refresh(true));
$('demo').addEventListener('click',()=>{
  cancelFeed();
  const {margin,otc}=state;
  state=demo();
  state.margin=margin;
  state.otc=otc;
  loadControls();
  refresh();
});
for(const btn of document.querySelectorAll('[data-mode]')) btn.addEventListener('click',()=>{
  mode=btn.dataset.mode;
  updateMode();
  drawSoon();
});
function updateMode(){
  for(const btn of document.querySelectorAll('[data-mode]')) btn.setAttribute('aria-pressed',String(btn.dataset.mode===mode));
}
$('show-legs').addEventListener('change',drawChart);
$('shock').addEventListener('input',drawChart);
for(const id of ['equity','maintenance','target','other','broker']) $(id).addEventListener('input',e=>{
  state.margin[id]=asInput(e.target);
  if(id==='equity') state.margin.equityDate=state.prior;
  if(id==='broker'||id==='other') state.margin[id+'Date']=state.asof;
  save();
  drawMargin();
});
$('margin-demo').addEventListener('click',()=>{
  state.margin={equity:18000,maintenance:15000,target:20000,broker:-7000,other:0,equityDate:state.prior,brokerDate:state.asof,otherDate:state.asof};
  for(const id of ['equity','maintenance','target','broker','other']) $(id).value=state.margin[id];
  save();
  drawMargin();
});
function drawOtc() {
  const m=state.otc;
  if(!Number.isFinite(m.mtm)||![m.threshold,m.posted,m.ia??0,m.mta??0].every(n=>Number.isFinite(n)&&n>=0)) {
    $('otc-result').innerHTML='<p class="status-strip">Enter MTM, CSA threshold and posted collateral. Other blank inputs count as zero.</p>';
    return;
  }
  const r=collateralCall(m.mtm,m.threshold,m.posted,m.ia??0,m.mta??0);
  $('otc-result').innerHTML=tile('Required collateral',usd(r.required))+tile('Collateral shortfall',usd(r.uncovered))+tile('Estimated cash call',usd(r.call),r.call?'negative':'positive');
}
for(const key of otcInputs) $('otc-'+key).addEventListener('input',e=>{
  state.otc[key]=asInput(e.target);
  save();
  drawOtc();
});
new ResizeObserver(drawChart).observe($('portfolio-chart'));
updateMode();
loadControls();
refresh();
setInterval(()=>{if(!document.hidden) refresh();},15*60000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden) refresh();});
