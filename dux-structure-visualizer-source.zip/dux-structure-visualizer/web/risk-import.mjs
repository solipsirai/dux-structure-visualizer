import {shift} from './risk-engine.mjs';

export function delimited(text) {
  const source=text.replace(/^\uFEFF/,'');
  const head=source.split(/\r?\n/,1)[0];
  const separator=head.includes('\t')?'\t':head.includes(';')?';':',';
  const rows=[];
  let row=[],field='',quoted=false;
  for(let i=0;i<source.length;i++){
    const c=source[i];
    if(c==='"'&&(quoted||field==='')){
      if(quoted&&source[i+1]==='"'){field+='"';i++;}
      else quoted=!quoted;
    } else if(!quoted&&(c===separator||c==='\n'||c==='\r')){
      row.push(field);field='';
      if(c!==separator){rows.push(row);row=[];if(c==='\r'&&source[i+1]==='\n')i++;}
    } else field+=c;
  }
  if(quoted) throw Error('Unclosed quoted cell.');
  if(row.length||field) rows.push([...row,field]);
  return rows;
}

const xml=s=>{
  const d=new DOMParser().parseFromString(s,'application/xml');
  if(d.querySelector('parsererror')||d.doctype) throw Error('Invalid workbook XML.');
  return d;
};
const elements=(d,name)=>Array.from(d.getElementsByTagNameNS('*',name));
async function xlsx(file) {
  const raw=await file.arrayBuffer(), v=new DataView(raw), b=new Uint8Array(raw), decoder=new TextDecoder();
  let tail=raw.byteLength-22;
  while(tail>=Math.max(0,raw.byteLength-65557)&&v.getUint32(tail,true)!==0x06054b50) tail--;
  if(tail<Math.max(0,raw.byteLength-65557)) throw Error('Workbook ZIP directory not found.');
  const zip=new Map();
  for(let i=0,p=v.getUint32(tail+16,true);i<v.getUint16(tail+10,true);i++){
    if(v.getUint32(p,true)!==0x02014b50) throw Error('Invalid ZIP directory.');
    const len=v.getUint16(p+28,true);
    zip.set(decoder.decode(b.subarray(p+46,p+46+len)),[v.getUint32(p+42,true),v.getUint32(p+20,true),v.getUint16(p+10,true)]);
    p+=46+len+v.getUint16(p+30,true)+v.getUint16(p+32,true);
  }
  async function read(path){
    const entry=zip.get(path);
    if(!entry)return '';
    const [p,n,method]=entry;
    if(v.getUint32(p,true)!==0x04034b50)throw Error('Invalid ZIP entry.');
    const start=p+30+v.getUint16(p+26,true)+v.getUint16(p+28,true);
    if(method===0)return decoder.decode(b.subarray(start,start+n));
    if(method!==8)throw Error('Unsupported ZIP compression.');
    const reader=new Blob([b.subarray(start,start+n)]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
    let length=0, text='';
    const utf8=new TextDecoder();
    try {
      while(true){
        const part=await reader.read();
        if(part.done)return text+utf8.decode();
        length+=part.value.length;
        if(length>16000000)throw Error('Worksheet exceeds 16 MB uncompressed.');
        text+=utf8.decode(part.value,{stream:true});
      }
    } finally {await reader.cancel();}
  }
  const book=xml(await read('xl/workbook.xml'));
  const rel=xml(await read('xl/_rels/workbook.xml.rels'));
  const shared=await read('xl/sharedStrings.xml');
  const strings=shared?elements(xml(shared),'si').map(s=>elements(s,'t').map(t=>t.textContent).join('')):[];
  const paths=new Map(elements(rel,'Relationship').map(r=>[r.getAttribute('Id'),r.getAttribute('Target')]));
  const epoch=elements(book,'workbookPr')[0]?.getAttribute('date1904')==='1'?'1904-01-01':'1899-12-30';
  const sheets=[];
  for(const s of elements(book,'sheet').slice(0,15)){
    const path=paths.get(s.getAttribute('r:id'));
    if(!path)continue;
    const text=await read(path.startsWith('/')?path.slice(1):'xl/'+path);
    if(!text)continue;
    const rows=elements(xml(text),'row').slice(0,10001).map(r=>{
      const row=[];
      for(const c of elements(r,'c')){
        const col=(c.getAttribute('r')??'A').match(/^[A-Z]+/)?.[0]??'A';
        const i=[...col].reduce((n,k)=>26*n+k.charCodeAt(0)-64,0)-1;
        if(i>100)continue;
        const value=elements(c,'v')[0]?.textContent??'';
        const type=c.getAttribute('t');
        row[i]=type==='s'?strings[Number(value)]:type==='inlineStr'?elements(c,'t').map(t=>t.textContent).join(''):value;
      }
      return row;
    });
    sheets.push({name:s.getAttribute('name'),rows,epoch});
  }
  return sheets;
}
export async function tables(file) {
  if(file.size>12000000)throw Error('Choose a file smaller than 12 MB.');
  return /\.xlsx$/i.test(file.name)?xlsx(file):[{name:file.name,rows:delimited(await file.text()),epoch:'1899-12-30'}];
}
export function objects(table) {
  const clean=s=>String(s??'').trim().toLowerCase().replaceAll(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');
  const [head,...body]=table.rows.filter(row=>row.some(v=>String(v??'').trim()));
  return body.map(row=>Object.fromEntries(Array.from(head??[],(h,i)=>{
    const k=clean(h);
    const val=String(row[i]??'').trim();
    return [k,/^(date|expiry|open_date|close_date|asof|prior)$/.test(k)&&/^\d{5}$/.test(val)?shift(table.epoch,Number(val)):val];
  })));
}
export function download(data,name,mime='text/csv;charset=utf-8'){
  const href=URL.createObjectURL(new Blob([data],{type:mime}));
  const a=document.createElement('a');a.href=href;a.download=name;a.click();
  setTimeout(()=>URL.revokeObjectURL(href),1000);
}
export function csv(rows) {
  if(!rows.length)return '';
  const keys=[...new Set(rows.flatMap(Object.keys))];
  const safe=s=>{const x=String(s??'');return '"'+(typeof s==='string'&&/^[=+\-@]/.test(x)?"'"+x:x).replaceAll('"','""')+'"';};
  return [keys.map(safe).join(','),...rows.map(r=>keys.map(k=>safe(r[k])).join(','))].join('\r\n');
}
export function excel(rows,name) {
  const keys=[...new Set(rows.flatMap(Object.keys))];
  const esc=s=>String(s??'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));
  const line=values=>'<Row>'+values.map(v=>'<Cell><Data ss:Type="'+(Number.isFinite(v)?'Number':'String')+'">'+esc(v)+'</Data></Cell>').join('')+'</Row>';
  download('<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Risk data"><Table>'+line(keys)+rows.map(r=>line(keys.map(k=>r[k]))).join('')+'</Table></Worksheet></Workbook>',name+'.xml','application/vnd.ms-excel');
}
