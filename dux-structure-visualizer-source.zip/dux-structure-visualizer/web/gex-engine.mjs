import {market, structureValue, group, sum, shift, series} from './risk-engine.mjs';
import {optionPoint} from './options-engine.mjs';

export const seriesKey=r=>[r.expiry,r.strike,r.type,r.style,r.factor].join('|');
export const knownSum=(rows,fn)=>{
  const values=rows.map(fn).filter(Number.isFinite);
  return values.length?sum(values,x=>x):null;
};

export function historyChange(previous,current,c){
  const old=market(previous,c);
  const now=market(current,c);
  const before=new Map(old.map(r=>[seriesKey(r),r]));
  const after=new Map(now.map(r=>[seriesKey(r),r]));
  const pairs=now.flatMap(r=>{
    const p=before.get(seriesKey(r));
    return Number.isFinite(r.exposure)&&Number.isFinite(p?.exposure)?[[p,r]]:[];
  });
  const covered=old.length>0&&now.length>0&&old.every(r=>Number.isFinite(r.exposure))&&now.every(r=>Number.isFinite(r.exposure));
  const expired=old.filter(r=>r.expiry<=current[0]?.date&&!after.has(seriesKey(r)));
  return {
    net:covered?sum(now,r=>r.exposure)-sum(old,r=>r.exposure):null,
    matched:pairs.length,
    matchedMove:knownSum(pairs,([a,b])=>b.exposure-a.exposure),
    expiredEffect:covered?-sum(expired,r=>r.exposure):null,
    universeEffect:covered?sum(now.filter(r=>!before.has(seriesKey(r))),r=>r.exposure)-sum(old.filter(r=>!after.has(seriesKey(r))&&r.expiry>current[0].date),r=>r.exposure):null,
    oiMove:old.length&&now.length&&[...old,...now].every(r=>r.oi!=null)?sum(now,r=>r.oi)-sum(old,r=>r.oi):null
  };
}

export function profileRoots(points,at){
  const roots=[];
  const scale=Math.max(1,...points.map(([,y])=>Math.abs(y??0)));
  const sign=y=>Number.isFinite(y)&&Math.abs(y)>scale*1e-9?Math.sign(y):0;
  let left=null;
  for(const point of points){
    if(!Number.isFinite(point[1])){left=null;continue;}
    const s=sign(point[1]);
    if(!s)continue;
    if(left&&sign(left[1])!==s){
      let a=left[0],b=point[0];
      for(let i=0;i<15;i++){
        const m=(a+b)/2, v=at(m);
        if(!Number.isFinite(v))break;
        if(!sign(v)){a=b=m;break;}
        if(sign(v)===s)b=m;else a=m;
      }
      roots.push((a+b)/2);
    }
    left=point;
  }
  return roots;
}

export function hedgeRoll(rows,c,f,days,vol){
  const next=market(rows,c,f,days+1,vol);
  const before=market(rows,c,f,days,vol);
  const today=shift(rows[0].date,days);
  const tomorrow=shift(today,1);
  const expiring=before.filter(r=>r.expiry>today&&r.expiry<=tomorrow);
  const active=r=>r.expiry>tomorrow;
  const hedge=knownSum(next.filter(active),r=>r.hedge);
  const close=knownSum(expiring,r=>r.hedge);
  const current=knownSum(before.filter(r=>r.expiry>today),r=>r.hedge);
  return {expiring:expiring.length, expiringHedge:close, nextHedge:current==null?null:hedge??0, change:current==null?null:(hedge??0)-current};
}

export function positionGamma(t,date,rate,f=t.f,days=0,vol=0){
  if(t.kind==='future')return {gamma:0,delta:t.signed,method:'Linear futures'};
  if(!(f>0&&t.factor>0))return null;
  const asof=shift(date,days);
  if(t.kind==='option'&&t.iv>0&&t.strike>0&&t.expiry>asof&&['call','put'].includes(t.type)){
    const g=optionPoint({...t,iv:Math.max(.01,t.iv+vol)},f,asof,rate,80);
    return {gamma:g.gamma*t.signed,delta:g.delta*t.signed,method:t.style==='us'?'American futures tree':'Black-76'};
  }
  if(t.kind==='structure'&&(t.barrierState==='ended'||t.remaining===0))return {gamma:0,delta:0,method:'No remaining fixings'};
  if(t.kind!=='structure'||t.expiry<=asof)return null;
  const bump=f*.005, sigma=Math.max(.01,t.iv+vol);
  const pv=x=>structureValue(t,x,asof,rate,sigma,512,days,days?t.f:null);
  const a=pv(f-bump),b=pv(f),d=pv(f+bump);
  if([a,b,d].some(x=>!Number.isFinite(x)))return null;
  return {gamma:(a-2*b+d)/(bump*bump*t.factor),delta:(d-a)/(2*bump*t.factor),method:'Path model · ±0.5% bump'};
}

export function portfolioGamma(trades,date,c){
  return trades.map(t=>{
    const r=positionGamma(t,date,c.rate);
    const eq=r==null?null:r.gamma===0?0:t.f>0?r.gamma*t.f*.01:null;
    return {Trade:t.id,Contract:t.symbol,Instrument:t.kind,Expiry:t.expiry,Strike:t.strike,'Open signed lots':t.signed,
      'Delta lots':r?.delta,'Gamma lots / point':r?.gamma,'Hedge sensitivity lots / +1%':eq==null?null:-eq,
      'Portfolio GEX USD / 1%':eq===0?0:eq!=null&&t.factor>0?eq*t.f*t.factor:null,Method:r?.method??'Missing terms, mark or IV'};
  });
}

export function gammaByExpiry(rows){
  return group(rows,'expiry').map(([expiry,rs])=>({expiry,oi:knownSum(rs,r=>r.oi),absolute:knownSum(rs,r=>r.exposure==null?null:Math.abs(r.exposure))}));
}
