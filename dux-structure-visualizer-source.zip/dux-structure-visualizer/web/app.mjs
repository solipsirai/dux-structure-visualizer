import {presets, example, evaluate, atPrice, boundaries, intervals, sensitivity, payoffAtRow, vanilla, checks} from './engine.mjs';

const $ = id => document.getElementById(id);
const all = selector => Array.from(document.querySelectorAll(selector));
const put = (id,value) => { $(id).textContent = value; };
const number = new Intl.NumberFormat('en-US',{maximumFractionDigits:6});
const fmt = value => number.format(Object.is(value,-0)?0:value);
const lot = qty => fmt(qty)+' '+(qty===1?'lot':'lots');
const cash = (v,c,sign=false) => (v<0?'−':v>0&&sign?'+':'')+
  new Intl.NumberFormat('en-US',{style:'currency',currency:c.currency,maximumFractionDigits:2,minimumFractionDigits:0}).format(Math.abs(v));
const signed = v => v<0?'−'+fmt(-v):v>0?'+'+fmt(v):'0';
const textNumber = value => Number(value.toPrecision(11)).toString();

const icons = {
  dux:'<path d="M3 15h7l2-5h8M15 5l5 5-5 5"/>',
  double:'<path d="M4 15h4V9H4zm8 0h4V5h-4zm8 0h1M3 19h18"/>',
  parachute:'<path d="M3 10a9 7 0 0 1 18 0H3zm0 0 9 9 9-9m-12 0 3 9 3-9"/>',
  ddu:'<path d="M4 16v-4m5 4V7m5 9v-4m5 4V5M3 20h18"/>',
  knock:'<path d="m6 6 12 12M18 6 6 18"/><circle cx="12" cy="12" r="9"/>'
};

$('presets').innerHTML = Object.entries(presets).filter(([,p])=>!p.variant).map(([key,p])=>
  '<button type="button" class="preset" data-preset="'+key+'"><span class="preset-icon"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">'+icons[key]+'</svg></span><span><strong>'+p.title+'</strong><small>'+p.subtitle+'</small></span></button>').join('');

$('variant').insertAdjacentHTML('beforeend',Object.entries(presets).filter(([,p])=>p.variant).map(([key,p])=>'<option value="'+key+'">'+p.title+' · '+p.subtitle+'</option>').join(''));

const eventNames = {base:'Base fixing',double:'Daily double-up',expiry:'Expiry double-up',stop:'KO · stopped',skip:'KO · skipped',resetDay:'KO · daily reset',resetRest:'KO · remaining lots reset',ended:'Already stopped'};
const activeInputs = ['settlement','strike','double','barrier','lots','count','coupon','timing','multiplier','doubleDir','doubleEqual','koMode','barrierDir','barrierEqual','action','size','factor','currency'];
let selectedPreset='dux', side='sell', day=4, view='payoff', cached=null, domain=null;
let lastScheduleCount = 0;

function setPreset(key) {
  const c=example(key);
  selectedPreset=key;
  $('variant').value=c.variant?key:'';
  loadOriginalTerms(key);
  side=c.side;
  day=c.prices.length-1;
  for (const name of activeInputs) $(name).value=c[name];
  $('resetPrice').value=c.reset;
  $('path').value=c.prices.join(', ');
  $('touches').value='';
  $('price').value=c.prices[day];
  $('benchmark').value='off';
  view='payoff';
  render();
}

function syncControls() {
  const doubleOff=$('timing').value==='none';
  const koOff=$('koMode').value==='none';
  const coupon=$('settlement').value==='coupon';
  for (const id of ['double','doubleDir','doubleEqual','multiplier']) $(id).disabled=doubleOff;
  for (const id of ['barrier','barrierDir','barrierEqual','action']) $(id).disabled=koOff;
  $('resetPrice').disabled=koOff || !['resetDay','resetRest'].includes($('action').value) || coupon;
  $('strike').disabled=coupon && $('benchmark').value==='off';
  $('coupon-field').hidden=!coupon;
  $('touch-field').hidden=$('koMode').value!=='touch';
  $('touch-label').textContent=$('barrierDir').value==='below'?'Pre-fixing lows':'Pre-fixing highs';
  $('touches').placeholder=$('barrierDir').value==='below'?'Example: —, 549, —, —, —':'Example: —, 651, —, —, —';
  for (const btn of all('[data-preset]')) btn.setAttribute('aria-pressed',String(btn.dataset.preset===selectedPreset));
  for (const btn of all('[data-side]')) btn.setAttribute('aria-pressed',String(btn.dataset.side===side));
  for (const btn of all('[data-view]')) btn.setAttribute('aria-pressed',String(btn.dataset.view===view));
  for (const btn of all('[data-path]')) btn.disabled=(btn.dataset.path==='touch'&&$('koMode').value!=='touch')||(btn.dataset.path==='rebound'&&koOff);
  put('preset-caption',presets[selectedPreset].description);
}

function inputError(id,message) {
  $(id).setAttribute('aria-invalid','true');
  throw new Error(message);
}

function readNumber(id,label,min=-1e9,max=1e9) {
  const input=$(id);
  const value=input.valueAsNumber;
  if(input.disabled) return Number.isFinite(value)?value:0;
  if (!Number.isFinite(value)||value<min||value>max) {
    if(min>0) inputError(id,label+' must be between '+fmt(min)+' and '+fmt(max)+'.');
    inputError(id,'Enter a number for '+label.toLowerCase()+' between '+fmt(min)+' and '+fmt(max)+'.');
  }
  return value;
}

function series(id,optional=false) {
  const raw=$(id).value.trim();
  if(!raw && optional) return [];
  if(!raw) inputError(id,'Enter at least one fixing price in the fixing schedule.');
  const parts=raw.split(/[\s,;]+/).filter(Boolean);
  return parts.map(part=>{
    if(optional&&['-','—','–'].includes(part)) return null;
    if(!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[-+]?\d+)?$/i.test(part)||!Number.isFinite(Number(part))||Math.abs(Number(part))>1e9)
      inputError(id,optional?'Use a number or a dash for each pre-fixing observation.':'Use numeric fixing prices, separated by commas, spaces or newlines.');
    return Number(part);
  });
}

function readConfig() {
  for (const input of all('[aria-invalid=true]')) input.removeAttribute('aria-invalid');
  const count=readNumber('count','Planned fixings',1,120);
  if(!Number.isInteger(count)) inputError('count','Planned fixings must be a whole number.');
  const prices=series('path');
  if(!prices.length||prices.length>count) inputError('path','Enter between 1 and '+count+' fixing prices for this schedule.');
  const touches=$('koMode').value==='touch'?series('touches',true):[];
  if(touches.length&&touches.length!==prices.length) inputError('touches','Enter a pre-fixing observation or a dash for each listed fixing.');
  day=Math.min(day,prices.length-1);
  return {
    count,prices,touches,side,settlement:$('settlement').value,timing:$('timing').value,koMode:$('koMode').value,
    action:$('action').value,currency:$('currency').value,doubleDir:$('doubleDir').value,barrierDir:$('barrierDir').value,
    doubleEqual:$('doubleEqual').value==='true',barrierEqual:$('barrierEqual').value==='true',
    strike:readNumber('strike','Fixing strike'),double:readNumber('double','Double-up trigger'),barrier:readNumber('barrier','KO barrier'),
    reset:readNumber('resetPrice','Reset price'),lots:readNumber('lots','Base lots per fixing',.000001,1e6),
    multiplier:readNumber('multiplier','Lot multiplier',1,100),size:readNumber('size','Units per lot',.000001,1e9),
    factor:readNumber('factor','Cash per point per unit',.000001,1e6),
    coupon:$('settlement').value==='coupon'?readNumber('coupon','Cash coupon'):0
  };
}

function priceRange(c) {
  const levels=[c.strike];
  if(c.timing!=='none') levels.push(c.double);
  if(c.koMode!=='none') levels.push(c.barrier);
  if(c.koMode!=='none'&&['resetDay','resetRest'].includes(c.action)&&c.settlement!=='coupon') levels.push(c.reset);
  const span=Math.max(...levels)-Math.min(...levels);
  const pad=Math.max(1,span*.38,Math.abs(c.strike)*.06);
  const selected=c.prices[day];
  return [Math.max(-1e9,Math.min(selected,Math.min(...levels)-pad)),Math.min(1e9,Math.max(selected,Math.max(...levels)+pad))];
}

function updatePrice(value,keepDomain=true,keepPriceInput=false) {
  try {
    if(!Number.isFinite(value)||Math.abs(value)>1e9) inputError('price','Enter a fixing price between −1 billion and +1 billion.');
    const path=series('path');
    path[day]=value;
    $('path').value=path.join(', ');
    render(keepDomain,keepPriceInput);
  } catch (e) {
    showError(e.message);
  }
}

function changeSide(newSide) {
  side=newSide;
  render();
}

function showError(message) {
  cached=null;
  $('error').hidden=false;
  put('error',message);
  put('statement-rules','Correct the contract inputs to see the rules.');
  put('statement-exposure','');
  for(const id of ['schedule-results','hedge-results']) $(id).hidden=true;
  $('outputs').classList.add('invalid-results');
  for(const id of ['chart','scrubber','benchmark']) $(id).inert=true;
}

function regionTitle(range) {
  if(!Number.isFinite(range.lo)&&!Number.isFinite(range.hi)) return 'Any fixing price';
  if(!Number.isFinite(range.lo)) return 'Below '+fmt(range.hi);
  if(!Number.isFinite(range.hi)) return 'Above '+fmt(range.lo);
  return 'Between '+fmt(range.lo)+' and '+fmt(range.hi);
}

function explanation(c,row) {
  const subject = c.settlement==='physical'?'locks in':'uses';
  const level = c.settlement==='coupon'?'':' at '+fmt(row.level);
  if (row.event==='ended') return 'A prior barrier event ended this schedule. No new lots are booked at this fixing.';
  if (row.event==='stop') return (row.touchHit?'The barrier was touched before fixing. ':'The fixing hits the barrier. ')+'The schedule ends here and earlier fixings stay booked.';
  if (row.event==='skip') return 'This barrier event skips the selected fixing. The next scheduled fixing can still book lots.';
  if (row.event==='resetRest') return 'The barrier event '+subject+' '+lot(row.base)+level+' from the remaining base schedule, including this fixing. Earlier extra lots stay booked.';
  if (row.event==='resetDay') return 'The barrier event '+subject+' '+lot(row.base)+level+' for this fixing only. The next fixing follows the usual rules.';
  if (row.event==='expiry') return 'The expiry fixing '+subject+' '+lot(row.base)+level+' and adds '+lot(row.extra)+' based on the original base schedule.';
  if (row.event==='double') return 'This fixing triggers '+lot(row.extra)+' on top of '+lot(row.base)+' at the same terms.';
  return 'This fixing '+subject+' the base amount of '+lot(row.base)+level+'.'+(c.timing==='expiry'&&row.day<c.count?' The extra block is tested at expiry.':'');
}

function renderRegions(c,row,ranges) {
  $('regions').innerHTML=ranges.map((range,i)=>{
    const r=range.row;
    const active=row.price>range.lo&&row.price<range.hi;
    const units=r.qty?lot(r.qty)+(c.settlement==='coupon'?' for coupon': ' at '+fmt(r.level)):'0 new lots';
    return '<button type="button" class="region" data-region="'+i+'" aria-pressed="'+active+'"><span>'+regionTitle(range)+'</span><strong>'+eventNames[r.event]+'</strong><small>'+units+'</small></button>';
  }).join('');
  const edges=boundaries(c,day);
  put('boundary-note',edges.length?edges.map(price=>{
    const exact=atPrice(c,day,price);
    return 'At '+fmt(price)+' exactly: '+eventNames[exact.event]+', '+lot(exact.qty)+'.';
  }).join(' '):row.touchHit&&row.hit?'The entered intraday touch applies at any fixing price.':'');
}

function renderSchedule(c,r) {
  const selected=$('selected-day');
  if(lastScheduleCount!==c.prices.length){
    selected.innerHTML=c.prices.map((_,i)=>'<option value="'+i+'">Day '+(i+1)+'</option>').join('');
    lastScheduleCount=c.prices.length;
  }
  selected.value=day;
  put('path-summary',r.rows.length+' of '+c.count+' fixings entered · '+lot(r.baseSchedule)+' planned base');
  put('level-head',c.settlement==='coupon'?'Coupon / lot':'Fixed at');
  put('value-head',c.settlement==='physical'?'Vs market':'Modeled cash');
  $('schedule-rows').innerHTML=r.rows.map((row,i)=>{
    const css=row.hit?' hit':row.extra?' extra':'';
    const fixed=row.qty?(c.settlement==='coupon'?cash(c.coupon,c):fmt(row.level)):'—';
    return '<tr class="'+(i===day?'selected':'')+'"><td><button type="button" class="day-button" data-day="'+i+'" aria-pressed="'+(i===day)+'">Day '+row.day+'</button></td><td>'+fmt(row.price)+'</td><td><span class="event'+css+'">'+eventNames[row.event]+'</span>'+(row.hit&&row.touchHit?' <small>@ '+fmt(row.intraday)+'</small>':'')+'</td><td>'+fmt(row.base)+'</td><td>'+fmt(row.extra)+'</td><td>'+fmt(row.qty)+'</td><td>'+fixed+'</td><td class="'+(row.payoff<0?'negative':row.payoff>0?'positive':'')+'">'+cash(row.payoff,c,true)+'</td></tr>';
  }).join('');
  const touchNote=c.koMode==='touch'&&c.prices.some((_,i)=>c.touches[i]==null)?' Missing intraday entries use fixing-only evidence. A touch could have happened before the fixing.':'';
  put('schedule-note','Total '+(c.settlement==='physical'?'value versus each fixing':'modeled cash')+' across the entered path is '+cash(r.totalPayoff,c,true)+'.'+touchNote);
}

function renderHedge(c,row) {
  const s=sensitivity(c,day,row.price);
  const local = s.edge ? 'At a threshold' : s.slope===0 ? 'Flat here' : (s.slope>0?'Long ':'Short ')+lot(Math.abs(s.slope));
  const dealer = s.edge ? 'At a threshold' : s.slope===0 ? 'Flat here' : (s.slope>0?'Short ':'Long ')+lot(Math.abs(s.slope));
  const hedge = s.edge ? 'No single hedge size' : s.slope===0 ? '0 futures lots' : (s.slope>0?'Buy ':'Sell ')+lot(Math.abs(s.slope));
  $('hedge-grid').innerHTML=[
    ['Your local exposure',local,'Selected fixing payoff'],
    ['Dealer before hedge',dealer,'Opposite side of your payoff'],
    ['Illustrative futures offset',hedge,'Same underlying and lot size']
  ].map(([name,main,sub])=>'<div class="hedge-tile"><span>'+name+'</span><strong>'+main+'</strong><small>'+sub+'</small></div>').join('');
  let detail;
  if(s.edge){
    detail='Just below this level your slope is '+signed(s.left)+' lots. Just above it the slope is '+signed(s.right)+' lots.'+(s.jump?' The payoff jumps at the trigger, so a futures position alone cannot cover the jump.':'');
  }else if(s.slope===0){
    detail=c.settlement==='coupon'&&row.qty?'The coupon is fixed within this region. Crossing a trigger can still change the cash amount.':'Small price changes within this region leave the selected fixing payoff unchanged.';
  }else{
    const move=cash(s.slope*c.size*c.factor,c,true);
    const opposite=cash(-s.slope*c.size*c.factor,c,true);
    detail='For a 1-point rise within this region, your fixing value moves '+move+' and the dealer’s moves '+opposite+'. The illustrative futures position offsets that move.';
  }
  put('hedge-reading',detail);
}

function render(keepDomain=false,keepPriceInput=false) {
  syncControls();
  let c;
  try { c=readConfig(); }
  catch(e) { showError(e.message); return; }
  $('error').hidden=true;
  for(const id of ['schedule-results','hedge-results']) $(id).hidden=false;
  $('outputs').classList.remove('invalid-results');
  for(const id of ['chart','scrubber','benchmark']) $(id).inert=false;
  const r=evaluate(c);
  const row=r.rows[day];
  const ranges=intervals(c,day);
  if(!keepDomain||!domain) domain=priceRange(c);
  cached={c,row,ranges};
  $('scrubber').min=domain[0];
  $('scrubber').max=domain[1];
  $('scrubber').value=row.price;
  $('scrubber').setAttribute('aria-valuetext',fmt(row.price));
  if(!keepPriceInput) $('price').value=row.price;
  put('payoff-label',c.settlement==='physical'?'Fixing value vs market':'Cash at this fixing');
  put('payoff-value',cash(row.payoff,c,true));
  $('payoff-value').className=row.payoff<0?'negative':row.payoff>0?'positive':'';
  put('payoff-note',c.settlement==='physical'?'Reference price comparison':'Modeled cash settlement');
  put('qty-value',fmt(row.qty));
  put('qty-note',row.extra?lot(row.base)+' base + '+lot(row.extra)+' extra':eventNames[row.event]);
  put('total-value',fmt(r.totalLots));
  put('total-note',r.stopped?'Schedule ended':r.remaining?lot(r.remaining)+' still scheduled':lot(r.baseSchedule)+' planned base');
  put('chart-title',view==='payoff'?'Payoff by price':'Exposure by price');
  put('chart-sub','Day '+row.day+' of '+c.count+' · '+(row.day===c.count?'expiry fixing':'scheduled fixing')+' · Earlier observations held fixed');
  put('legend-line',view==='payoff'?'Your structure':'Your local exposure');
  $('benchmark-control').classList.toggle('show-benchmark',$('benchmark').value!=='off');
  $('legend-ko').hidden=c.koMode==='none';
  $('legend-double').hidden=c.timing==='none'||(c.timing==='expiry'&&row.day!==c.count);
  $('benchmark-control').hidden=view!=='payoff';
  $('comparison-note').hidden=view!=='payoff'||$('benchmark').value==='off';
  put('reading',explanation(c,row));
  renderStatement(c,row);
  renderRegions(c,row,ranges);
  renderSchedule(c,r);
  renderHedge(c,row);
  renderChart();
}

function renderChart() {
  if(!cached) return;
  const {c,row,ranges}=cached;
  const chart=$('chart');
  const W=Math.max(275,Math.round(chart.clientWidth||680));
  const H=chart.clientHeight||276;
  const left=W<450?51:69;
  const right=W-17;
  const top=28;
  const bottom=H-37;
  const [lo,hi]=domain;
  const x=p=>left+(p-lo)/(hi-lo)*(right-left);
  const payoff=view==='payoff';
  const compare=payoff?$('benchmark').value:'off';
  const pick=(r,p)=>payoff?payoffAtRow(c,r,p):r.slope;
  const segments=ranges.map(range=>({...range,start:Math.max(lo,range.lo),end:Math.min(hi,range.hi)})).filter(r=>r.start<r.end);
  const chosen=pick(row,row.price);
  const vals=[0,chosen,...segments.flatMap(r=>[pick(r.row,r.start),pick(r.row,r.end)])];
  if(compare!=='off') vals.push(vanilla(c,lo,compare),vanilla(c,hi,compare));
  const ymin=Math.min(...vals);
  const ymax=Math.max(...vals);
  const pad=(ymax-ymin)*.10||1;
  const y0=ymin-pad;
  const y1=ymax+pad;
  const y=v=>bottom-(v-y0)/(y1-y0)*(bottom-top);
  const compact=new Intl.NumberFormat('en-US',{notation:'compact',maximumFractionDigits:1});
  const axisValue=v=>{
    const magnitude=Math.abs(v);
    const n=magnitude>=1000?compact.format(magnitude):fmt(Number(magnitude.toPrecision(3)));
    return (v<0?'−':'')+n;
  };
  const coords=(px,py)=>x(px).toFixed(2)+','+y(py).toFixed(2);
  const point=(px,py,filled,r=3.8)=>'<circle cx="'+x(px)+'" cy="'+y(py)+'" r="'+r+'" fill="'+(filled?'#ad4b22':'#f9f9f2')+'" stroke="#ad4b22" stroke-width="1.7"/>';
  const levels=boundaries(c,day);
  let markup='<title id="svg-title">'+(payoff?'Selected fixing payoff by price':'Selected fixing exposure in equivalent lots')+'</title><desc id="svg-desc">At '+fmt(row.price)+' the selected value is '+(payoff?cash(chosen,c,true):signed(chosen)+' equivalent lots')+'. Use the slider or price field to explore.</desc>';
  markup+='<defs><linearGradient id="under" x1="0" x2="0" y1="0" y2="1" gradientUnits="objectBoundingBox"><stop stop-color="#e7ae87" stop-opacity=".46"/><stop offset="1" stop-color="#efc9a9" stop-opacity=".31"/></linearGradient></defs>';
  const bands=['#f2e8de','#f1f3e9','#f4ece1'];
  segments.forEach((r,i)=>{
    markup+='<rect x="'+x(r.start)+'" y="'+top+'" width="'+(x(r.end)-x(r.start))+'" height="'+(bottom-top)+'" fill="'+bands[i%bands.length]+'" opacity=".62"/>';
  });
  const yTicks=Array.from({length:5},(_,i)=>ymin+(ymax-ymin)*i/4);
  if(ymin===ymax) yTicks.splice(0,5,-.5,0,.5);
  else if(ymin<0&&ymax>0) yTicks[yTicks.reduce((i,v,j)=>Math.abs(v)<Math.abs(yTicks[i])?j:i,0)]=0;
  yTicks.forEach(v=>{
    markup+='<line x1="'+left+'" y1="'+y(v)+'" x2="'+right+'" y2="'+y(v)+'" stroke="'+(Math.abs(v)<1e-10?'#a2a99b':'#dce0d3')+'"/><text x="'+(left-7)+'" y="'+(y(v)+4)+'" text-anchor="end" fill="#596358" font-size="10.5">'+axisValue(v)+'</text>';
  });
  if(ymin<0&&ymax>0&&!yTicks.includes(0)) markup+='<line x1="'+left+'" y1="'+y(0)+'" x2="'+right+'" y2="'+y(0)+'" stroke="#a2a99b"/>';
  const tickCount=W<450?4:6;
  for(let i=0;i<=tickCount;i++){
    const v=lo+(hi-lo)*i/tickCount;
    markup+='<line x1="'+x(v)+'" y1="'+top+'" x2="'+x(v)+'" y2="'+bottom+'" stroke="#dce0d3"/><text x="'+x(v)+'" y="'+(bottom+16)+'" text-anchor="middle" fill="#596358" font-size="10.5">'+axisValue(v)+'</text>';
  }
  markup+='<text x="'+left+'" y="16" fill="#596358" font-size="10.5" font-weight="650">'+(payoff?c.currency:'Equivalent lots')+'</text>';
  markup+='<text x="'+((left+right)/2)+'" y="'+(H-7)+'" text-anchor="middle" fill="#596358" font-size="10.5" font-weight="650">Fixing price</text>';
  const marks=[];
  if(c.koMode!=='none') marks.push([c.barrier,'KO','#995f58']);
  if(c.timing==='daily'||(c.timing==='expiry'&&row.day===c.count)) marks.push([c.double,'2×','#886835']);
  marks.forEach(([level,label,color],i)=>{
    if(level<lo||level>hi) return;
    const mid=x(level);
    markup+='<line x1="'+mid+'" x2="'+mid+'" y1="'+top+'" y2="'+bottom+'" stroke="'+color+'" stroke-dasharray="4 4" opacity=".85"/>';
    const near=marks.some(([other],j)=>j!==i&&Math.abs(mid-x(other))<55);
    const tx=Math.min(right-14,Math.max(left+14,mid));
    markup+='<text x="'+tx+'" y="'+(near&&i===1?43:19)+'" text-anchor="middle" fill="'+color+'" font-size="10.5" font-weight="700">'+label+' '+axisValue(level)+'</text>';
  });
  segments.forEach(r=>{
    const a=coords(r.start,pick(r.row,r.start));
    const b=coords(r.end,pick(r.row,r.end));
    markup+='<polygon points="'+coords(r.start,0)+' '+a+' '+b+' '+coords(r.end,0)+'" fill="url(#under)"/><polyline points="'+a+' '+b+'" fill="none" stroke="#ad4b22" stroke-width="2.5" stroke-linecap="round"/>';
  });
  if(compare!=='off'){
    const pivot=Math.min(hi,Math.max(lo,c.strike));
    markup+='<polyline points="'+[lo,pivot,hi].map(p=>coords(p,vanilla(c,p,compare))).join(' ')+'" fill="none" stroke="#41688c" stroke-width="2" stroke-dasharray="6 4"/>';
  }
  levels.forEach((level,i)=>{
    if(level<lo||level>hi) return;
    const before=pick(ranges[i].row,level);
    const after=pick(ranges[i+1].row,level);
    const exact=pick(atPrice(c,day,level),level);
    if(before===after&&exact===before) return;
    markup+=point(level,before,exact===before);
    if(before!==after) markup+=point(level,after,exact===after);
    if(exact!==before&&exact!==after) markup+=point(level,exact,true);
  });
  const sx=x(row.price);
  markup+='<line x1="'+sx+'" x2="'+sx+'" y1="'+top+'" y2="'+bottom+'" stroke="#a94923" stroke-width="1.2" stroke-dasharray="3 3"/><circle cx="'+sx+'" cy="'+y(chosen)+'" r="7" fill="#fdf7ea" stroke="#ad4b22" stroke-width="1.4"/>'+point(row.price,chosen,true,4);
  const label=fmt(row.price);
  const labelWidth=Math.max(31,label.length*6.3+13);
  const tagX=Math.min(right-labelWidth/2,Math.max(left+labelWidth/2,sx));
  markup+='<rect x="'+(tagX-labelWidth/2)+'" y="'+(bottom-15)+'" width="'+labelWidth+'" height="15" rx="4" fill="#8c3d20"/><text x="'+tagX+'" y="'+(bottom-4)+'" text-anchor="middle" fill="white" font-size="10.5" font-weight="650">'+label+'</text>';
  markup+='<rect class="plot-hit" x="'+left+'" y="'+top+'" width="'+(right-left)+'" height="'+(bottom-top)+'" fill="transparent"/>';
  chart.setAttribute('viewBox','0 0 '+W+' '+H);
  chart.innerHTML=markup;
  cached.plot={left,right,W,lo,hi};
}

function examplePath(kind) {
  try {
    const c=readConfig();
    const span=Math.max(1,Math.abs(c.strike)*.025,Math.abs(c.double-c.strike)*.5,Math.abs(c.barrier-c.strike)*.5);
    const triggerSign=c.doubleDir==='above'?1:-1;
    const barrierSign=c.barrierDir==='below'?-1:1;
    const safe=c.barrier-barrierSign*span;
    const cap=value=>Math.max(-1e9,Math.min(1e9,Number(textNumber(value))));
    const data=Array.from({length:c.count},(_,i)=>{
      const level=c.timing==='none'?c.strike:c.double;
      const target=level+triggerSign*span*(2*(i+1)/c.count-0.6);
      if(kind==='rally'&&c.koMode==='none') return cap(target);
      if(kind==='rally') return cap(barrierSign<0?Math.max(safe,target):Math.min(safe,target));
      return cap(safe-barrierSign*span*(i%3)*.35);
    });
    const hitIndex=Math.min(data.length-1,Math.floor(data.length/2));
    const hitPrice=cap(c.barrier+barrierSign*span*.2);
    const touch=Array(data.length).fill('—');
    if(kind==='touch') touch[hitIndex]=hitPrice;
    if(kind==='rebound') data[hitIndex]=hitPrice;
    $('path').value=data.join(', ');
    $('touches').value=kind==='touch'?touch.join(', '):'';
    day=kind==='rally'?data.length-1:hitIndex;
    render();
  } catch(e) { showError(e.message); }
}

function loadOriginalTerms(key) {
  let stored=null;
  try { stored=localStorage.getItem('dux-statement-'+key); } catch {}
  $('original-terms').value=stored??'';
}

function ruleRelation(dir,equal) {
  return dir==='above'?(equal?'≥':'>'):(equal?'≤':'<');
}

function renderStatement(c,row) {
  const metadata=[['Base notional',lot(c.count*c.lots)],['Scheduled fixings',fmt(c.count)]];
  $('statement-metadata').innerHTML=metadata.map(([k,v])=>'<div><dt>'+k+'</dt><dd>'+v+'</dd></div>').join('');
  const side=c.settlement==='physical'?(c.side==='sell'?'Sell':'Buy'):'Book';
  const price=c.settlement==='coupon'?cash(c.coupon,c)+' per lot':fmt(c.strike);
  const rules=[side+' '+lot(c.lots)+' at '+price+' each active fixing.'];
  if(c.koMode!=='none'){
    const action={stop:'End future fixings.',skip:'Skip this fixing.',resetDay:'Reset this fixing at '+fmt(c.reset)+'.',resetRest:'Reset remaining base lots at '+fmt(c.reset)+'.'}[c.action];
    rules.push((c.koMode==='touch'?'Intraday observation':'Fixing')+' '+ruleRelation(c.barrierDir,c.barrierEqual)+' '+fmt(c.barrier)+' triggers the barrier. '+action);
  }
  if(c.timing!=='none'){
    const qty=c.lots*(c.multiplier-1)*(c.timing==='expiry'?c.count:1);
    rules.push(side+' '+lot(qty)+' extra at '+price+' if the '+(c.timing==='expiry'?'expiry':'daily')+' fixing is '+ruleRelation(c.doubleDir,c.doubleEqual)+' '+fmt(c.double)+' and the contract is active.');
  }
  $('statement-rules').innerHTML=rules.map(s=>'<li>'+s+'</li>').join('');
  put('statement-exposure','Selected fixing: '+lot(row.qty)+' and '+cash(row.payoff,c,true)+' versus the reference price.');
}

$('variant').addEventListener('change',e=>{if(e.target.value)setPreset(e.target.value);});
$('load-statement').addEventListener('click',()=>setPreset('parachuteExpiry'));
$('original-terms').addEventListener('input',e=>{try{localStorage.setItem('dux-statement-'+selectedPreset,e.target.value);}catch{}});

for(const btn of all('[data-preset]')) btn.addEventListener('click',()=>setPreset(btn.dataset.preset));
for(const btn of all('[data-side]')) btn.addEventListener('click',()=>changeSide(btn.dataset.side));
for(const btn of all('[data-view]')) btn.addEventListener('click',()=>{view=btn.dataset.view;render(true);});
for(const btn of all('[data-path]')) btn.addEventListener('click',()=>examplePath(btn.dataset.path));
$('reset').addEventListener('click',()=>setPreset(selectedPreset));
$('terms').addEventListener('submit',e=>e.preventDefault());
$('terms').addEventListener('input',e=>{
  if(e.target.id==='barrierDir') $('touches').value='';
  render();
});
for(const id of ['path','touches']) $(id).addEventListener('input',()=>render());
$('selected-day').addEventListener('change',e=>{day=Number(e.target.value);render();});
$('schedule-rows').addEventListener('click',e=>{
  const btn=e.target.closest('[data-day]');
  if(btn){day=Number(btn.dataset.day);render();$('schedule-rows').querySelector('[data-day="'+day+'"]').focus({preventScroll:true});}
});
$('benchmark').addEventListener('change',()=>render(true));
$('scrubber').addEventListener('input',e=>updatePrice(e.target.valueAsNumber));
$('price').addEventListener('input',e=>{
  if(Number.isFinite(e.target.valueAsNumber)) updatePrice(e.target.valueAsNumber,false,true);
});
$('price').addEventListener('change',e=>updatePrice(e.target.valueAsNumber,false));
$('price').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();e.target.blur();e.target.focus();}});
$('regions').addEventListener('click',e=>{
  const btn=e.target.closest('[data-region]');
  if(btn&&cached){
    const i=Number(btn.dataset.region);
    updatePrice(Math.max(-1e9,Math.min(1e9,cached.ranges[i].probe)),false);
    $('regions').querySelector('[data-region="'+i+'"]')?.focus({preventScroll:true});
  }
});
$('chart').addEventListener('click',e=>{
  if(!cached||!e.target.classList.contains('plot-hit')) return;
  const {left,right,W,lo,hi}=cached.plot;
  const rect=$('chart').getBoundingClientRect();
  const ratio=((e.clientX-rect.left)*W/rect.width-left)/(right-left);
  updatePrice(Number((lo+Math.max(0,Math.min(1,ratio))*(hi-lo)).toPrecision(6)));
});
new ResizeObserver(()=>renderChart()).observe($('chart'));

let passed=0;
$('test-list').innerHTML=checks.map(check=>{
  const ok=check.run();
  if(ok) passed++;
  return '<li><strong>'+check.name+' · '+(ok?'Pass':'Fail')+'</strong><p>'+check.explain+'</p></li>';
}).join('');
put('test-count',passed+' / '+checks.length+' passing');
if(passed!==checks.length) $('test-count').classList.add('negative');
setPreset('dux');
