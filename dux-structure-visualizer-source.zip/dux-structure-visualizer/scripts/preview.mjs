import {createServer} from 'node:http';
import {assets} from './build.mjs';
import {handler} from '../worker/index.mjs';

const args=process.argv.slice(2);
const port=Number(process.env.PORT||args[args.indexOf('--port')+1])||4173;
const host=process.env.HOST||'127.0.0.1';
createServer(async(req,res)=>{
  try {
    const app=handler(await assets());
    const response=await app.fetch(new Request('http://localhost'+req.url,{method:req.method}));
    res.writeHead(response.status,Object.fromEntries(response.headers));
    res.end(Buffer.from(await response.arrayBuffer()));
  } catch(error) {
    res.writeHead(500);
    res.end(String(error));
  }
}).listen(port,host,()=>console.log('Preview ready on '+host+':'+port));
