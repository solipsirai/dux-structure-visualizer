import {readFile,mkdir,readdir,writeFile} from 'node:fs/promises';

const types={js:'text/javascript; charset=utf-8',html:'text/html; charset=utf-8',css:'text/css; charset=utf-8',mjs:'text/javascript; charset=utf-8'};
export async function assets() {
  const pairs=await Promise.all((await readdir('web')).map(async name=>{
    const type=types[name.split('.').at(-1)];
    if(!type) throw new Error('Unsupported asset type: '+name);
    return ['/'+name,[type,await readFile('web/'+name,'utf8')]];
  }));
  return Object.fromEntries(pairs);
}

if(process.argv[1]?.endsWith('/build.mjs')) {
  const market=(await readFile('worker/market.mjs','utf8')).replaceAll('export function ','function ').replaceAll('export async function ','async function ');
  const index=(await readFile('worker/index.mjs','utf8')).replace("import {settlements} from './market.mjs';",'').replace('export function handler','function handler');
  await mkdir('dist/server',{recursive:true});
  await writeFile('dist/server/index.js',market+'\n'+index+'\nexport default handler('+JSON.stringify(await assets())+');\n');
}
