import assert from 'node:assert/strict';
import {checks,example,evaluate,atPrice} from '../web/engine.mjs';
import {products,greeks,optionBook,marketMove,marginCall,collateralCall,shockValue} from '../web/options-engine.mjs';
import {parseHistorical,cutoff,settlements} from '../worker/market.mjs';
import deployed from '../dist/server/index.js';

const near=(actual,expected,tolerance)=>assert.ok(Math.abs(actual-expected)<tolerance,actual+' vs '+expected);
for(const t of checks) assert.ok(t.run(),t.name);

const exampleTrade=example('parachuteExpiry');
let r=evaluate(exampleTrade);
assert.equal(r.totalLots,20);
assert.equal(r.rows[9].extra,10);
assert.equal(atPrice(exampleTrade,9,519.99).extra,0);
r=evaluate({...exampleTrade,touches:[null,480]});
assert.equal(r.rows[1].level,495);
assert.equal(r.rows[1].qty,9);
assert.equal(r.totalLots,10);
assert.equal(r.rows[9].extra,0);
assert.equal(evaluate(example('closeReset')).rows[2].qty,1);
assert.equal(evaluate(example('closeSkip')).rows[2].qty,0);
assert.equal(evaluate(example('closeSkip')).rows[3].qty,2);
assert.equal(atPrice(example('digital'),0,600).payoff,250);
assert.equal(atPrice(example('digital'),0,599.99).payoff,0);
assert.equal(evaluate(example('consumer')).rows[2].qty,2);

const euro={contract:1,style:'eu',type:'call',strike:100,iv:20,expiry:'2027-01-01',lots:2,side:'long',premium:5};
const asof='2026-01-01';
const rate=.05;
const call=greeks(euro,100,asof,rate);
const put=greeks({...euro,type:'put'},100,asof,rate);
near(call.price,7.57708,.0001);
near(call.delta-put.delta,Math.exp(-.05),1e-8);
near(call.gamma,put.gamma,1e-8);
near(call.vega,.37759,.0001);
assert.ok(call.theta<0&&call.rho<0);
const amer=greeks({...euro,style:'us',type:'put',strike:130},100,asof,rate);
assert.ok(amer.price>=30&&amer.price>=greeks({...euro,type:'put',strike:130},100,asof,rate).price);
assert.equal(greeks(euro,100,euro.expiry,rate).atStrike,true);
assert.equal(products.SB.factor,1120);
assert.equal(products.W.factor,50);
const markets={1:{close:100,previous:99,factor:50}};
const book=optionBook([{...euro,mark:8,previousMark:6},{...euro,side:'short',mark:8,previousMark:6}],markets,asof,rate);
near(book.reduce((n,b)=>n+b.deltaLots,0),0,1e-8);
near(shockValue(book,markets,asof,rate,-5,3),0,1e-8);
assert.equal(marketMove(book.slice(0,1),markets,asof,'2025-12-31',rate).value,200);
assert.equal(marketMove(book,markets,asof,asof,rate),null);
assert.deepEqual(marginCall(18000,-7000,15000,20000),{adjusted:11000,shortfall:4000,call:9000});
assert.equal(marginCall(15000,0,15000,20000).call,0);
assert.equal(collateralCall(-10000,1000,3000,0,6000).call,6000);
assert.equal(collateralCall(-10000,1000,3000,0,6001).call,0);

const bars=[['Thu Nov 12 00:00:00 2026',99],['Tue Nov 10 00:00:00 2026',18.09],['Wed Nov 11 00:00:00 2026',18.48]];
assert.deepEqual(parseHistorical(bars,'2026-11-11'),{date:'2026-11-11',close:18.48,previousDate:'2026-11-10',previous:18.09});
assert.equal(cutoff(new Date('2026-11-12T22:00:00Z')),'2026-11-12');
const saved=new Map();
const bucket={get:async k=>saved.has(k)?{json:async()=>JSON.parse(saved.get(k))}:null,put:async(k,v)=>saved.set(k,v)};
const liveFetch=globalThis.fetch;
let requestCount=0;
globalThis.fetch=async url=>{
  requestCount++;
  return Response.json(url.includes('contract-data')?[{marketStrip:'Mar27',marketId:7}]:{bars});
};
try {
  const url=new URL('https://test.invalid/api/market/settlements?symbols=SBH27');
  const warmed=await settlements(url,{BUCKET:bucket});
  assert.equal(warmed.quotes.SBH27.close,parseHistorical(bars,cutoff()).close);
  assert.equal(saved.size,1);
  await settlements(url,{BUCKET:bucket});
  assert.equal(requestCount,2);
} finally {globalThis.fetch=liveFetch;}
const home=await deployed.fetch(new Request('https://test.invalid/'));
assert.equal(home.status,200);
assert.match(await home.text(),/Load synthetic example/);
const opts=await deployed.fetch(new Request('https://test.invalid/options.html'));
assert.match(await opts.text(),/Options Portfolio/);
assert.equal((await deployed.fetch(new Request('https://test.invalid/api/market/refresh'))).status,405);
process.stdout.write('Structure, option Greeks, daily P/L, margin, CSA and settlement checks passed.\n');
